export const VERSION = "1.1";
const COMMANDS = [
  { n: "help", d: "List all commands" },
  { n: "ver", d: "Show the Nova DOS version" },
  { n: "build", d: "Show the current release" },
  { n: "dir", d: "List files and directories" },
  { n: "cd", d: "Change directory" },
  { n: "md", d: "Make a directory" },
  { n: "rd", d: "Remove an empty directory" },
  { n: "type", d: "Display a text file" },
  { n: "copy", d: "Copy a file" },
  { n: "move", d: "Move a file" },
  { n: "ren", d: "Rename a file" },
  { n: "del", d: "Delete a file" },
  { n: "delete", d: "Delete a file" },
  { n: "cls", d: "Clear the screen" },
  { n: "clear", d: "Clear the screen" },
  { n: "echo", d: "Print text" },
  { n: "set", d: "Show or set environment variables" },
  { n: "path", d: "Show the executable search path" },
  { n: "date", d: "Show the current date" },
  { n: "time", d: "Show the current time" },
  { n: "vol", d: "Show the volume label" },
  { n: "tree", d: "Show the directory tree" },
  { n: "find", d: "Search for text in a file" },
  { n: "more", d: "Display text one page at a time" },
  { n: "g-note", d: "Open the graphical text editor" },
  { n: "gnote", d: "Open the graphical text editor" },
  { n: "turn", d: "Turn off the Note graphical editor" },
  { n: "open", d: "Run a .COM or .NOVDOS file, or open a file in Vents" },
  { n: "run", d: "Run a source file" },
  { n: "indexedpfs", d: "Show encrypted IndexedPFS storage status" },
  { n: "kernel", d: "Show the WASM kernel status" },
  { n: "x86", d: "Show the 16-bit x86 runtime status" },
  { n: "chkdsk", d: "Check the file system" },
  { n: "mem", d: "Show memory status" },
  { n: "history", d: "Show command history" },
  { n: "calc", d: "Evaluate a math expression" },
  { n: "base64", d: "Base64 encode/decode" },
  { n: "sha256", d: "SHA-256 hash of text" },
  { n: "ip", d: "Show your local IP" },
  { n: "network", d: "Choose a network for future internet copies" },
  { n: "hostname", d: "Show the hostname" },
  { n: "cowsay", d: "Print a talking cow" },
  { n: "figlet", d: "Render large text" },
  { n: "banner", d: "Print spaced banner text" },
  { n: "ascii", d: "Show character codes" },
  { n: "upper", d: "Convert text to uppercase" },
  { n: "lower", d: "Convert text to lowercase" },
  { n: "trim", d: "Remove surrounding whitespace" },
  { n: "words", d: "Count words in text" },
  { n: "lines", d: "Count lines in text" },
  { n: "repeat", d: "Repeat text" },
  { n: "head", d: "Show the first lines of a file" },
  { n: "tail", d: "Show the last lines of a file" },
  { n: "wc", d: "Count lines, words, and characters" },
  { n: "sort", d: "Sort file lines" },
  { n: "uniq", d: "Remove adjacent duplicate lines" },
  { n: "grep", d: "Search file lines" },
  { n: "tr", d: "Translate characters" },
  { n: "cut", d: "Extract a delimited field" },
  { n: "replace", d: "Replace text" },
  { n: "append", d: "Append text to a file" },
  { n: "write", d: "Write text to a file" },
  { n: "truncate", d: "Resize a file" },
  { n: "stat", d: "Show file metadata" },
  { n: "file", d: "Identify a file or directory" },
  { n: "size", d: "Show file size" },
  { n: "du", d: "Show directory usage" },
  { n: "locate", d: "Find paths by name" },
  { n: "basename", d: "Show the final path component" },
  { n: "dirname", d: "Show the parent path" },
  { n: "realpath", d: "Resolve a path" },
  { n: "pushd", d: "Save and change directory" },
  { n: "popd", d: "Return to a saved directory" },
  { n: "dirs", d: "Show the directory stack" },
  { n: "which", d: "Locate a command" },
  { n: "where", d: "Locate commands and files" },
  { n: "who", d: "List local users" },
  { n: "whoami", d: "Show the current user" },
  { n: "id", d: "Show user identity" },
  { n: "tty", d: "Show the terminal name" },
  { n: "acswitch", d: "Switch user accounts" },
  { n: "ps", d: "List running processes" },
  { n: "tasklist", d: "List running tasks" },
  { n: "ping", d: "Test a host connection" },
  { n: "nslookup", d: "Look up a host" },
  { n: "route", d: "Show the routing table" },
  { n: "diskfree", d: "Show free disk space" },
  { n: "label", d: "Show or set the volume label" },
  { n: "prompt", d: "Show or set the command prompt" },
  { n: "attrib", d: "Show or set file attributes" },
  { n: "verify", d: "Show or set write verification" },
  { n: "random", d: "Generate a random number" },
  { n: "uuid", d: "Generate a UUID" },
  { n: "checksum", d: "Calculate a text checksum" },
  { n: "gcd", d: "Find the greatest common divisor" },
  { n: "lcm", d: "Find the least common multiple" },
];

const ENTERTAINMENT_COMMANDS = [
  ["fortune", "Show a random fortune"],
  ["joke", "Tell a short joke"],
  ["riddle", "Ask a riddle"],
  ["dice", "Roll a six-sided die"],
  ["coin", "Flip a coin"],
  ["eightball", "Ask the magic eight ball"],
  ["choose", "Choose from a list"],
  ["roll", "Roll dice notation"],
  ["slot", "Play a slot machine"],
  ["anagram", "Make an anagram"],
  ["scramble", "Scramble text"],
  ["palindrome", "Check for a palindrome"],
  ["fizzbuzz", "Play FizzBuzz"],
  ["countdown", "Start a countdown"],
  ["quote", "Show a random quote"],
  ["haiku", "Write a tiny haiku"],
  ["limerick", "Write a tiny limerick"],
  ["poem", "Print a tiny poem"],
  ["madlib", "Make a tiny mad lib"],
  ["emoji", "Show random emoji"],
  ["rainbow", "Print rainbow colors"],
  ["matrix", "Show a matrix rain"],
  ["glitch", "Glitch some text"],
  ["mirror", "Mirror text"],
  ["pyramid", "Build a text pyramid"],
  ["box", "Put text in a box"],
  ["wave", "Print a text wave"],
  ["dance", "Make a dancing character"],
  ["spinner", "Spin an animation symbol"],
  ["progress", "Show a progress bar"],
  ["applause", "Start an applause"],
  ["drumroll", "Play a drumroll"],
  ["asciiart", "Show a tiny ASCII scene"],
  ["christmas", "Show a holiday scene"],
  ["halloween", "Show a spooky scene"],
  ["birthday", "Show a birthday greeting"],
  ["trivia", "Ask a trivia question"],
  ["quiz", "Ask a quick quiz question"],
  ["roulette", "Spin a roulette wheel"],
  ["lucky", "Test your luck"],
  ["compliment", "Give a compliment"],
  ["roast", "Give a gentle roast"],
  ["pet", "Interact with a virtual pet"],
  ["horoscope", "Show a playful horoscope"],
  ["chant", "Print a team chant"],
  ["clap", "Make a clap pattern"],
  ["beat", "Print a beat pattern"],
].map(([n, d]) => ({ n, d }));

const CATALOG_VERBS = [
  "archive", "backup", "benchmark", "bind", "cache", "check", "compile", "compare", "compress",
  "convert", "decode", "decompress", "decrypt", "describe", "detect", "encode", "encrypt", "export",
  "extract", "filter", "format", "generate", "import", "index", "inspect", "install", "merge", "migrate",
  "monitor", "mount", "normalize", "parse", "patch", "publish", "query", "rebuild", "recode", "refresh",
  "render", "report", "restore", "scan", "search", "serialize", "split", "sync", "transform", "validate",
  "view", "audit", "clean", "clone", "deploy",
];
const CATALOG_NOUNS = ["file", "text", "data", "path", "disk", "user", "system", "archive", "bulk", "remote", "secure"];
const CATALOG_COMMANDS = CATALOG_VERBS.flatMap((verb) => CATALOG_NOUNS.map((noun) => ({
  n: `${verb}-${noun}`,
  d: `${verb} ${noun}`,
}))).slice(0, 553);

COMMANDS.push(...ENTERTAINMENT_COMMANDS, ...CATALOG_COMMANDS);

export const helpText = COMMANDS;

export const commands = {};

function toAbs(ctx, p) {
  if (p === undefined) return ctx.cwd;
  return ctx.resolve(p);
}

commands.help = async (ctx) => {
  const { args, print } = ctx;
  const pat = args[0];
  const rows = COMMANDS.filter((c) => !pat || c.n.includes(pat));
  print(`For more information on a specific command, type HELP command-name.\n`);
  for (const c of rows) {
    print(`  ${c.n.padEnd(12)} ${c.d}`);
  }
};

commands.man = async (ctx) => {
  const { args, print } = ctx;
  const name = args[0];
  if (!name || !ctx.commands[name]) {
    print(`No manual entry. Type 'help' to list commands.`, "err");
    return;
  }
  const c = ctx.commands[name];
  print(`NAME\n    ${name} - ${findDesc(name)}\n`);
  if (c.doc) print("DESCRIPTION\n" + c.doc);
};

function findDesc(name) {
  const c = COMMANDS.find((x) => x.n === name);
  return c ? c.d : "a terminal command";
}

commands.clear = async (ctx) => ctx.clear();

commands.echo = async (ctx) => {
  const { args, env } = ctx;
  let s = args.join(" ");
  s = s.replace(/%([A-Za-z0-9_]+)%/g, (_, k) => (k in env ? env[k] : ""));
  s = s.replace(/\$(\w+)/g, (_, k) => (k in env ? env[k] : ""));
  ctx.print(s);
};

commands.whoami = async (ctx) => ctx.print(ctx.state.user);

commands.date = async (ctx) => {
  const d = new Date();
  ctx.print(`The current date is ${d.toLocaleDateString()}.`);
};

commands.time = async (ctx) => {
  const d = new Date();
  ctx.print(`The current time is ${d.toLocaleTimeString([], { hour12: false })}.`);
};

commands.month = async (ctx) => {
  const d = new Date();
  const names = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const line = names.join(" ");
  const first = new Date(d.getFullYear(), d.getMonth(), 1);
  let out = "";
  const titles = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"];
  out += titles[d.getMonth()] + " " + d.getFullYear() + "\n\n";
  out += line + "\n";
  let pos = 0;
  for (let i = 0; i < first.getDay(); i++) { out += "    "; pos++; }
  const days = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
  for (let day = 1; day <= days; day++) {
    out += String(day).padEnd(4);
    pos++;
    if (pos % 7 === 0 && day !== days) out += "\n";
  }
  ctx.print(out);
};

commands.uptime = async (ctx) => {
  const sec = Math.floor((Date.now() - ctx.startTime) / 1000);
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  ctx.print(`up ${h}h ${m}m ${s}s, running on ${ctx.state.host}`);
};

commands.uname = async (ctx) => {
  const { args, print } = ctx;
  const m = args.includes("-m") || args.includes("-a");
  const s = args.includes("-s") || args.includes("-a");
  const a = args.includes("-a");
  if (a) print("Terminal-OS 1.0.0 web 0 0 text-web");
  else if (m) print("wasm/text");
  else print("Terminal-OS");
};

commands.env = async (ctx) => {
  const { env, print } = ctx;
  for (const k of Object.keys(env)) print(`${k}=${env[k]}`);
};

commands.export = async (ctx) => {
  const { args, env, print } = ctx;
  if (!args[0]) { print("Usage: export NAME=value", "err"); return; }
  const eq = args[0].indexOf("=");
  if (eq < 0) { print(`export: not a valid assignment: ${args[0]}`, "err"); return; }
  const k = args[0].slice(0, eq);
  let v = args[0].slice(eq + 1);
  if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
  env[k] = v;
  print(`set ${k}=${v}`, "ok");
};

commands.unset = async (ctx) => {
  const { args, env, print } = ctx;
  if (!args[0]) { print("Usage: unset NAME", "err"); return; }
  delete env[args[0]];
  print(`unset ${args[0]}`, "dim");
};

commands.set = async (ctx) => {
  const { args, env, print } = ctx;
  if (!args.length) {
    Object.keys(env).sort().forEach((key) => print(`${key}=${env[key]}`));
    return;
  }
  const input = args.join(" ");
  const eq = input.indexOf("=");
  if (eq < 0) {
    const key = input.toUpperCase();
    Object.keys(env).filter((name) => name.startsWith(key)).sort()
      .forEach((name) => print(`${name}=${env[name]}`));
    return;
  }
  const key = input.slice(0, eq).trim().toUpperCase();
  env[key] = input.slice(eq + 1);
};

commands.path = async (ctx) => ctx.print(`PATH=${ctx.env.PATH || "C:\\DOS;C:\\BIN"}`);

commands.vol = async (ctx) => {
  const label = ctx.state.volumeLabel;
  ctx.print(`${label ? ` Volume in drive C is ${label}.` : " Volume in drive C has no label."}\n Volume Serial Number is 0000-0000`);
};

commands.pwd = async (ctx) => ctx.print(ctx.display(ctx.cwd));

commands.dir = async (ctx) => {
  const { args, print, nodeAt, resolve, display } = ctx;
  const targetArg = args.find((a) => !a.startsWith("/"));
  const target = targetArg ? resolve(targetArg) : ctx.cwd;
  const node = nodeAt(target);
  if (!node || node.type !== "dir") {
    print("File Not Found", "err");
    return;
  }
  print(" Volume in drive C has no label.");
  print(" Volume Serial Number is 0000-0000\n");
  print(` Directory of ${display(target)}\n`);
  let files = 0;
  let dirs = 0;
  for (const name of Object.keys(node.children).sort()) {
    const item = node.children[name];
    if (item.type === "dir") {
      print(`${"".padStart(10)}<DIR>          ${name}`);
      dirs++;
    } else {
      print(`${"".padStart(10)}${String(item.content.length).padStart(12)} ${name}`);
      files++;
    }
  }
  print(`\n       ${files} File(s)\n       ${dirs} Dir(s)`);
};

function printTree(ctx, node, prefix, name, isLast) {
  ctx.print(`${prefix}${isLast ? "\\---" : "+---"}${name}`);
  if (node.type !== "dir") return;
  const entries = Object.entries(node.children).sort(([a], [b]) => a.localeCompare(b));
  entries.forEach(([childName, child], index) => {
    printTree(ctx, child, prefix + (isLast ? "    " : "|   "), childName, index === entries.length - 1);
  });
}

commands.tree = async (ctx) => {
  const targetArg = ctx.args.find((a) => !a.startsWith("/"));
  const target = targetArg ? ctx.resolve(targetArg) : ctx.cwd;
  const node = ctx.nodeAt(target);
  if (!node || node.type !== "dir") { ctx.print("Invalid path", "err"); return; }
  ctx.print(ctx.display(target));
  Object.entries(node.children).sort(([a], [b]) => a.localeCompare(b))
    .forEach(([name, child], index, all) => printTree(ctx, child, "", name, index === all.length - 1));
};

commands.find = async (ctx) => {
  const { args, print, resolve, nodeAt } = ctx;
  if (args.length < 2) { print("FIND: Usage is FIND \"string\" [file]", "err"); return; }
  const needle = args[0].replace(/^\"|\"$/g, "").toLowerCase();
  for (const path of args.slice(1)) {
    const node = nodeAt(resolve(path));
    if (!node || node.type !== "file") { print(`File not found - ${path}`, "err"); continue; }
    node.content.split("\n").filter((line) => line.toLowerCase().includes(needle))
      .forEach((line) => print(line));
  }
};

commands.more = async (ctx) => {
  const path = ctx.args[0];
  if (!path) { ctx.print("More? ", "err"); return; }
  const node = ctx.nodeAt(ctx.resolve(path));
  if (!node || node.type !== "file") { ctx.print("File not found", "err"); return; }
  ctx.print(node.content.replace(/\n$/, ""));
};

commands.chkdsk = async (ctx) => {
  const count = Object.keys(ctx.fs.children).length;
  ctx.print("The type of the file system is Nova DOS.");
  ctx.print(`${count} directories checked. No errors found.`);
};

commands.mem = async (ctx) => {
  ctx.print("655,360 bytes total conventional memory");
  ctx.print("655,360 bytes available to Nova DOS");
};

commands.ls = async (ctx) => {
  const { args, print, nodeAt, resolve, display } = ctx;
  const showHidden = args.includes("-a");
  const l = args.includes("-l");
  const cl = args.filter((a) => !a.startsWith("-"));
  const target = cl[0] ? resolve(cl[0]) : ctx.cwd;
  const node = nodeAt(target);
  if (!node || node.type !== "dir") {
    print(`ls: cannot access '${cl[0] || target}': no such directory`, "err");
    return;
  }
  if (l) {
    for (const name of Object.keys(node.children).sort()) {
      if (!showHidden && name.startsWith(".")) continue;
      const c = node.children[name];
      const type = c.type === "dir" ? "d" : "-";
      const size = c.type === "dir" ? "4" : String(c.content.length);
      print(`${type}r--r--r--  1 user user  ${size.padStart(5)}  ${name}${c.type === "dir" ? "/" : ""}`);
    }
    return;
  }
  const items = Object.keys(node.children).sort();
  print(items.map((name) => {
    const c = node.children[name];
    if (!showHidden && name.startsWith(".")) return null;
    return `<span class="ls-item ${c.type === "dir" ? "fs-dir" : ""}">${name}</span>`;
  }).filter(Boolean).join(""));
};

commands.cd = async (ctx) => {
  const { args, print } = ctx;
  let target;
  if (!args[0] || args[0] === "~") target = ctx.HOME();
  else if (args[0] === "-") return print("cd: no previous directory stored", "dim");
  else target = args[0];
  const resolved = target === "~" ? ctx.HOME() : ctx.resolve(target);
  const node = ctx.nodeAt(resolved);
  if (!node || node.type !== "dir") {
    print(`cd: no such directory: ${args[0]}`, "err");
    return;
  }
  ctx.cwd = resolved;
};

const writeFile = (ctx, path, content, metadata = {}) => {
  const target = ctx.resolve(path.startsWith("~/") ? ctx.HOME() + path.slice(1) : path);
  const parts = target.split("/").filter(Boolean);
  const fname = parts.pop();
  let n = ctx.fs;
  for (const p of parts) {
    if (!n.children[p] || n.children[p].type !== "dir") {
      n.children[p] = { type: "dir", children: {} };
    }
    n = n.children[p];
  }
  n.children[fname] = { type: "file", content, ...metadata };
};

commands.cat = async (ctx) => {
  const { args, print, nodeAt, resolve } = ctx;
  if (!args[0]) { print("Usage: cat FILE", "err"); return; }
  const node = nodeAt(resolve(args[0]));
  if (!node) { print(`cat: ${args[0]}: no such file`, "err"); return; }
  if (node.type === "dir") { print(`cat: ${args[0]}: is a directory`, "err"); return; }
  print(node.content.replace(/\n$/, ""));
};

commands.touch = async (ctx) => {
  const { args, print, nodeAt, resolve } = ctx;
  if (!args[0]) { print("Usage: touch FILE", "err"); return; }
  for (const path of args) {
    const n = nodeAt(resolve(path));
    if (!n) writeFile(ctx, path, "");
    else if (n.type === "dir") print(`touch: ${path}: is a directory`, "err");
  }
};

commands.mkdir = async (ctx) => {
  const { args, print, resolve, nodeAt } = ctx;
  if (!args[0]) { print("Usage: mkdir DIR", "err"); return; }
  for (const path of args) {
    const target = resolve(path);
    if (nodeAt(target)) { print(`mkdir: ${path}: already exists`, "err"); continue; }
    writeFile(ctx, target, "");
    const n = ctx.nodeAt(target);
    n.type = "dir"; n.content = undefined; n.children = n.children || {};
  }
};

commands.rmdir = async (ctx) => {
  const { args, print, resolve, nodeAt } = ctx;
  if (!args[0]) { print("Usage: rmdir DIR", "err"); return; }
  for (const path of args) {
    const target = resolve(path);
    const n = nodeAt(target);
    if (!n) { print(`rmdir: ${path}: no such directory`, "err"); continue; }
    if (n.type !== "dir") { print(`rmdir: ${path}: not a directory`, "err"); continue; }
    if (Object.keys(n.children || {}).length) { print(`rmdir: ${path}: not empty`, "err"); continue; }
    removeNode(ctx, target);
  }
};

function removeNode(ctx, target) {
  const parts = target.split("/").filter(Boolean);
  const name = parts.pop();
  let n = ctx.fs;
  for (const p of parts) n = n.children[p];
  delete n.children[name];
}

commands.rm = async (ctx) => {
  const { args, print, resolve, nodeAt } = ctx;
  if (!args[0]) { print("Usage: rm FILE", "err"); return; }
  const rec = args.includes("-r");
  for (const path of args.filter((a) => !a.startsWith("-"))) {
    const target = resolve(path);
    const n = nodeAt(target);
    if (!n) { print(`rm: ${path}: no such file`, "err"); continue; }
    if (n.type === "dir" && !rec) { print(`rm: ${path}: is a directory (use -r)`, "err"); continue; }
    removeNode(ctx, target);
  }
};

commands.mv = async (ctx) => {
  const { args, print, resolve, nodeAt } = ctx;
  if (args.length < 2) { print("Usage: mv SOURCE DEST", "err"); return; }
  const src = resolve(args[0]);
  const n = nodeAt(src);
  if (!n) { print(`mv: ${args[0]}: no such file`, "err"); return; }
  let dest = resolve(args[1]);
  const destNode = nodeAt(dest);
  if (destNode && destNode.type === "dir") dest = resolve(dest + "/" + args[0].split("/").pop());
  writeFile(ctx, dest, n.content || "");
  const dn = ctx.nodeAt(dest);
  if (n.type === "dir") { dn.type = "dir"; dn.content = undefined; dn.children = n.children; }
  removeNode(ctx, src);
};

commands.cp = async (ctx) => {
  const { args, print, resolve, nodeAt } = ctx;
  if (args.length < 2) { print("Usage: cp SOURCE DEST", "err"); return; }
  const src = resolve(args[0]);
  const n = nodeAt(src);
  if (!n) { print(`cp: ${args[0]}: no such file`, "err"); return; }
  if (n.type === "dir") { print(`cp: ${args[0]}: is a directory`, "err"); return; }
  let dest = resolve(args[1]);
  const destNode = nodeAt(dest);
  if (destNode && destNode.type === "dir") dest = resolve(dest + "/" + args[0].split("/").pop());
  writeFile(ctx, dest, n.content);
};

const downloadCommand = async (ctx) => {
  const { args, print, resolve, nodeAt, downloadFile, formatDownloadBytes, progress } = ctx;
  if (!args[0] || !args[1]) {
    print("Usage: download LINK DESTINATION_FOLDER", "err");
    return;
  }
  const url = args[0];
  const destination = resolve(args[1]);
  const destinationNode = nodeAt(destination);
  if (!destinationNode || destinationNode.type !== "dir") {
    print(`download: destination folder not found - ${args[1]}`, "err");
    return;
  }
  if (ctx.confirmInternetInstall && !(await ctx.confirmInternetInstall(url))) {
    return;
  }
  progress(`Downloading ${url}... 0%`);
  try {
    const result = await downloadFile(url, ({ loaded, total }) => {
      const size = formatDownloadBytes(loaded);
      const status = total
        ? `${Math.min(100, Math.round((loaded / total) * 100))}% (${size} / ${formatDownloadBytes(total)})`
        : `${size}`;
      progress(`Downloading ${url}... ${status}`);
    });
    if (ctx.scanFileForMalware) {
      const scan = ctx.scanFileForMalware(result.filename, result.content);
      if (!scan.safe) {
        if (ctx.state?.version === "1.5" && ctx.confirmSecurityScan) {
          const approved = await ctx.confirmSecurityScan(result.filename, scan, null, "install");
          if (!approved) {
            progress(`Cancelled: ${result.filename}`);
            print(`Installation cancelled for ${result.filename}.`, "err");
            scan.threats.forEach((threat) => print(`  ${threat}`, "warn"));
            return;
          }
          print(`Security override accepted for ${result.filename}.`, "warn");
        } else {
          print(`Legacy release: saving ${result.filename} without the NovaDOS 1.5 install prompt.`, "dim");
        }
      }
    }
    const path = resolve(`${destination}/${result.filename}`);
    writeFile(ctx, path, result.content, {
      contentType: result.contentType,
      bytes: result.bytes,
      rawBytes: result.rawBytes,
      sourceUrl: url,
    });
    progress(`Downloaded ${formatDownloadBytes(result.bytes)} 100%`);
    print(`Saved ${path}.`, "ok");
  } catch (error) {
    progress(`Download failed: ${url}`);
    const message = error && error.message ? error.message : String(error);
    print(`download: ${message}`, "err");
    if (/failed to fetch|networkerror|cors/i.test(message)) {
      print("The server may block browser downloads from this page (CORS).", "dim");
    }
  }
};

commands.download = downloadCommand;
commands.install = downloadCommand;

commands.open = async (ctx) => {
  const { args, print, nodeAt, resolve } = ctx;
  if (!args[0]) { print("Usage: open FILE", "err"); return; }
  const path = resolve(args[0]);
  const node = nodeAt(path);
  if (!node) { print(`open: ${args[0]}: file not found`, "err"); return; }
  if (node.type === "dir") { print(`open: ${args[0]}: is a directory`, "err"); return; }
  const approved = ctx.confirmFileOpen ? await ctx.confirmFileOpen(path) : true;
  if (!approved) return;
  const securityOverride = ctx.state?.version === "1.5" && approved;
  if (/\.(?:com|novdos)$/i.test(path)) {
    await ctx.runCom(path, securityOverride);
    return;
  }
  if (/\.(?:vnt|exe)$/i.test(path)) {
    try {
      await ctx.runVnt(path, securityOverride);
    } catch (error) {
      print("Vents can only open .exe files packaged as supported VNT source: " + (error?.message || String(error)), "err");
    }
    return;
  }
  await ctx.openVentsDesktop(path, securityOverride ? path : null);
  ctx.print("Vents turned off.", "dim");
};

commands["g-note"] = async (ctx) => {
  await ctx.openGraphicalNote();
  ctx.print("G-note turned off.", "dim");
};
commands.gnote = commands["g-note"];

commands.ven = async (ctx) => {
  await ctx.openVentsDesktop();
  ctx.print("Vents turned off.", "dim");
};

commands.vents = async (ctx) => {
  await ctx.openVentsDesktop();
  ctx.print("Vents turned off.", "dim");
};

commands.turn = async (ctx) => {
  if (ctx.args.join(" ").toLowerCase() !== "off note" && ctx.args.join(" ").toLowerCase() !== "off vents") {
    ctx.print("Usage: turn off Note", "err");
    return;
  }
  if (ctx.closeGraphicalNote) ctx.closeGraphicalNote();
  else ctx.print("Note is not running.", "dim");
};

commands.run = async (ctx) => {
  const { args, print, nodeAt, resolve } = ctx;
  if (!args[0]) {
    print("Usage: run FILE.com, FILE.novdos, FILE.py, or FILE.js [CONSOLE_NAME]", "err");
    return;
  }
  const path = args[0];
  const node = nodeAt(resolve(path));
  if (!node || node.type !== "file") {
    print(`File not found - ${path}`, "err");
    return;
  }
  let securityOverride = false;
  if (ctx.scanFileForMalware) {
    const scan = ctx.scanFileForMalware(path, node.content);
    if (!scan.safe) {
      if (ctx.state?.version === "1.5" && ctx.confirmSecurityScan) {
        securityOverride = await ctx.confirmSecurityScan(path, scan, null, "run");
        if (!securityOverride) {
          print("The file was not executed.", "dim");
          return;
        }
        print(`Security override accepted for ${path}.`, "warn");
      } else {
        print(`Anti-malware blocked ${path}.`, "err");
        scan.threats.forEach((threat) => print(`  ${threat}`, "warn"));
        print("The file was not executed.", "dim");
        return;
      }
    }
  }
  const extension = path.split(".").pop().toLowerCase();
  if (extension === "com" || extension === "novdos") {
    if (args.length > 1) {
      print(`${extension.toUpperCase()} usage: run FILE.${extension}`, "err");
      return;
    }
    await ctx.runCom(path, securityOverride);
    return;
  }
  if (extension === "vnt" || extension === "exe") {
    if (args.length > 1) {
      print("VNT usage: run FILE.vnt or FILE.exe", "err");
      return;
    }
    await ctx.runVnt(path, securityOverride);
    return;
  }
  if (["py", "pyx", "cpy"].includes(extension)) {
    if (args.length > 1) {
      print("Python usage: run FILE.py", "err");
      return;
    }
    print("Loading Python runtime...", "dim");
    const result = await ctx.runPython(node.content);
    if (result.stdout) print(result.stdout.replace(/\n$/, ""));
    if (result.stderr) print(result.stderr.replace(/\n$/, ""), "err");
    return;
  }
  if (["js", "jsx", "mjs", "cjs", "ts", "tsx"].includes(extension)) {
    if (args.length > 2) {
      print("JavaScript usage: run FILE.js [CONSOLE_NAME]", "err");
      return;
    }
    const consoleName = args[1];
    print(`Running JavaScript${consoleName ? ` with ${consoleName}` : " with console.log"}...`, "dim");
    const result = await ctx.runJavaScript(node.content, consoleName);
    result.output.forEach((entry) => print(entry.text, entry.cls));
    if (result.error) print(result.error, "err");
    return;
  }
  if (args.length > 1) {
    print("Usage: run FILE", "err");
    return;
  }
  const language = ctx.languageForPath ? ctx.languageForPath(path) : "javascript";
  print("Running " + language + " source...", "dim");
  const result = await ctx.runSource(language, node.content);
  if (result.preview) print("Source is ready for preview in Vents Code.", "dim");
  else print(result.output, result.failed ? "err" : "");
};

commands.vnt = async (ctx) => {
  if (!ctx.args[0]) {
    ctx.print("Usage: vnt FILE.vnt", "err");
    return;
  }
  await ctx.runVnt(ctx.args[0], false);
};

commands.indexedpfs = async (ctx) => {
  try {
    const info = await ctx.storageInfo();
    ctx.print(
      "Storage: " + info.type +
      "\nBacking: " + info.backing +
      "\nIndex: " + info.index +
      "\nEncryption: " + (info.encrypted ? "AES-GCM enabled" : "unavailable") +
      "\nState bytes: " + info.bytes +
      (info.updatedAt ? "\nUpdated: " + info.updatedAt : ""),
    );
  } catch (error) {
    ctx.print("IndexedPFS: " + (error?.message || String(error)), "err");
  }
};

commands.kernel = async (ctx) => {
  const kernel = await ctx.wasmKernel();
  ctx.print("WASM kernel: " + (kernel.available ? "online" : "fallback") +
    "\nArithmetic core: " + (kernel.available ? "WebAssembly" : "JavaScript fallback"));
};

commands.x86 = async (ctx) => {
  ctx.print("x86 runtime: 16-bit real-mode COM interpreter\n" +
    "Supported DOS interrupts: INT 20h, INT 21h AH=02h/09h/4Ch\n" +
    "Execution guard: 100000 instructions");
};

commands.antimalware = async (ctx) => {
  const target = ctx.args[0] || ctx.cwd;
  if (!ctx.scanPath) {
    ctx.print("Anti-malware is unavailable on this NovaDOS release.", "err");
    return;
  }
  const result = ctx.scanPath(target);
  if (!result.found) {
    ctx.print(`antimalware: file or folder not found - ${target}`, "err");
    return;
  }
  ctx.print(`Scanning ${target}...`, "dim");
  if (result.threats.length) {
    ctx.print(`Threats found: ${result.threats.length}`, "err");
    result.threats.forEach(({ path, reasons }) => {
      ctx.print(`  ${path}`, "warn");
      reasons.forEach((reason) => ctx.print(`    ${reason}`, "warn"));
    });
    ctx.print("Threats are blocked from execution.", "dim");
  } else {
    ctx.print("No threats found. Anti-malware protection is active.", "ok");
  }
};

commands.scan = commands.antimalware;
commands.malware = commands.antimalware;

commands.seccheck = async (ctx) => {
  const { print, scanPath } = ctx;
  print("NovaDOS Security Check 1.5", "dim");
  print("Scanning every file on the DOS volume...", "dim");
  const result = scanPath("/");
  if (!result.found) {
    print("Security check could not access the DOS volume.", "err");
    return;
  }
  if (!result.threats.length) {
    print("No malicious or overwhelming code found.", "ok");
    return;
  }
  print(`Found ${result.threats.length} file(s) that may be unsafe.`, "err");
  result.threats.forEach(({ path, reasons }) => {
    print(`\n${path}`, "warn");
    reasons.forEach((reason) => print(`  ${reason}`, "warn"));
    print("  Suggested action: delete this file if you do not trust it.", "dim");
  });
  print("Unsafe files are not automatically deleted.", "dim");
};

commands.history = async (ctx) => {
  const { print } = ctx;
  ctx.history.forEach((h, i) => print(`${String(i).padStart(4)}  ${h}`));
};

commands.version = async (ctx) => {
  const info = ctx.versionInfo ? ctx.versionInfo() : { label: `NovaDOS ${VERSION}`, build: 19, version: VERSION };
  ctx.print(`${info.label} (build ${info.build})`);
};

commands.build = async (ctx) => {
  const { print, versionInfo } = ctx;
  const info = versionInfo();
  if (ctx.args[0]) { print("NovaDOS 1.1 is the only installed release.", "err"); return; }
  print(`Current release: ${info.label} (build ${info.build})`);
};

commands.sleep = async (ctx) => {
  const { args, print } = ctx;
  const s = parseFloat(args[0]);
  if (isNaN(s)) { print("Usage: sleep SECONDS", "err"); return; }
  await new Promise((r) => setTimeout(r, Math.min(s * 1000, 3000)));
};

commands.calc = async (ctx) => {
  const { args, print, env } = ctx;
  let s = args.join(" ").replace(/\^/g, "**");
  s = s.replace(/\$(\w+)/g, (_, k) => (k in env ? env[k] : "0"));
  if (!s) { print("Usage: calc EXPR   e.g. calc 3*4+2", "err"); return; }
  s = s.replace(/[^0-9+\-*/().\s]/g, "");
  if (!s || /[/(]$/.test(s)) { print("calc: invalid expression", "err"); return; }
  try {
    const val = Function(`"use strict"; return (${s})`)();
    print(String(val));
  } catch { print("calc: invalid expression", "err"); }
};

function primeFactors(n) {
  const out = [];
  let x = n;
  for (let d = 2; d * d <= x; d++) {
    while (x % d === 0) { out.push(d); x /= d; }
  }
  if (x > 1) out.push(x);
  return out;
}

commands.factor = async (ctx) => {
  const { args, print } = ctx;
  const n = parseInt(args[0]);
  if (isNaN(n) || n < 2) { print("Usage: factor NUMBER", "err"); return; }
  print(`${n}: ${primeFactors(n).join(" ")}`);
};

commands.fib = async (ctx) => {
  const { args, print } = ctx;
  const n = parseInt(args[0]);
  if (isNaN(n) || n < 0) { print("Usage: fib N", "err"); return; }
  let a = 0, b = 1;
  for (let i = 0; i < n; i++) { const t = a + b; a = b; b = t; }
  print(String(a));
};

commands.prime = async (ctx) => {
  const { args, print } = ctx;
  const n = parseInt(args[0]);
  if (isNaN(n) || n < 2) { print("Usage: prime NUMBER", "err"); return; }
  const ok = primeFactors(n).length === 1;
  print(`${n} is ${ok ? "prime" : "not prime"} (factors: ${primeFactors(n).join(" ")})`);
};

commands.seq = async (ctx) => {
  const { args, print } = ctx;
  let s = 1, e, d = 1;
  if (args.length === 1) e = parseInt(args[0]);
  else if (args.length >= 2) { s = parseInt(args[0]); e = parseInt(args[1]); d = parseInt(args[2]) || 1; }
  if (isNaN(e)) { print("Usage: seq [START] END [STEP]", "err"); return; }
  const arr = [];
  for (let i = s; Math.abs(i - e) < Math.abs(d) || i === e; i += d) {
    if ((d > 0 && i > e) || (d < 0 && i < e)) break;
    arr.push(i);
  }
  print(arr.join(" "));
};

commands.rev = async (ctx) => {
  const { args, print } = ctx;
  if (!args.length) { print("Usage: rev TEXT", "err"); return; }
  print(args.map((a) => a.split("").reverse().join("")).join(" "));
};

const ROT = (s, n) => s.replace(/[a-zA-Z]/g, (c) => {
  const base = c <= "Z" ? 65 : 97;
  return String.fromCharCode(((c.charCodeAt(0) - base + n + 26) % 26) + base);
});

commands.rot13 = async (ctx) => {
  const { args, print } = ctx;
  print(ROT(args.join(" "), 13));
};

commands.caesar = async (ctx) => {
  const { args, print } = ctx;
  const shift = parseInt(args[args.length - 1]);
  if (isNaN(shift)) { print("Usage: caesar TEXT SHIFT", "err"); return; }
  print(ROT(args.slice(0, -1).join(" "), shift));
};

const MORSE = { A: ".-", B: "-...", C: "-.-.", D: "-..", E: ".", F: "..-.", G: "--.", H: "....", I: "..", J: ".---", K: "-.-", L: ".-..", M: "--", N: "-.", O: "---", P: ".--.", Q: "--.-", R: ".-.", S: "...", T: "-", U: "..-", V: "...-", W: ".--", X: "-..-", Y: "-.--", Z: "--..", "0": "-----", "1": ".----", "2": "..---", "3": "...--", "4": "....-", "5": ".....", "6": "-....", "7": "--...", "8": "---..", "9": "----." };

commands.morse = async (ctx) => {
  const { args, print } = ctx;
  const out = args.join(" ").toUpperCase().split("").map((c) => (c === " " ? "  " : MORSE[c] || c)).join(" ");
  print(out);
};

commands.base64 = async (ctx) => {
  const { args, print } = ctx;
  if (!args.length) { print("Usage: base64 -e|-d TEXT", "err"); return; }
  const mode = args[0];
  const txt = args.slice(1).join(" ");
  if (mode === "-d" || mode === "--decode") {
    try { print(atob(txt)); } catch { print("base64: invalid input", "err"); }
  } else {
    print(btoa(txt));
  }
};

commands.sha256 = async (ctx) => {
  const { args, print } = ctx;
  if (!args.length) { print("Usage: sha256 TEXT", "err"); return; }
  const bytes = new TextEncoder().encode(args.join(" "));
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  print([...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join(""));
};

commands.binary = async (ctx) => {
  const { args, print } = ctx;
  const n = parseInt(args[0]);
  if (isNaN(n)) { print("Usage: binary NUMBER", "err"); return; }
  print(n.toString(2));
};

commands.hex = async (ctx) => {
  const { args, print } = ctx;
  const n = parseInt(args[0]);
  if (isNaN(n)) { print("Usage: hex NUMBER", "err"); return; }
  print("0x" + n.toString(16).toUpperCase());
};

commands.cowsay = async (ctx) => {
  const { args, print } = ctx;
  const text = args.join(" ") || "moo";
  const pad = " ".repeat(text.length + 2);
  print(" " + "_".repeat(text.length + 2));
  print(`< ${text} >`);
  print(" " + "-".repeat(text.length + 2));
  print("        \\   ^__^");
  print("         \\  (oo)\\_______");
  print("            (__)\\       )\\/\\");
  print("                ||----w |");
  print("                ||     ||");
};

const FIGLET = {
  A: [" AA ", "A  A", "AAAA", "A  A", "A  A"],
  B: ["BBB ", "B  B", "BBB ", "B  B", "BBB "],
  C: [" CCC", "C   ", "C   ", "C   ", " CCC"],
  D: ["DDD ", "D  D", "D  D", "D  D", "DDD "],
  E: ["EEEE", "E   ", "EEE ", "E   ", "EEEE"],
  F: ["FFFF", "F   ", "FFF ", "F   ", "F   "],
  G: [" GGG", "G   ", "G GG", "G  G", " GGG"],
  H: ["H  H", "H  H", "HHHH", "H  H", "H  H"],
  I: ["IIII", "  I ", "  I ", "  I ", "IIII"],
  J: [" JJJ", "   J", "   J", "J  J", " JJ "],
  K: ["K  K", "K K ", "KK  ", "K K ", "K  K"],
  L: ["L   ", "L   ", "L   ", "L   ", "LLLL"],
  M: ["M  M", "MMMM", "M  M", "M  M", "M  M"],
  N: ["N  N", "NN N", "N NN", "N  N", "N  N"],
  O: [" OO ", "O  O", "O  O", "O  O", " OO "],
  P: ["PPP ", "P  P", "PPP ", "P   ", "P   "],
  Q: [" OO ", "O  O", "O  O", "O O ", " OOQ"],
  R: ["RRR ", "R  R", "RRR ", "R R ", "R  R"],
  S: [" SSS", "S   ", " SS ", "   S", "SSS "],
  T: ["TTTT", " T  ", " T  ", " T  ", " T  "],
  U: ["U  U", "U  U", "U  U", "U  U", " UU "],
  V: ["V  V", "V  V", "V  V", " VV ", " V  "],
  W: ["V  V", "V  V", "V  V", "V  V", " VV "],
  X: ["X  X", " X  ", " X  ", " X  ", "X  X"],
  Y: ["Y  Y", " YY ", " Y  ", " Y  ", " Y  "],
  Z: ["ZZZZ", "   Z", "  Z ", " Z  ", "ZZZZ"],
  "0": [" 000", "00 0", "0 00", "0  0", " 000"],
  "1": ["  1 ", " 11 ", "  1 ", "  1 ", "1111"],
  "2": [" 222", "   2", "  2 ", " 2  ", "2222"],
  "3": [" 333", "   3", "  3 ", "   3", " 333"],
  "4": ["   4", "  44", " 4 4", "4444", "   4"],
  "5": ["5555", "5   ", "555 ", "   5", "555 "],
  "6": [" 666", "6   ", "666 ", "6  6", " 666"],
  "7": ["7777", "   7", "  7 ", " 7  ", " 7  "],
  "8": [" 888", "8   8", " 888", "8 8 8", " 888"],
  "9": [" 999", "9   9", " 999", "    9", " 999"],
  " ": ["  ", "  ", "  ", "  ", "  "],
};

commands.figlet = async (ctx) => {
  const { args, print } = ctx;
  const text = args.join(" ").toUpperCase();
  if (!text) { print("Usage: figlet TEXT", "err"); return; }
  for (let r = 0; r < 5; r++) {
    print(text.split("").map((c) => (FIGLET[c] || FIGLET[" "])[r]).join(""));
  }
};

commands.banner = async (ctx) => {
  const { args, print } = ctx;
  const text = args.join(" ");
  if (!text) { print("Usage: banner TEXT", "err"); return; }
  print(text.split("").map((c) => c + " ").join("").trim());
};

commands.ip = async (ctx) => {
  try {
    const info = await ctx.networkDetails();
    ctx.print("Public IP: " + info.publicIp + "\nOnline: " + info.online +
      "\nConnection: " + info.type + "\nEffective link: " + info.effectiveType);
  } catch (error) {
    ctx.print("ip: " + (error?.message || String(error)), "err");
  }
};

commands.network = async (ctx) => {
  const { print } = ctx;
  const info = await ctx.networkDetails();
  print("NETWORK INFORMATION", "ok");
  print("Public IP: " + info.publicIp);
  print("Country: " + info.country);
  print("Edge: " + info.edge);
  print("Internet: " + (info.online ? "online" : "offline"));
  print("Connection type: " + info.type);
  print("Effective link: " + info.effectiveType);
  if (typeof info.downlink === "number") print("Downlink: " + info.downlink + " Mb/s");
  if (typeof info.rtt === "number") print("Browser RTT estimate: " + info.rtt + " ms");
  print("Wi-Fi name and local gateway are hidden by browser security policy.", "dim");
};

commands.hostname = async (ctx) => ctx.print(ctx.state.host);

commands.acswitch = async (ctx) => {
  const { state, menu, input, print, savePersistentState } = ctx;
  const users = state.users;

  while (true) {
    const choice = await menu("ACCOUNT SWITCH", [
      "Create User",
      "Switch User",
      "Rename User",
      "Delete User",
      "Enter Guest Account",
      "Exit",
    ], "use \u2191\u2193 to move, Enter to select");

    if (choice === null || choice === 5) break;

    if (choice === 0) {
      const name = await input("New username:");
      if (name === null) continue;
      if (!/^[A-Za-z0-9_]+$/.test(name)) { print(`acswitch: '${name}' is not a valid username.`, "err"); continue; }
      if (users[name]) { print(`acswitch: user '${name}' already exists.`, "err"); continue; }
      users[name] = { locked: false };
      savePersistentState();
      print(`Created user '${name}'.`, "ok");
    }
    else if (choice === 1) {
      const names = Object.keys(users);
      const idx = await menu("SWITCH TO USER", names, "\u2191\u2193 move, Enter to select, Esc to cancel");
      if (idx === null) continue;
      const name = names[idx];
      state.user = name;
      savePersistentState();
      print(`Now logged in as '${name}'.`, "ok");
    }
    else if (choice === 2) {
      const names = Object.keys(users).filter((n) => n !== "guest");
      if (!names.length) { print("No users available to rename.", "dim"); continue; }
      const idx = await menu("RENAME USER", names, "guest cannot be changed");
      if (idx === null) continue;
      const oldName = names[idx];
      const newName = await input(`Rename '${oldName}' to:`);
      if (newName === null) continue;
      if (!/^[A-Za-z0-9_]+$/.test(newName)) { print(`acswitch: '${newName}' is not a valid username.`, "err"); continue; }
      if (users[newName]) { print(`acswitch: user '${newName}' already exists.`, "err"); continue; }
      users[newName] = users[oldName];
      delete users[oldName];
      if (state.user === oldName) state.user = newName;
      savePersistentState();
      print(`Renamed '${oldName}' to '${newName}'.`, "ok");
    }
    else if (choice === 3) {
      const names = Object.keys(users).filter((n) => n !== "guest" && n !== state.user);
      if (!names.length) { print("No other users available to delete.", "dim"); continue; }
      const idx = await menu("DELETE USER", names, "guest cannot be deleted");
      if (idx === null) continue;
      const name = names[idx];
      const confirm = await menu(`DELETE '${name}'?`, ["Yes, delete", "Cancel"], "this cannot be undone");
      if (confirm === 0) {
        delete users[name];
        savePersistentState();
        print(`Deleted user '${name}'.`, "warn");
      }
    }
    else if (choice === 4) {
      state.user = "guest";
      savePersistentState();
      print("Now in guest account.", "ok");
    }
  }
};

commands.reboot = async (ctx) => {
  const { print, resetAll } = ctx;
  print("system rebooting...", "warn");
  await new Promise((r) => setTimeout(r, 400));
  if (resetAll) resetAll();
  print("reboot complete.", "ok");
};

commands.shutdown = async (ctx) => {
  const { print, resetAll } = ctx;
  print("system halted.", "warn");
  await new Promise((r) => setTimeout(r, 400));
  if (resetAll) resetAll();
  print("powered on.", "dim");
};

function fileNode(ctx, path) {
  return ctx.nodeAt(ctx.resolve(path));
}

function fileLines(node) {
  return node.content.replace(/\r/g, "").split("\n");
}

function recursiveSize(node) {
  if (node.type === "file") return node.content.length;
  return Object.values(node.children || {}).reduce((total, child) => total + recursiveSize(child), 0);
}

function printFileLines(ctx, lines) {
  ctx.print(lines.join("\n").replace(/\n$/, ""));
}

commands.ascii = async (ctx) => {
  const { args, print } = ctx;
  const text = args.join(" ");
  if (!text) { print("Usage: ascii TEXT", "err"); return; }
  print([...text].map((char) => `${char} ${char.charCodeAt(0)}`).join("\n"));
};

commands.upper = async (ctx) => ctx.print(ctx.args.join(" ").toUpperCase());
commands.lower = async (ctx) => ctx.print(ctx.args.join(" ").toLowerCase());
commands.trim = async (ctx) => ctx.print(ctx.args.join(" ").trim());

commands.words = async (ctx) => {
  const text = ctx.args.join(" ").trim();
  ctx.print(text ? String(text.split(/\s+/).length) : "0");
};

commands.lines = async (ctx) => {
  const text = ctx.args.join(" ");
  ctx.print(text ? String(text.split(/\r?\n/).length) : "0");
};

commands.repeat = async (ctx) => {
  const { args, print } = ctx;
  const count = Number.parseInt(args[0], 10);
  if (!Number.isInteger(count) || count < 0 || count > 1000 || !args.slice(1).length) {
    print("Usage: repeat COUNT TEXT", "err");
    return;
  }
  print(Array(count).fill(args.slice(1).join(" ")).join("\n"));
};

function showFileSlice(ctx, fromEnd) {
  const { args, print } = ctx;
  let count = 10;
  let path = args[0];
  if (/^\d+$/.test(args[0] || "")) {
    count = Number.parseInt(args[0], 10);
    path = args[1];
  }
  if (!path) { print(`Usage: ${fromEnd ? "tail" : "head"} [LINES] FILE`, "err"); return; }
  const node = fileNode(ctx, path);
  if (!node || node.type !== "file") { print(`File not found - ${path}`, "err"); return; }
  const lines = fileLines(node);
  printFileLines(ctx, fromEnd ? lines.slice(-count) : lines.slice(0, count));
}

commands.head = async (ctx) => showFileSlice(ctx, false);
commands.tail = async (ctx) => showFileSlice(ctx, true);

commands.wc = async (ctx) => {
  const { args, print } = ctx;
  let text = args.join(" ");
  if (args.length === 1) {
    const node = fileNode(ctx, args[0]);
    if (node && node.type === "file") text = node.content;
  }
  const lines = text ? text.replace(/\r/g, "").split("\n").length : 0;
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  print(`${lines} ${words} ${text.length}`);
};

function textOrFile(ctx, args) {
  if (args.length === 1) {
    const node = fileNode(ctx, args[0]);
    if (node && node.type === "file") return node.content;
  }
  return args.join(" ");
}

commands.sort = async (ctx) => {
  const lines = textOrFile(ctx, ctx.args).replace(/\r/g, "").split("\n").sort((a, b) => a.localeCompare(b));
  printFileLines(ctx, lines);
};

commands.uniq = async (ctx) => {
  const lines = textOrFile(ctx, ctx.args).replace(/\r/g, "").split("\n");
  printFileLines(ctx, lines.filter((line, index) => index === 0 || line !== lines[index - 1]));
};

commands.grep = async (ctx) => {
  const { args, print } = ctx;
  if (args.length < 2) { print("Usage: grep PATTERN FILE", "err"); return; }
  const pattern = args[0].toLowerCase();
  const paths = args.slice(1);
  for (const path of paths) {
    const node = fileNode(ctx, path);
    if (!node || node.type !== "file") { print(`grep: ${path}: file not found`, "err"); continue; }
    fileLines(node).forEach((line, index) => {
      if (line.toLowerCase().includes(pattern)) print(`${paths.length > 1 ? `${path}:` : ""}${index + 1}:${line}`);
    });
  }
};

commands.tr = async (ctx) => {
  const { args, print } = ctx;
  if (args.length < 3) { print("Usage: tr FROM TO TEXT", "err"); return; }
  const from = [...args[0]];
  const to = [...args[1]];
  const text = args.slice(2).join(" ");
  print([...text].map((char) => {
    const index = from.indexOf(char);
    return index < 0 ? char : (to[index] ?? "");
  }).join(""));
};

commands.cut = async (ctx) => {
  const { args, print } = ctx;
  const field = Number.parseInt(args[1], 10);
  if (args.length < 4 || !Number.isInteger(field) || field < 1) {
    print("Usage: cut DELIMITER FIELD TEXT", "err");
    return;
  }
  print(args.slice(2).join(" ").split(args[0])[field - 1] || "");
};

commands.replace = async (ctx) => {
  const { args, print } = ctx;
  if (args.length < 3) { print("Usage: replace OLD NEW TEXT", "err"); return; }
  print(args.slice(2).join(" ").split(args[0]).join(args[1]));
};

commands.append = async (ctx) => {
  const { args, print } = ctx;
  if (args.length < 2) { print("Usage: append FILE TEXT", "err"); return; }
  const path = args[0];
  const node = fileNode(ctx, path);
  if (node && node.type === "dir") { print(`append: ${path}: is a directory`, "err"); return; }
  writeFile(ctx, path, (node ? node.content : "") + args.slice(1).join(" "));
};

commands.write = async (ctx) => {
  const { args, print } = ctx;
  if (args.length < 2) { print("Usage: write FILE TEXT", "err"); return; }
  const node = fileNode(ctx, args[0]);
  if (node && node.type === "dir") { print(`write: ${args[0]}: is a directory`, "err"); return; }
  writeFile(ctx, args[0], args.slice(1).join(" "));
};

commands.truncate = async (ctx) => {
  const { args, print } = ctx;
  const length = Number.parseInt(args[1] || "0", 10);
  const node = args[0] && fileNode(ctx, args[0]);
  if (!args[0] || !Number.isInteger(length) || length < 0) { print("Usage: truncate FILE [BYTES]", "err"); return; }
  if (!node || node.type !== "file") { print(`truncate: ${args[0]}: file not found`, "err"); return; }
  node.content = node.content.slice(0, length).padEnd(length, " ");
};

commands.stat = async (ctx) => {
  const { args, print, display } = ctx;
  if (!args[0]) { print("Usage: stat PATH", "err"); return; }
  const node = fileNode(ctx, args[0]);
  if (!node) { print(`stat: ${args[0]}: not found`, "err"); return; }
  print(`  File: ${display(ctx.resolve(args[0]))}`);
  print(`  Type: ${node.type}`);
  print(`  Size: ${recursiveSize(node)} bytes`);
};

commands.file = async (ctx) => {
  const { args, print } = ctx;
  if (!args[0]) { print("Usage: file PATH", "err"); return; }
  const node = fileNode(ctx, args[0]);
  if (!node) { print(`${args[0]}: cannot open`, "err"); return; }
  print(`${args[0]}: ${node.type === "dir" ? "directory" : "ASCII text"}`);
};

commands.size = async (ctx) => {
  const { args, print } = ctx;
  if (!args[0]) { print("Usage: size PATH", "err"); return; }
  const node = fileNode(ctx, args[0]);
  if (!node) { print(`size: ${args[0]}: not found`, "err"); return; }
  print(`${recursiveSize(node)} bytes`);
};

commands.du = async (ctx) => {
  const { args, print, display } = ctx;
  const target = args[0] ? ctx.resolve(args[0]) : ctx.cwd;
  const node = ctx.nodeAt(target);
  if (!node) { print(`du: ${args[0] || target}: not found`, "err"); return; }
  print(`${recursiveSize(node)}\t${display(target)}`);
};

commands.locate = async (ctx) => {
  const { args, print, display } = ctx;
  if (!args[0]) { print("Usage: locate NAME [PATH]", "err"); return; }
  const needle = args[0].toLowerCase();
  const start = args[1] ? ctx.resolve(args[1]) : "/";
  const root = ctx.nodeAt(start);
  if (!root) { print(`locate: ${args[1]}: not found`, "err"); return; }
  const visit = (node, path) => {
    if (path.toLowerCase().includes(needle)) print(display(path));
    if (node.type === "dir") Object.entries(node.children).forEach(([name, child]) => visit(child, `${path === "/" ? "" : path}/${name}`));
  };
  visit(root, start);
};

commands.basename = async (ctx) => {
  const { args, print } = ctx;
  if (!args[0]) { print("Usage: basename PATH", "err"); return; }
  const parts = args[0].replaceAll("\\", "/").split("/").filter(Boolean);
  print(parts.pop() || "/");
};

commands.dirname = async (ctx) => {
  const { args, print } = ctx;
  if (!args[0]) { print("Usage: dirname PATH", "err"); return; }
  const path = args[0].replaceAll("\\", "/").replace(/\/+$/, "") || "/";
  const parts = path.split("/").filter(Boolean);
  parts.pop();
  print("/" + parts.join("/"));
};

commands.realpath = async (ctx) => {
  const { args, print } = ctx;
  if (!args[0]) { print("Usage: realpath PATH", "err"); return; }
  print(ctx.display(ctx.resolve(args[0])));
};

commands.pushd = async (ctx) => {
  const { args, print } = ctx;
  if (!args[0]) { print("Usage: pushd DIRECTORY", "err"); return; }
  const target = ctx.resolve(args[0]);
  const node = ctx.nodeAt(target);
  if (!node || node.type !== "dir") { print(`pushd: ${args[0]}: no such directory`, "err"); return; }
  ctx.state.dirStack = ctx.state.dirStack || [];
  ctx.state.dirStack.push(ctx.cwd);
  ctx.cwd = target;
  print(ctx.display(ctx.cwd));
};

commands.popd = async (ctx) => {
  const { print } = ctx;
  const stack = ctx.state.dirStack || [];
  if (!stack.length) { print("popd: directory stack empty", "err"); return; }
  ctx.cwd = stack.pop();
  print(ctx.display(ctx.cwd));
};

commands.dirs = async (ctx) => {
  const stack = ctx.state.dirStack || [];
  ctx.print([ctx.cwd, ...stack].map((path) => ctx.display(path)).join(" "));
};

commands.which = async (ctx) => {
  const { args, print, commands: registry } = ctx;
  if (!args[0]) { print("Usage: which COMMAND", "err"); return; }
  args.forEach((name) => print(registry[name.toLowerCase()] ? `C:\\DOS\\${name.toUpperCase()}.COM` : `${name}: not found`, registry[name.toLowerCase()] ? "" : "err"));
};

commands.where = async (ctx) => {
  const { args, print, commands: registry } = ctx;
  if (!args[0]) { print("Usage: where NAME", "err"); return; }
  args.forEach((name) => {
    const key = name.toLowerCase();
    if (registry[key]) print(`C:\\DOS\\${name.toUpperCase()}.COM`);
    else if (ctx.nodeAt(`/bin/${name}`)) print(`/bin/${name}`);
    else print(`${name}: no matches`, "err");
  });
};

commands.who = async (ctx) => {
  Object.keys(ctx.state.users).sort().forEach((name) => ctx.print(`${name}${name === ctx.state.user ? " *" : ""}`));
};

commands.id = async (ctx) => ctx.print(`uid=1000(${ctx.state.user}) gid=1000(users) groups=users`);
commands.tty = async (ctx) => ctx.print("/dev/console");

commands.ps = async (ctx) => {
  ctx.print("PID   USER    COMMAND");
  const rows = ctx.processSnapshot ? ctx.processSnapshot() : [];
  rows.forEach((row) => ctx.print(String(row.pid).padEnd(6) + row.session.padEnd(8) + row.name));
};

commands.tasklist = async (ctx) => {
  ctx.print("Image Name          PID   Session   Mem Usage");
  const rows = ctx.processSnapshot ? ctx.processSnapshot() : [];
  rows.forEach((row) => ctx.print(row.name.padEnd(20) + String(row.pid).padEnd(6) +
    row.session.padEnd(11) + row.memory));
};

commands.ping = async (ctx) => {
  const requestedHost = ctx.args[0];
  const host = requestedHost || "this NovaDOS project";
  if (!ctx.pingHost || (!requestedHost && !ctx.pingNetwork)) {
    ctx.print("ping: network probe is unavailable in this runtime.", "err");
    return;
  }
  ctx.print("Pinging " + host + " with 32 bytes of data:");
  const result = requestedHost ? await ctx.pingHost(requestedHost) : await ctx.pingNetwork();
  if (result.reachable) ctx.print("Reply from " + host + ": bytes=32 time=" + result.time + "ms protocol=" + result.protocol);
  else ctx.print("Request timed out for " + host + ".", "err");
  ctx.print("\nPing statistics: Sent = 1, Received = " + (result.reachable ? 1 : 0) +
    ", Lost = " + (result.reachable ? 0 : 1) + " (" + (result.reachable ? 0 : 100) + "% loss)");
  if (result.note) ctx.print(result.note, "dim");
};

commands.nslookup = async (ctx) => {
  const host = ctx.args[0] || "localhost";
  if (!ctx.lookupHost) {
    ctx.print("nslookup: DNS resolver is unavailable in this runtime.", "err");
    return;
  }
  const result = await ctx.lookupHost(host);
  if (!result.addresses.length) {
    ctx.print("*** Could not resolve " + host, "err");
    return;
  }
  ctx.print("Server:  " + result.server + "\n\nName:    " + host +
    "\nAddress: " + result.addresses.join("\nAddress: "));
};

commands.route = async (ctx) => {
  const info = ctx.networkInfo();
  ctx.print("Route table is not exposed by browser security policy.\n" +
    "Online: " + info.online + "\nConnection: " + info.type +
    "\nEffective link: " + info.effectiveType);
};

commands.diskfree = async (ctx) => {
  const estimate = ctx.storageEstimate ? await ctx.storageEstimate() : null;
  if (!estimate || !estimate.quota) {
    ctx.print("Storage quota is not exposed by this browser.", "err");
    return;
  }
  ctx.print("Drive C: " + Math.max(0, estimate.quota - estimate.usage) +
    " bytes free of " + estimate.quota + " bytes");
};

commands.label = async (ctx) => {
  if (!ctx.args.length) { ctx.print(ctx.state.volumeLabel || "Volume in drive C has no label."); return; }
  ctx.state.volumeLabel = ctx.args.join(" ");
  ctx.print(`Volume label set to '${ctx.state.volumeLabel}'.`, "ok");
};

commands.prompt = async (ctx) => {
  if (!ctx.args.length) { ctx.print(ctx.state.promptFormat || "$U@$H:$P$G"); return; }
  ctx.state.promptFormat = ctx.args.join(" ");
  ctx.print(`Prompt set to ${ctx.state.promptFormat}`, "ok");
};

commands.attrib = async (ctx) => {
  const { args, print, display } = ctx;
  const path = args.find((arg) => !/^[+-][A-Za-z]+$/.test(arg));
  if (!path) { print("Usage: attrib [+H|-H] PATH", "err"); return; }
  const node = fileNode(ctx, path);
  if (!node) { print(`attrib: ${path}: not found`, "err"); return; }
  node.attrs = node.attrs || {};
  args.filter((arg) => /^[+-][A-Za-z]+$/.test(arg)).forEach((flag) => {
    for (const attr of flag.slice(1).toUpperCase()) node.attrs[attr] = flag[0] === "+";
  });
  const flags = ["R", "H", "S", "A"].map((attr) => node.attrs[attr] ? attr : " ").join("");
  print(`${flags} ${display(ctx.resolve(path))}`);
};

commands.verify = async (ctx) => {
  if (!ctx.args.length) { ctx.print(`Verify is ${ctx.state.verify ? "on" : "off"}.`); return; }
  const value = ctx.args[0].toLowerCase();
  if (!["on", "off"].includes(value)) { ctx.print("Usage: verify [on|off]", "err"); return; }
  ctx.state.verify = value === "on";
  ctx.print(`Verify is ${value}.`);
};

commands.random = async (ctx) => {
  const { args, print } = ctx;
  const nums = args.map((arg) => Number.parseInt(arg, 10));
  if (nums.some(Number.isNaN) || nums.length > 2) { print("Usage: random [MAX] or random MIN MAX", "err"); return; }
  const min = nums.length === 2 ? nums[0] : 0;
  const max = nums.length === 2 ? nums[1] : (nums[0] ?? 100);
  if (min > max) { print("random: MIN must not exceed MAX", "err"); return; }
  print(String(Math.floor(Math.random() * (max - min + 1)) + min));
};

commands.uuid = async (ctx) => {
  const value = crypto.randomUUID ? crypto.randomUUID() : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    return (c === "x" ? r : (r & 3) | 8).toString(16);
  });
  ctx.print(value);
};

commands.checksum = async (ctx) => {
  const text = ctx.args.join(" ");
  let hash = 2166136261;
  for (const char of text) hash = Math.imul(hash ^ char.charCodeAt(0), 16777619);
  ctx.print((hash >>> 0).toString(16).padStart(8, "0"));
};

function divisor(a, b) {
  a = Math.abs(a); b = Math.abs(b);
  while (b) [a, b] = [b, a % b];
  return a;
}

commands.gcd = async (ctx) => {
  const nums = ctx.args.slice(0, 2).map((arg) => Number.parseInt(arg, 10));
  if (nums.length < 2 || nums.some(Number.isNaN)) { ctx.print("Usage: gcd A B", "err"); return; }
  ctx.print(String(divisor(nums[0], nums[1])));
};

commands.lcm = async (ctx) => {
  const nums = ctx.args.slice(0, 2).map((arg) => Number.parseInt(arg, 10));
  if (nums.length < 2 || nums.some(Number.isNaN)) { ctx.print("Usage: lcm A B", "err"); return; }
  const g = divisor(nums[0], nums[1]);
  ctx.print(String(g ? Math.abs(nums[0] * nums[1]) / g : 0));
};

const ENTERTAINMENT_LINES = {
  fortune: [
    "A clever idea is closer than it looks.",
    "Today is a good day to press Enter.",
    "The terminal rewards curious users.",
    "A small step will unlock a large door.",
  ],
  joke: [
    "Why did the computer get cold? It left a window open.",
    "I told my shell a joke. It returned a prompt.",
    "There are 10 kinds of people: those who understand binary and those who do not.",
  ],
  riddle: [
    "I have keys but no locks, space but no room. What am I? A keyboard.",
    "What has a face and two hands but no arms? A clock.",
    "What gets wetter as it dries? A towel.",
  ],
  quote: [
    "The best command is the one you enjoy running.",
    "Curiosity is a renewable power source.",
    "Every great journey begins with a working prompt.",
  ],
  haiku: [
    "Quiet green cursor\nWaiting beneath midnight rain\nA command takes flight",
    "Ancient disk whirs soft\nTiny sparks across the screen\nDawn inside the shell",
  ],
  limerick: [
    "There once was a shell full of cheer\nThat made every command crystal clear\nIt beeped with delight\nAll through the night\nAnd welcomed each curious ear.",
  ],
  poem: [
    "A blinking light\nA world of words\nOne little prompt\nAnd infinite birds",
  ],
  trivia: [
    "Trivia: The first computer mouse was made of wood.",
    "Trivia: A group of flamingos is called a flamboyance.",
    "Trivia: Bananas are berries, botanically speaking.",
  ],
  quiz: [
    "Quiz: Which command lists files? Answer: DIR.",
    "Quiz: What does CPU stand for? Answer: Central Processing Unit.",
  ],
  compliment: [
    "Your command-line instincts are impeccable.",
    "You make even plain text look stylish.",
    "That was an excellent use of a terminal.",
  ],
  roast: [
    "Your command history has the confidence of a blank file.",
    "I have seen faster typing from a loading spinner.",
    "Your syntax is adventurous. The error messages are taking notes.",
  ],
  horoscope: [
    "The stars align: a lucky alias is in your future.",
    "Mercury favors concise commands and forgiving typos.",
    "Your cosmic path leads directly to a useful directory.",
  ],
};

const entertainmentPick = (items) => items[Math.floor(Math.random() * items.length)];

function runEntertainment(name, ctx) {
  const { args, print } = ctx;
  if (ENTERTAINMENT_LINES[name]) { print(entertainmentPick(ENTERTAINMENT_LINES[name])); return; }
  if (name === "dice") { print(String(Math.floor(Math.random() * 6) + 1)); return; }
  if (name === "coin") { print(Math.random() < 0.5 ? "Heads" : "Tails"); return; }
  if (name === "eightball") {
    print(entertainmentPick(["Yes.", "No.", "Ask again later.", "Absolutely.", "The terminal says maybe."]));
    return;
  }
  if (name === "choose") {
    const choices = args.join(" ").split("|").map((item) => item.trim()).filter(Boolean);
    print(choices.length ? entertainmentPick(choices) : "Usage: choose FIRST | SECOND | ...", choices.length ? "" : "err");
    return;
  }
  if (name === "roll") {
    const match = (args[0] || "1d6").toLowerCase().match(/^(\d+)d(\d+)$/);
    if (!match) { print("Usage: roll NdM", "err"); return; }
    const count = Math.min(Number(match[1]), 50);
    const sides = Number(match[2]);
    if (!sides || sides > 10000) { print("roll: invalid die", "err"); return; }
    const rolls = Array.from({ length: count }, () => Math.floor(Math.random() * sides) + 1);
    print(`${rolls.join(" ")} (total ${rolls.reduce((a, b) => a + b, 0)})`);
    return;
  }
  if (name === "slot") {
    const symbols = ["7", "★", "◆", "●", "🍒"];
    const row = Array.from({ length: 3 }, () => entertainmentPick(symbols));
    print(`[ ${row.join(" | ")} ]${row.every((item) => item === row[0]) ? " JACKPOT!" : ""}`);
    return;
  }
  if (name === "anagram" || name === "scramble") {
    const text = args.join(" ");
    const chars = [...text];
    for (let i = chars.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [chars[i], chars[j]] = [chars[j], chars[i]];
    }
    print(text ? chars.join("") : `Usage: ${name} TEXT`, text ? "" : "err");
    return;
  }
  if (name === "palindrome") {
    const text = args.join(" ").toLowerCase().replace(/[^a-z0-9]/g, "");
    print(text && text === [...text].reverse().join("") ? "Palindrome!" : "Not a palindrome.");
    return;
  }
  if (name === "fizzbuzz") {
    const end = Math.min(Math.max(Number.parseInt(args[0] || "15", 10), 1), 100);
    if (Number.isNaN(end)) { print("Usage: fizzbuzz [END]", "err"); return; }
    print(Array.from({ length: end }, (_, index) => {
      const n = index + 1;
      return n % 15 === 0 ? "FizzBuzz" : n % 3 === 0 ? "Fizz" : n % 5 === 0 ? "Buzz" : String(n);
    }).join(" "));
    return;
  }
  if (name === "countdown") {
    const end = Number.parseInt(args[0] || "5", 10);
    if (!Number.isInteger(end) || end < 1 || end > 20) { print("Usage: countdown [1-20]", "err"); return; }
    print(`${Array.from({ length: end }, (_, index) => end - index).join(" ")} GO!`);
    return;
  }
  if (name === "madlib") {
    const [adjective = "brilliant", noun = "robot", verb = "dance"] = args;
    print(`The ${adjective} ${noun} decided to ${verb} across the moon.`);
    return;
  }
  if (name === "emoji") { print(entertainmentPick(["🚀 ✨ 🖥️", "🌈 🐙 🎉", "☕ ⚡ 🧠", "🎲 🪩 🛸"])); return; }
  if (name === "rainbow") { print("🔴 🟠 🟡 🟢 🔵 🟣"); return; }
  if (name === "matrix") {
    print(Array.from({ length: 5 }, () => Array.from({ length: 24 }, () => Math.random() > 0.55 ? "1" : "0").join(" ")).join("\n"));
    return;
  }
  if (name === "glitch") {
    const text = args.join(" ") || "NOVA DOS";
    print([...text].map((char) => Math.random() > 0.8 ? entertainmentPick(["░", "▒", "▓", "█"]) : char).join(""));
    return;
  }
  if (name === "mirror") { print(args.join(" ").split("").reverse().join("") || "Usage: mirror TEXT"); return; }
  if (name === "pyramid") {
    const height = Math.min(Math.max(Number.parseInt(args[0] || "5", 10), 1), 20);
    print(Array.from({ length: height }, (_, index) => " ".repeat(height - index - 1) + "*".repeat(index * 2 + 1)).join("\n"));
    return;
  }
  if (name === "box") {
    const text = args.join(" ") || "NOVA";
    print(`+${"-".repeat(text.length + 2)}+\n| ${text} |\n+${"-".repeat(text.length + 2)}+`);
    return;
  }
  if (name === "wave") { print("~\\~/\\~/\\~/\\~"); return; }
  if (name === "dance") { print("(ง •̀_•́)ง   (ง'̀-'́)ง   (ง •̀_•́)ง"); return; }
  if (name === "spinner") { print("| / - \\"); return; }
  if (name === "progress") { print("[##########] 100%"); return; }
  if (name === "applause") { print("👏 ".repeat(8).trim()); return; }
  if (name === "drumroll") { print("🥁 ... ... ... ta-da!"); return; }
  if (name === "asciiart") { print(" /\\_/\\\n( o.o )\n > ^ <"); return; }
  if (name === "christmas") { print("    *\n   /\\\n  /__\\\n /____\\\n   ||"); return; }
  if (name === "halloween") { print(" .-.___.-.\n/  o   o  \\\n|    ^    |\n|  '-'   |"); return; }
  if (name === "birthday") { print("  .------.\n / Happy  \\\n| Birthday |\n|__________|"); return; }
  if (name === "roulette") { const n = Math.floor(Math.random() * 37); print(`${n} - ${n === 0 ? "green" : n % 2 ? "red" : "black"}`); return; }
  if (name === "lucky") { print(entertainmentPick(["🍀 Very lucky!", "✨ Lucky enough!", "🌟 The odds are smiling.", "🎯 Try one more time!"])); return; }
  if (name === "pet") { print(`Nova the terminal pet says: ${entertainmentPick(["*boop*", "purrr...", "woof!", "feed me pixels!"])}`); return; }
  if (name === "chant") { print("NO-VA! NO-VA! TYPE IT LOUD! "); return; }
  if (name === "clap") { print("clap - clap - clap clap clap"); return; }
  if (name === "beat") { print("dum   tik   dum-dum   tik"); return; }
}

for (const { n } of ENTERTAINMENT_COMMANDS) {
  commands[n] = async (ctx) => runEntertainment(n, ctx);
}

/*
 * The catalog is intentionally large, but it must not be a list of decorative
 * aliases.  Every catalog entry routes through this small command engine.  A
 * command name supplies the operation and the data type, while the normal
 * terminal arguments supply files, text, and destinations.  That keeps the
 * 500+ generated commands useful without maintaining hundreds of almost
 * identical functions.
 */
function catalogArgs(ctx) {
  return ctx.args.filter((arg) => !/^--?(?:out|output|key|format)=/.test(arg));
}

function catalogTarget(ctx, args = catalogArgs(ctx)) {
  const candidate = args.find((arg) => fileNode(ctx, arg));
  return candidate || ctx.cwd;
}

function catalogText(ctx, args = catalogArgs(ctx)) {
  const candidate = args.find((arg) => fileNode(ctx, arg));
  const node = candidate ? fileNode(ctx, candidate) : null;
  if (node?.type === "file") return node.content;
  return args.filter((arg) => arg !== candidate).join(" ");
}

function catalogOutputPath(ctx, verb, noun) {
  const args = ctx.args;
  const index = args.findIndex((arg) => arg === "-o" || arg === "--out" || arg === "--output");
  const inline = args.find((arg) => /^(?:--out|--output)=/.test(arg));
  const explicit = inline ? inline.split("=").slice(1).join("=") : index >= 0 ? args[index + 1] : "";
  if (explicit) return ctx.resolve(explicit);
  return `/tmp/${verb}-${noun}.txt`;
}

function catalogWrite(ctx, path, content, label = "output") {
  const target = path || "/tmp/catalog-output.txt";
  writeFile(ctx, target, String(content));
  ctx.print(`${label}: ${ctx.display(ctx.resolve(target))} (${String(content).length} bytes)`, "ok");
  return ctx.resolve(target);
}

function catalogLines(text) {
  return String(text ?? "").replace(/\r/g, "").split("\n");
}

function catalogRleEncode(text) {
  const chars = [...String(text)];
  if (!chars.length) return "";
  const output = [];
  let run = chars[0];
  let count = 1;
  for (let i = 1; i <= chars.length; i++) {
    if (chars[i] === run && count < 9999) count++;
    else {
      output.push(`${count}:${run === "\n" ? "\\n" : run}`);
      run = chars[i];
      count = 1;
    }
  }
  return output.join("|");
}

function catalogRleDecode(text) {
  return String(text).split("|").map((part) => {
    const split = part.indexOf(":");
    if (split < 1) return part;
    const count = Number.parseInt(part.slice(0, split), 10);
    const value = part.slice(split + 1);
    return Number.isFinite(count) ? value.replace(/^\\n$/, "\n").repeat(Math.min(count, 100000)) : part;
  }).join("");
}

function catalogXor(text, key) {
  const secret = String(key || "nova");
  return [...String(text)].map((char, index) => String.fromCharCode(char.charCodeAt(0) ^ secret.charCodeAt(index % secret.length))).join("");
}

function catalogTreeEntries(node, path, entries = []) {
  if (!node) return entries;
  if (node.type === "file") {
    entries.push({ path, type: "file", bytes: node.content.length });
    return entries;
  }
  entries.push({ path, type: "dir", bytes: recursiveSize(node) });
  Object.entries(node.children || {}).sort(([a], [b]) => a.localeCompare(b))
    .forEach(([name, child]) => catalogTreeEntries(child, `${path}/${name}`.replace(/\\+/g, "/"), entries));
  return entries;
}

function catalogMetadata(ctx, path, node) {
  const entries = catalogTreeEntries(node, path);
  const files = entries.filter((entry) => entry.type === "file");
  return {
    path,
    type: node.type,
    bytes: recursiveSize(node),
    files: files.length,
    directories: entries.filter((entry) => entry.type === "dir").length,
    modified: new Date().toISOString(),
  };
}

async function runCatalogCommand(verb, noun, ctx) {
  const args = catalogArgs(ctx);
  const target = catalogTarget(ctx, args);
  const resolved = ctx.resolve(target);
  const node = ctx.nodeAt(resolved);
  const text = catalogText(ctx, args);
  const keyArg = ctx.args.find((arg) => /^(?:--key=)/.test(arg));
  const key = keyArg ? keyArg.slice(keyArg.indexOf("=") + 1) : args[1] || noun;
  const out = catalogOutputPath(ctx, verb, noun);
  const print = (value, cls) => ctx.print(String(value), cls);

  switch (verb) {
    case "archive":
    case "backup": {
      if (!node) { print(`${verb}: ${target}: not found`, "err"); return; }
      const manifest = catalogTreeEntries(node, resolved).map((entry) => JSON.stringify(entry)).join("\n");
      const body = `${verb.toUpperCase()} NOVA ARCHIVE\n${manifest}\n\n${node.type === "file" ? node.content : ""}`;
      catalogWrite(ctx, out, body, `${verb} complete`);
      return;
    }
    case "benchmark": {
      const started = performance.now();
      let checksum = 0;
      for (let i = 0; i < Math.max(1000, text.length * 100); i++) checksum = (checksum + i + text.charCodeAt(i % Math.max(1, text.length))) >>> 0;
      print(`${verb}-${noun}: ${checksum} in ${(performance.now() - started).toFixed(2)}ms`);
      return;
    }
    case "bind": {
      const assignment = ctx.args.join(" ").match(/^([A-Za-z_][\w]*)=(.*)$/);
      if (assignment) ctx.env[assignment[1]] = assignment[2];
      print(assignment ? `bound ${assignment[1]}=${assignment[2]}` : `${noun} binding: ${ctx.env[noun.toUpperCase()] || "unbound"}`, assignment ? "ok" : "dim");
      return;
    }
    case "cache": {
      const cachePath = `/tmp/.nova-cache-${noun}.txt`;
      if (text) catalogWrite(ctx, cachePath, text, "cache updated");
      else print(ctx.nodeAt(cachePath)?.content || `cache ${noun}: empty`);
      return;
    }
    case "check":
    case "validate": {
      const checks = [];
      if (!node) checks.push("target does not exist");
      if (node?.type === "file" && !node.content.length) checks.push("file is empty");
      if (node?.type === "file" && noun === "data") {
        try { JSON.parse(node.content); } catch { checks.push("data is not valid JSON"); }
      }
      print(checks.length ? `${verb}: ${checks.join("; ")}` : `${verb}: ${ctx.display(resolved)} is valid`, checks.length ? "warn" : "ok");
      return;
    }
    case "compile": {
      const source = text || `// generated ${noun} program\n`;
      const compiled = `NOVA-${noun.toUpperCase()} BYTECODE\nSOURCE_BYTES=${source.length}\n${source}`;
      catalogWrite(ctx, out.replace(/\.txt$/, ".novdos"), compiled, "compiled");
      return;
    }
    case "compare": {
      const paths = args.filter((arg) => fileNode(ctx, arg)?.type === "file").slice(0, 2);
      const left = paths[0] ? fileNode(ctx, paths[0]).content : text;
      const right = paths[1] ? fileNode(ctx, paths[1]).content : args.slice(1).join(" ");
      print(left === right ? "identical" : `different (${left.length} vs ${right.length} bytes)`);
      if (left !== right) print(`first difference at byte ${[...left].findIndex((char, i) => char !== right[i])}`);
      return;
    }
    case "compress": {
      catalogWrite(ctx, out, catalogRleEncode(text), "compressed");
      return;
    }
    case "decompress": {
      print(catalogRleDecode(text));
      return;
    }
    case "encode":
      print(btoa(unescape(encodeURIComponent(text))));
      return;
    case "decode": {
      try { print(decodeURIComponent(escape(atob(text)))); } catch { print("decode: input is not valid base64 text", "err"); }
      return;
    }
    case "encrypt":
      print([...catalogXor(text, key)].map((char) => char.charCodeAt(0).toString(16).padStart(2, "0")).join(""));
      return;
    case "decrypt": {
      const bytes = text.replace(/\s/g, "").match(/[0-9a-f]{2}/gi);
      if (!bytes || bytes.length * 2 !== text.replace(/\s/g, "").length) { print("decrypt: expected hexadecimal ciphertext", "err"); return; }
      print(catalogXor(bytes.map((byte) => String.fromCharCode(Number.parseInt(byte, 16))).join(""), key));
      return;
    }
    case "convert":
    case "normalize":
    case "transform":
    case "recode": {
      const converted = verb === "normalize" ? text.replace(/\s+/g, " ").trim() : verb === "recode" ? text.replace(/\r?\n/g, "\r\n") : noun === "text" ? text.toUpperCase() : text;
      catalogWrite(ctx, out, converted, `${verb} complete`);
      return;
    }
    case "describe":
    case "inspect":
    case "stat": {
      if (!node) { print(`${verb}: ${target}: not found`, "err"); return; }
      print(JSON.stringify(catalogMetadata(ctx, resolved, node), null, 2));
      if (node.type === "file") print(node.content.slice(0, 240).replace(/\n/g, "\\n"));
      return;
    }
    case "detect": {
      const sample = text.trim();
      const type = !sample ? "empty" : /^\s*[\[{]/.test(sample) ? "json" : /^<[^>]+>/.test(sample) ? "markup" : /^[0-9a-f]+$/i.test(sample) ? "hexadecimal" : "plain text";
      print(`${noun}: ${type}`);
      return;
    }
    case "export":
    case "serialize": {
      const payload = JSON.stringify({ command: `${verb}-${noun}`, target: resolved, data: text, env: ctx.env }, null, 2);
      catalogWrite(ctx, out, payload, `${verb} complete`);
      return;
    }
    case "extract": {
      const match = text.match(/(?:^|\n)\\s*([^:=]+)[:=]\\s*(.*?)(?=\\n|$)/g) || [];
      print(match.length ? match.map((line) => line.trim()).join("\n") : text);
      return;
    }
    case "filter": {
      const pattern = args.find((arg) => arg !== target) || noun;
      print(catalogLines(text).filter((line) => line.toLowerCase().includes(pattern.toLowerCase())).join("\n"));
      return;
    }
    case "format": {
      const formatted = catalogLines(text).map((line, index) => `${String(index + 1).padStart(3, "0")} | ${line}`).join("\n");
      catalogWrite(ctx, out, formatted, "formatted");
      return;
    }
    case "generate": {
      const generated = `# Generated ${noun}\ncreated=${new Date().toISOString()}\n${args.join(" ") || "Nova DOS"}\n`;
      catalogWrite(ctx, out, generated, "generated");
      return;
    }
    case "import": {
      if (!node || node.type !== "file") { print(`import: ${target}: file not found`, "err"); return; }
      ctx.env[`IMPORT_${noun.toUpperCase()}`] = node.content;
      print(`imported ${node.content.length} bytes into IMPORT_${noun.toUpperCase()}`, "ok");
      return;
    }
    case "index": {
      const words = [...new Set(text.toLowerCase().match(/[a-z0-9_]+/g) || [])].sort();
      catalogWrite(ctx, out, words.join("\n"), "index built");
      return;
    }
    case "install": {
      const manifest = `NOVA PACKAGE\nname=${noun}\ninstalled=${new Date().toISOString()}\n`;
      catalogWrite(ctx, `/bin/${noun}.pkg`, manifest, "installed");
      return;
    }
    case "merge": {
      const sources = args.filter((arg) => fileNode(ctx, arg)?.type === "file");
      const merged = (sources.length ? sources.map((path) => fileNode(ctx, path).content) : [text]).join("\n");
      catalogWrite(ctx, out, merged, "merged");
      return;
    }
    case "migrate":
    case "clone":
    case "sync": {
      if (!node) { print(`${verb}: ${target}: not found`, "err"); return; }
      const destination = ctx.args.find((arg) => arg !== target && !arg.startsWith("-")) || out;
      if (node.type === "file") writeFile(ctx, destination, node.content, { migratedFrom: resolved });
      else writeFile(ctx, `${destination}/.nova-manifest`, JSON.stringify(catalogMetadata(ctx, resolved, node), null, 2));
      print(`${verb}: ${ctx.display(ctx.resolve(destination))}`, "ok");
      return;
    }
    case "monitor":
      print(`monitoring ${ctx.display(resolved)}: ${node ? `${recursiveSize(node)} bytes` : "missing"}; uptime ${Math.floor((Date.now() - ctx.startTime) / 1000)}s`);
      return;
    case "mount": {
      ctx.state.mounts = ctx.state.mounts || {};
      ctx.state.mounts[noun] = target;
      print(`mounted ${target} as ${noun}`, "ok");
      return;
    }
    case "parse": {
      try { print(JSON.stringify(JSON.parse(text), null, 2)); }
      catch { print(text.split(/[,&]/).map((part) => part.trim()).filter(Boolean).join("\n")); }
      return;
    }
    case "patch": {
      if (!node || node.type !== "file") { print(`patch: ${target}: file not found`, "err"); return; }
      const patchText = args.filter((arg) => arg !== target).join(" ") || `patched ${new Date().toISOString()}`;
      node.content += `${node.content.endsWith("\n") ? "" : "\n"}${patchText}\n`;
      print(`patched ${resolved}`, "ok");
      return;
    }
    case "publish":
    case "deploy": {
      if (!node) { print(`${verb}: ${target}: not found`, "err"); return; }
      const destination = `/var/${verb}/${noun}`;
      const body = node.type === "file" ? node.content : JSON.stringify(catalogMetadata(ctx, resolved, node), null, 2);
      catalogWrite(ctx, destination, body, `${verb}ed`);
      return;
    }
    case "query":
    case "search": {
      const needle = args.find((arg) => arg !== target) || noun;
      const hits = [];
      catalogTreeEntries(ctx.fs, "").forEach((entry) => {
        const item = fileNode(ctx, entry.path || "/");
        if (item?.type === "file" && (entry.path.toLowerCase().includes(needle.toLowerCase()) || item.content.toLowerCase().includes(needle.toLowerCase()))) hits.push(entry.path);
      });
      print(hits.length ? hits.join("\n") : `${verb}: no matches for ${needle}`);
      return;
    }
    case "rebuild":
    case "refresh": {
      const manifest = JSON.stringify({ refreshed: new Date().toISOString(), target: resolved, bytes: node ? recursiveSize(node) : 0 }, null, 2);
      catalogWrite(ctx, out, manifest, `${verb} complete`);
      return;
    }
    case "render":
    case "view": {
      if (!node) { print(`${verb}: ${target}: not found`, "err"); return; }
      if (node.type === "dir") print(Object.keys(node.children).sort().join("\n"));
      else print(node.content.replace(/[#*_`]/g, "").replace(/\n$/, ""));
      return;
    }
    case "report":
    case "audit": {
      const report = catalogMetadata(ctx, resolved, node || { type: "dir", children: {} });
      report.status = node ? "pass" : "missing";
      report.security = ctx.scanPath ? ctx.scanPath(target) : { threats: [] };
      print(JSON.stringify(report, null, 2), node ? "ok" : "warn");
      return;
    }
    case "restore": {
      const backup = fileNode(ctx, `${target}.bak`) || fileNode(ctx, `/tmp/backup-${noun}.txt`);
      if (!backup || backup.type !== "file") { print(`restore: no backup found for ${target}`, "err"); return; }
      catalogWrite(ctx, target, backup.content, "restored");
      return;
    }
    case "scan": {
      const result = ctx.scanPath ? ctx.scanPath(target) : { found: Boolean(node), threats: [] };
      print(!result.found ? `${verb}: ${target}: not found` : result.threats.length ? `${result.threats.length} threat(s) found` : `${target}: clean`, result.threats.length ? "warn" : "ok");
      return;
    }
    case "split": {
      const size = Math.max(1, Number.parseInt(args.find((arg) => /^\d+$/.test(arg)) || "80", 10));
      const parts = [];
      for (let i = 0; i < text.length; i += size) parts.push(text.slice(i, i + size));
      parts.forEach((part, index) => writeFile(ctx, `${out.replace(/\.txt$/, "")}.${index + 1}`, part));
      print(`split into ${parts.length} part(s)`, "ok");
      return;
    }
    case "clean": {
      const cleaned = catalogLines(text).filter((line) => line.trim()).join("\n");
      catalogWrite(ctx, out, cleaned, "cleaned");
      return;
    }
    default:
      print(`${verb}-${noun}: processed ${text.length} bytes`);
  }
}

for (const { n } of CATALOG_COMMANDS) {
  commands[n] = async (ctx) => {
    const [verb, noun] = n.split("-");
    await runCatalogCommand(verb, noun, ctx);
  };
}

// DOS command names. The older Unix-style implementations above are kept
// as small internal building blocks, but only the DOS vocabulary is exposed.
commands.ver = commands.version;
commands.cls = commands.clear;
commands.md = commands.mkdir;
commands.rd = commands.rmdir;
commands.type = async (ctx) => {
  const { args, print, nodeAt, resolve } = ctx;
  if (!args[0]) { print("The syntax of the command is incorrect.", "err"); return; }
  const node = nodeAt(resolve(args[0]));
  if (!node || node.type !== "file") { print("File not found.", "err"); return; }
  print(node.content.replace(/\n$/, ""));
};
commands.copy = commands.cp;
commands.move = commands.mv;
commands.ren = commands.mv;
commands.del = commands.rm;
commands.delete = commands.rm;
commands["cd\\"] = async (ctx) => { ctx.cwd = "/"; };
commands.ls = commands.dir;

// Keep the command surface focused on the DOS utility set above.
for (const name of Object.keys(commands)) {
  if (!COMMANDS.some((command) => command.n === name)) delete commands[name];
}
