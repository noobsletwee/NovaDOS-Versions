const DB_NAME = "novados-indexedpfs";
const DB_VERSION = 1;
const META_STORE = "meta";
const STATE_FILE = ".novados/state.enc";

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(META_STORE)) db.createObjectStore(META_STORE);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("IndexedPFS metadata database could not be opened."));
  });
}

function idbRequest(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("IndexedPFS metadata request failed."));
  });
}

async function getMeta(db, key) {
  return idbRequest(db.transaction(META_STORE, "readonly").objectStore(META_STORE).get(key));
}

async function putMeta(db, key, value) {
  return idbRequest(db.transaction(META_STORE, "readwrite").objectStore(META_STORE).put(value, key));
}

async function getRoot() {
  if (!navigator.storage?.getDirectory) throw new Error("Origin Private File System is unavailable in this browser.");
  return navigator.storage.getDirectory();
}

async function getStateHandle(root, create = false) {
  const parts = STATE_FILE.split("/");
  let directory = root;
  for (const part of parts.slice(0, -1)) directory = await directory.getDirectoryHandle(part, { create });
  return directory.getFileHandle(parts.at(-1), { create });
}

async function makeKey(db) {
  let key = await getMeta(db, "encryption-key");
  if (!key) {
    key = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
    await putMeta(db, "encryption-key", key);
  }
  return key;
}

async function encryptJson(key, value) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encoded = new TextEncoder().encode(JSON.stringify(value));
  const ciphertext = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, encoded));
  const packet = new Uint8Array(iv.length + ciphertext.length);
  packet.set(iv, 0);
  packet.set(ciphertext, iv.length);
  return packet;
}

async function decryptJson(key, bytes) {
  const iv = bytes.slice(0, 12);
  const ciphertext = bytes.slice(12);
  const plaintext = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, ciphertext);
  return JSON.parse(new TextDecoder().decode(plaintext));
}

export class IndexedPFS {
  constructor(name = "novados") {
    this.name = name;
    this.dbPromise = null;
    this.keyPromise = null;
  }

  async database() {
    if (!this.dbPromise) this.dbPromise = openDatabase();
    return this.dbPromise;
  }

  async key() {
    if (!this.keyPromise) this.keyPromise = this.database().then(makeKey);
    return this.keyPromise;
  }

  async saveJson(value) {
    const [root, key, db] = await Promise.all([getRoot(), this.key(), this.database()]);
    const packet = await encryptJson(key, value);
    const handle = await getStateHandle(root, true);
    const writable = await handle.createWritable();
    try {
      await writable.write(packet);
    } finally {
      await writable.close();
    }
    await putMeta(db, "state-index", {
      path: STATE_FILE,
      bytes: packet.byteLength,
      encrypted: true,
      updatedAt: new Date().toISOString(),
    });
  }

  async loadJson() {
    const root = await getRoot();
    let handle;
    try {
      handle = await getStateHandle(root, false);
    } catch (error) {
      if (error?.name === "NotFoundError") return null;
      throw error;
    }
    const bytes = new Uint8Array(await (await handle.getFile()).arrayBuffer());
    return decryptJson(await this.key(), bytes);
  }

  async info() {
    const db = await this.database();
    await this.key();
    const index = await getMeta(db, "state-index");
    return {
      type: "IndexedPFS",
      backing: "Origin Private File System",
      index: "IndexedDB",
      encrypted: Boolean(index?.encrypted ?? true),
      bytes: index?.bytes || 0,
      updatedAt: index?.updatedAt || null,
    };
  }
}
