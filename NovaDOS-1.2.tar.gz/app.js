import { commands, helpText, VERSION } from "./commands.js";
import { IndexedPFS } from "./indexedpfs.js";
import { createWasmKernel } from "./wasm-kernel.js";
import { runX86Com } from "./x86-16.js";

const term = document.getElementById("term");

let history = [];
let historyIdx = -1;
let output = [];
let buffer = "";
let cursor = 0;

const startTime = Date.now();

const state = {
  user: "user",
  host: "novados",
  version: "1.2",
  ventsVersion: "1.0",
  users: { guest: { locked: true }, user: { locked: false } },
};

const fs = makeFS();
let cwd = "/";

const HOME = () => "/home/user";
const env = { HOME: HOME(), PATH: "C:\\DOS;C:\\BIN" };
const OPFS_STATE_FILE = "novados-state.json";
const RELEASE_STATE = "1.2";
let persistentStateReady = Promise.resolve();
let persistentWriteQueue = Promise.resolve();
const indexedPFS = new IndexedPFS("novados");
const wasmKernelReady = createWasmKernel();

const CODE_LANGUAGES = Object.freeze({
  javascript: { label: "JavaScript", extensions: ["js", "jsx", "mjs", "cjs", "ts", "tsx"], defaultExtension: ".js", runnable: true },
  python: { label: "Python", extensions: ["py"], defaultExtension: ".py", runnable: true },
  html: { label: "HTML", extensions: ["html", "htm"], defaultExtension: ".html", runnable: true },
  css: { label: "CSS", extensions: ["css"], defaultExtension: ".css", runnable: true },
  c: { label: "C", extensions: ["c", "h"], defaultExtension: ".c", runnable: true },
  rust: { label: "Rust", extensions: ["rs"], defaultExtension: ".rs", runnable: true },
  cpp: { label: "C++", extensions: ["cpp", "cc", "cxx", "c++", "hpp", "hh", "hxx", "h++"], defaultExtension: ".cpp", runnable: true },
  assembly: { label: "Assembly", extensions: ["asm", "s", "S"], defaultExtension: ".asm", runnable: true },
  wasm: { label: "WebAssembly", extensions: ["wasm", "wat"], defaultExtension: ".wasm", runnable: true },
  cython: { label: "Cython", extensions: ["pyx"], defaultExtension: ".pyx", runnable: true },
  cpython: { label: "CPython", extensions: ["cpy"], defaultExtension: ".cpy", runnable: true },
});
const CODE_SOURCE_EXTENSIONS = new Set(Object.values(CODE_LANGUAGES).flatMap(({ extensions }) => extensions));
const COMPILER_EXPLORER_COMPILERS = Object.freeze({ c: "cg162", cpp: "g162", assembly: "llvmas2110" });

const CODE_STARTERS = Object.freeze({
  javascript: `console.log("Hello from Nova Code");`,
  python: `print("Hello from Nova Code")`,
  html: `<main class="card">\n  <h1>Hello, Nova</h1>\n  <p>Edit this page, then press Run.</p>\n</main>`,
  css: `body {\n  font-family: sans-serif;\n  color: #111936;\n  background: #f7d36a;\n}\n.card {\n  margin: 3rem auto;\n  max-width: 28rem;\n  padding: 2rem;\n  background: white;\n}`,
  c: `#include <stdio.h>\n\nint main(void) {\n    printf("Hello from Nova Code\\n");\n    return 0;\n}`,
  rust: `fn main() {\n    println!("Hello from Nova Code");\n}`,
  cpp: `#include <iostream>\n\nint main() {\n    std::cout << "Hello from Nova Code\\n";\n}`,
  assembly: `.text\n.global main\nmain:\n  mov $42, %eax\n  ret`,
  wasm: `(module\n  (func (export "main") (result i32)\n    i32.const 42))`,
});

function codeLanguageForPath(path) {
  const extension = String(path).split(".").pop().toLowerCase();
  return Object.entries(CODE_LANGUAGES).find(([, language]) => language.extensions.includes(extension))?.[0] || "javascript";
}

function pathParts(path) {
  const target = resolve(path);
  const parts = target.split("/").filter(Boolean);
  const filename = parts.pop() || "program";
  return { directory: `/${parts.join("/")}`.replace(/\/+/g, "/") || "/", filename };
}

function uniqueSourcePath(path) {
  const target = resolve(path);
  if (!nodeAt(target)) return target;
  const { directory, filename } = pathParts(target);
  const dot = filename.lastIndexOf(".");
  const stem = dot > 0 ? filename.slice(0, dot) : filename;
  const extension = dot > 0 ? filename.slice(dot) : "";
  let index = 1;
  let candidate = `${directory}/${stem} (${index})${extension}`.replace(/\/+/g, "/");
  while (nodeAt(candidate)) {
    index++;
    candidate = `${directory}/${stem} (${index})${extension}`.replace(/\/+/g, "/");
  }
  return candidate;
}

function sourcePathForLanguage(path, languageKey, avoidExisting = false) {
  const language = CODE_LANGUAGES[languageKey] || CODE_LANGUAGES.javascript;
  const { directory, filename } = pathParts(path || `${HOME()}/program`);
  const dot = filename.lastIndexOf(".");
  const stem = (dot > 0 ? filename.slice(0, dot) : filename) || "program";
  const candidate = `${directory}/${stem}${language.defaultExtension}`.replace(/\/+/g, "/");
  return avoidExisting ? uniqueSourcePath(candidate) : candidate;
}

function isComFile(path) {
  return String(path).split(".").pop().toLowerCase() === "com";
}

function isNovdosFile(path) {
  return String(path).split(".").pop().toLowerCase() === "novdos";
}

function isVntFile(path) {
  return String(path).split(".").pop().toLowerCase() === "vnt";
}

function isDosProgramFile(path) {
  return isComFile(path) || isNovdosFile(path) || isVntFile(path);
}

const NOVA_RELEASES = Object.freeze({
  "1.2": { build: 34, label: "NovaDOS 1.2", next: null, previous: null },
});
const RELEASE_ORDER = Object.keys(NOVA_RELEASES);
const COMMAND_UNAVAILABLE_IN_1_0 = new Set([
  "seccheck",
]);
const COMMAND_ALLOWED = Object.freeze({});

function normalizeVersion(value) {
  const raw = String(value ?? "").trim().toLowerCase().replace(/^novados\s*/, "");
  const aliases = { "34": "1.2", "v34": "1.2" };
  return NOVA_RELEASES[raw] ? raw : aliases[raw] || null;
}

function versionInfo(version) {
  const normalized = normalizeVersion(version || state.version) || "1.0";
  const release = NOVA_RELEASES[normalized];
  return { version: normalized, ...release };
}

function commandAvailable(name) {
  const allowed = COMMAND_ALLOWED[String(name).toLowerCase()];
  if (allowed) return allowed.includes(state.version);
  return !COMMAND_UNAVAILABLE_IN_1_0.has(String(name).toLowerCase());
}

function isAntiMalwareEnabled() {
  return true;
}

const MALWARE_SIGNATURES = Object.freeze([
  { pattern: /\b(?:virus|malware|ransomware|trojan)\b/i, reason: "malware marker detected" },
  { pattern: /\bformat\s+(?:[a-z]:|c:|\/)/i, reason: "disk format command detected" },
  { pattern: /(?:\brm\s+-rf\b|\b(?:del|erase)\s+(?:\/\w+\s+)*\*|\brd\s+(?:\/s|\/q))/i, reason: "destructive delete command detected" },
  { pattern: /\b(?:shutdown|reboot)\b/i, reason: "system disruption command detected" },
  { pattern: /while\s*\(\s*true\s*\)|while\s+True\s*:/i, reason: "unbounded execution loop detected" },
  { pattern: /for\s*\(\s*;\s*;\s*\)/i, reason: "unbounded execution loop detected" },
  { pattern: /\b(?:eval|exec)\s*\(|new\s+Function\s*\(|\bFunction\s*\(/i, reason: "dynamic code execution detected" },
  { pattern: /(?:fork\s*bomb|:\(\)\s*\{[^}]*:\s*\|\s*:\s*&)/i, reason: "process-spawning code detected" },
  { pattern: /\b(?:dd\s+if=\/dev\/(?:zero|null)|yes\s*(?:>|>>)|mkfs\b)/i, reason: "resource-exhaustion or disk-destruction command detected" },
  { pattern: /(?:Array\s*\(\s*(?:\d{7,}|[1-9]\d{6,})\s*\)|new\s+Array\s*\(\s*(?:\d{7,}|[1-9]\d{6,})\s*\))/i, reason: "large memory allocation detected" },
  { pattern: /(?:\.repeat\s*\(\s*(?:\d{7,}|[1-9]\d{6,})\s*\)|Array\.from\s*\(\s*\{\s*length\s*:\s*(?:\d{7,}|[1-9]\d{6,})\s*\})/i, reason: "large repeated allocation detected" },
]);

const NOVA_RUNTIME_LIMIT_MS = 5000;
const NOVA_RUNTIME_OUTPUT_LIMIT = 100000;
const NOVA_RUNTIME_COMMAND_LIMIT = 256;

function scanFileForMalware(path, content = null) {
  if (!isAntiMalwareEnabled()) return { safe: true, threats: [] };
  const node = content === null ? nodeAt(resolve(path)) : null;
  const source = String(content ?? node?.content ?? "");
  const threats = MALWARE_SIGNATURES
    .filter(({ pattern }) => pattern.test(source))
    .map(({ reason }) => reason);
  if (source.length > 250000) threats.push("unusually large source file may overwhelm DOS memory");
  return { safe: threats.length === 0, threats };
}

function scanPathForMalware(path = cwd) {
  const targetPath = resolve(path);
  const target = nodeAt(targetPath);
  if (!target) return { found: false, threats: [] };
  const threats = [];
  const visit = (node, currentPath) => {
    if (node.type === "file") {
      const scan = scanFileForMalware(currentPath, node.content);
      if (!scan.safe) threats.push({ path: currentPath, reasons: scan.threats });
      return;
    }
    Object.entries(node.children || {}).forEach(([name, child]) => visit(child, `${currentPath}/${name}`.replace(/\/+/g, "/")));
  };
  visit(target, targetPath);
  return { found: true, threats };
}

function currentVentsVersion() {
  return "1.0";
}

function makeFS() {
  const root = { type: "dir", children: {} };
  const home = { type: "dir", children: {} };
  root.children["home"] = { type: "dir", children: { user: home } };
  root.children["usr"] = { type: "dir", children: {} };
  root.children["bin"] = { type: "dir", children: {} };
  root.children["etc"] = { type: "dir", children: {} };
  root.children["tmp"] = { type: "dir", children: {} };
  root.children["var"] = { type: "dir", children: {} };
  home.children["hello.txt"] = { type: "file", content: "Nova DOS text file.\r\nType HELP to see the available commands.\r\n" };
  return root;
}

function networkInfo() {
  const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
  return {
    online: navigator.onLine,
    type: connection?.type || "unavailable",
    effectiveType: connection?.effectiveType || "unavailable",
    downlink: connection?.downlink,
    rtt: connection?.rtt,
  };
}

async function storageEstimate() {
  if (!navigator.storage?.estimate) return null;
  const estimate = await navigator.storage.estimate();
  return {
    usage: Number(estimate.usage || 0),
    quota: Number(estimate.quota || 0),
  };
}

async function pingHost(host) {
  const cleanHost = String(host || "").trim();
  if (!/^[a-z0-9.-]+$/i.test(cleanHost)) throw new Error("Host names must not contain paths or shell characters.");
  const started = performance.now();
  const response = await fetch("/api/ping", {
    method: "POST",
    headers: { "content-type": "application/json" },
    cache: "no-store",
    body: JSON.stringify({ host: cleanHost }),
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || "Network probe failed.");
  return {
    reachable: Boolean(body.reachable),
    time: Math.max(0, Math.round(body.time ?? (performance.now() - started))),
    protocol: body.protocol || "HTTP",
    note: body.note || "",
  };
}

async function networkDetails() {
  const response = await fetch("/api/network", { cache: "no-store" });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || "Network details are unavailable.");
  return { ...networkInfo(), ...body };
}

async function pingNetwork() {
  const started = performance.now();
  const response = await fetch("/api/network", { cache: "no-store" });
  return {
    reachable: response.ok,
    time: Math.round(performance.now() - started),
    protocol: "BROWSER→PROJECT",
    note: "Measured the visitor browser's network path to this NovaDOS project.",
  };
}

async function lookupHost(host) {
  const cleanHost = String(host || "").trim();
  if (!/^[a-z0-9.-]+$/i.test(cleanHost)) throw new Error("Invalid host name.");
  const response = await fetch("/api/dns?host=" + encodeURIComponent(cleanHost), { cache: "no-store" });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || "DNS lookup failed.");
  return body;
}

function nodeAt(path) {
  if (!path) return null;
  const parts = path.split("/").filter(Boolean);
  let n = fs;
  if (parts.length === 0) return fs;
  for (const p of parts) {
    if (!n || n.type !== "dir" || !n.children[p]) return null;
    n = n.children[p];
  }
  return n;
}

function resolve(p) {
  const treatHome = (x) => (x === "~" ? HOME() : x.startsWith("~/") ? HOME() + x.slice(1) : x);
  p = String(p).replace(/^C:/i, "").replaceAll("\\", "/");
  p = treatHome(p);
  let parts = [];
  if (p.startsWith("/")) {
    parts = p.split("/").filter(Boolean);
  } else {
    const base = cwd.split("/").filter(Boolean);
    parts = base.concat(p.split("/").filter(Boolean));
  }
  const out = [];
  for (const part of parts) {
    if (part === ".") continue;
    if (part === "..") out.pop();
    else out.push(part);
  }
  return "/" + out.join("/");
}

function display(cwd) {
  const path = cwd === "/" ? "" : cwd.replace(/^\/+/, "").replaceAll("/", "\\");
  return `C:\\${path}`;
}

function promptLabel(pwd) {
  const format = state.promptFormat;
  if (!format) return `nova@novados:${display(pwd)}`;
  return format
    .replaceAll("$U", state.user)
    .replaceAll("$H", state.host)
    .replaceAll("$P", display(pwd))
    .replaceAll("$G", "");
}

function persistentStateSnapshot() {
  return {
    fs,
    cwd,
    env,
    state: {
      user: state.user,
      host: state.host,
      version: state.version,
      ventsVersion: state.ventsVersion,
      releaseState: RELEASE_STATE,
      users: state.users,
      promptFormat: state.promptFormat,
      volumeLabel: state.volumeLabel,
      verify: state.verify,
      dirStack: state.dirStack,
    },
  };
}

async function opfsRoot() {
  if (!navigator.storage?.getDirectory) {
    throw new Error("Origin Private File System is unavailable in this browser.");
  }
  return navigator.storage.getDirectory();
}

function savePersistentState() {
  const write = async () => {
    await persistentStateReady;
    await indexedPFS.saveJson(persistentStateSnapshot());
  };
  persistentWriteQueue = persistentWriteQueue.then(write, write);
  return persistentWriteQueue.catch((error) => {
    console.warn("Nova DOS could not save its OPFS state.", error);
  });
}

async function loadPersistentState() {
  try {
    let saved = await indexedPFS.loadJson();
    if (!saved) {
      try {
        const root = await opfsRoot();
        const legacyHandle = await root.getFileHandle(OPFS_STATE_FILE);
        saved = JSON.parse(await (await legacyHandle.getFile()).text());
        await indexedPFS.saveJson(saved);
        await root.removeEntry(OPFS_STATE_FILE);
      } catch (error) {
        if (error?.name !== "NotFoundError") throw error;
      }
    }
    if (!saved) return;

    if (saved.fs && saved.fs.type === "dir" && saved.fs.children && typeof saved.fs.children === "object") {
      fs.children = saved.fs.children;
    }
    if (saved.env && typeof saved.env === "object") {
      for (const key of Object.keys(env)) delete env[key];
      for (const [key, value] of Object.entries(saved.env)) {
        if (typeof value === "string") env[key] = value;
      }
    }
    if (saved.state && typeof saved.state === "object") {
      if (saved.state.users && typeof saved.state.users === "object") state.users = saved.state.users;
      if (typeof saved.state.host === "string") state.host = saved.state.host;
      const savedVersion = normalizeVersion(saved.state.version);
      if (saved.state.releaseState === RELEASE_STATE) {
        if (savedVersion) state.version = savedVersion;
        state.ventsVersion = "1.0";
      } else {
        state.version = RELEASE_STATE;
        state.ventsVersion = "1.0";
      }
      if (typeof saved.state.promptFormat === "string") state.promptFormat = saved.state.promptFormat;
      if (typeof saved.state.volumeLabel === "string") state.volumeLabel = saved.state.volumeLabel;
      if (typeof saved.state.verify === "boolean") state.verify = saved.state.verify;
      if (Array.isArray(saved.state.dirStack)) state.dirStack = saved.state.dirStack;
      if (typeof saved.state.user === "string" && state.users[saved.state.user]) state.user = saved.state.user;
    }
    if (typeof saved.cwd === "string" && nodeAt(saved.cwd)?.type === "dir") cwd = saved.cwd;
  } catch (error) {
    console.warn("Nova DOS could not load its OPFS state.", error);
  }
}

persistentStateReady = loadPersistentState();

let activeNote = null;

function collectNoteFiles(node = fs, base = "", files = []) {
  if (!node || node.type !== "dir") return files;
  for (const [name, child] of Object.entries(node.children || {}).sort(([a], [b]) => a.localeCompare(b))) {
    const path = `${base}/${name}` || "/";
    if (child.type === "dir") collectNoteFiles(child, path, files);
    else files.push(path);
  }
  return files;
}

function writeNoteFile(path, content, metadata = {}) {
  const target = resolve(path);
  const parts = target.split("/").filter(Boolean);
  const filename = parts.pop();
  if (!filename) throw new Error("A filename is required.");
  let node = fs;
  for (const part of parts) {
    if (!node.children[part]) node.children[part] = { type: "dir", children: {} };
    if (node.children[part].type !== "dir") throw new Error(`${part} is not a folder.`);
    node = node.children[part];
  }
  node.children[filename] = { type: "file", content: String(content), ...metadata };
  savePersistentState();
  return target;
}

const VENTS_UPDATE_PACKAGE = Object.freeze({
  "vents-shell.bin": "VENTS graphical shell 1.5\nImproved file navigation and protected system folders.\n",
  "filesystem-core.bin": "NOVA FS CORE 1.5\nAtomic copies: enabled\nProtected folders: enabled\n",
  "antivirus.vdb": "NOVA GUARD GRAPHICAL EDITION 1.5\nSignatures: built-in\nReal-time open/download scanning: enabled\n",
  "games/arcade.game": "Arcade collection: Star Dash, Pixel Pairs, Space Catcher, Number Sprint\n",
  "games/logic.game": "Logic collection: Mines, Word Grid, Memory Match, Safe Path\n",
});

function ensureDirectoryAt(path) {
  const parts = resolve(path).split("/").filter(Boolean);
  let node = fs;
  for (const part of parts) {
    if (!node.children[part]) node.children[part] = { type: "dir", children: {} };
    if (node.children[part].type !== "dir") throw new Error(`${part} is not a folder.`);
    node = node.children[part];
  }
  return node;
}

function ensureVentsUpdatePackage() {
  const packageRoot = ensureDirectoryAt("/usr/vents-updates/1.5");
  for (const [relativePath, content] of Object.entries(VENTS_UPDATE_PACKAGE)) {
    const parts = relativePath.split("/");
    const filename = parts.pop();
    const folder = ensureDirectoryAt(`/usr/vents-updates/1.5/${parts.join("/")}`);
    if (!folder.children[filename]) folder.children[filename] = { type: "file", content };
  }
  return packageRoot;
}

ensureVentsUpdatePackage();

function closeGraphicalNote() {
  if (activeNote) activeNote.close();
}

function openGraphicalNote() {
  if (activeNote) return activeNote.promise;

  let finish;
  const promise = new Promise((resolveClose) => { finish = resolveClose; });
  const overlay = document.createElement("div");
  overlay.className = "note-overlay";
  overlay.innerHTML = `
    <div class="note-boot-screen" aria-hidden="true">
      <div class="note-boot-mark">G-NOTE</div>
      <div class="note-boot-subtitle">GRAPHICAL TEXT SYSTEM // 2026</div>
      <div class="note-boot-message">INITIALIZING MEMORY...</div>
      <div class="note-boot-progress"><span></span></div>
      <div class="note-boot-footer">COPYRIGHT NOVA SYSTEMS</div>
    </div>
    <section class="note-window" role="dialog" aria-label="G-note">
      <header class="note-titlebar">
        <span class="note-title">G-note</span>
        <button class="note-close" data-action="turn-off" aria-label="Turn off G-note">×</button>
      </header>
      <nav class="note-menubar">
        <button class="note-menu-button" data-action="file-menu">File</button>
        <div class="note-file-menu" hidden>
          <button data-action="new">New</button>
          <button data-action="open">Open</button>
          <button data-action="save">Save</button>
          <button data-action="save-as">Save As</button>
          <button data-action="turn-off">turn off G-note</button>
        </div>
      </nav>
      <div class="note-toolbar">
        <label class="note-file-label">File <input class="note-filename" value="/home/user/untitled.txt" spellcheck="false" /></label>
        <select class="note-file-list" aria-label="Files">
          <option value="">Open a file...</option>
        </select>
        <button data-action="new">New</button>
        <button data-action="open">Open</button>
        <button class="note-save-button" data-action="save">Save</button>
        <button data-action="save-as">Save As</button>
      </div>
      <textarea class="note-editor" spellcheck="false" aria-label="Text editor"></textarea>
      <footer class="note-statusbar">
        <span class="note-status">New document</span>
        <span>Ctrl+S to save · Esc to turn off</span>
      </footer>
    </section>
  `;
  document.body.appendChild(overlay);

  const windowElement = overlay.querySelector(".note-window");
  const bootScreen = overlay.querySelector(".note-boot-screen");
  const editor = overlay.querySelector(".note-editor");
  const filename = overlay.querySelector(".note-filename");
  const fileList = overlay.querySelector(".note-file-list");
  const status = overlay.querySelector(".note-status");
  const fileMenu = overlay.querySelector(".note-file-menu");
  let currentPath = "/home/user/untitled.txt";
  let dirty = false;
  let bootTimer;

  const setStatus = (message, kind = "") => {
    status.textContent = message;
    status.className = `note-status${kind ? ` ${kind}` : ""}`;
  };

  const refreshFiles = () => {
    fileList.innerHTML = "<option value=\"\">Open a file...</option>";
    for (const path of collectNoteFiles()) {
      const option = document.createElement("option");
      option.value = path;
      option.textContent = path;
      fileList.appendChild(option);
    }
    fileList.value = nodeAt(currentPath)?.type === "file" ? currentPath : "";
  };

  const loadFile = async (path) => {
    const node = nodeAt(resolve(path));
    if (!node || node.type !== "file") {
      setStatus(`Could not open ${path}.`, "error");
      return;
    }
    if (!(await confirmFileOpen(path, overlay))) {
      setStatus("File open cancelled.", "dim");
      return;
    }
    currentPath = resolve(path);
    filename.value = currentPath;
    editor.value = node.content;
    dirty = false;
    setStatus(`Opened ${currentPath}`);
    refreshFiles();
    editor.focus();
  };

  const saveFile = () => {
    const requestedPath = filename.value.trim();
    if (!requestedPath) {
      setStatus("Enter a filename before saving.", "error");
      filename.focus();
      return;
    }
    try {
      currentPath = writeNoteFile(requestedPath, editor.value);
      filename.value = currentPath;
      dirty = false;
      setStatus(`Saved ${currentPath}`, "saved");
      refreshFiles();
    } catch (error) {
      setStatus(error.message || String(error), "error");
    }
  };

  const newFile = () => {
    currentPath = "/home/user/untitled.txt";
    filename.value = currentPath;
    editor.value = "";
    dirty = true;
    setStatus("New document · unsaved", "unsaved");
    editor.focus();
  };

  const close = () => {
    clearTimeout(bootTimer);
    overlay.remove();
    activeNote = null;
    finish();
    focusInput();
  };

  activeNote = { promise, close };
  refreshFiles();

  bootTimer = setTimeout(() => {
    windowElement.classList.add("is-ready");
    bootScreen.classList.add("is-complete");
    setTimeout(() => bootScreen.remove(), 360);
    editor.focus();
  }, 1500);

  overlay.addEventListener("click", (event) => {
    const action = event.target.closest("[data-action]")?.dataset.action;
    if (!action) return;
    if (action === "file-menu") {
      fileMenu.hidden = !fileMenu.hidden;
      return;
    }
    fileMenu.hidden = true;
    if (action === "new") newFile();
    else if (action === "open") {
      if (fileList.value) loadFile(fileList.value);
      else { setStatus("Choose a file to open."); fileList.focus(); }
    } else if (action === "save") saveFile();
    else if (action === "save-as") {
      filename.focus();
      filename.select();
      setStatus("Enter a new path, then press Save.");
    } else if (action === "turn-off") close();
  });

  fileList.addEventListener("change", () => {
    if (fileList.value) loadFile(fileList.value);
  });
  filename.addEventListener("input", () => { dirty = true; setStatus("Unsaved changes", "unsaved"); });
  editor.addEventListener("input", () => { dirty = true; setStatus("Unsaved changes", "unsaved"); });
  editor.addEventListener("keydown", (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
      event.preventDefault();
      saveFile();
    }
  });
  overlay.addEventListener("keydown", (event) => {
    event.stopPropagation();
    if (event.key === "Escape") {
      event.preventDefault();
      if (isVents16 && windowElement.classList.contains("is-open")) {
        windowElement.classList.remove("is-open");
        setStatus("My PC closed");
      } else close();
    }
  });

  return promise;
}

function openVents16Desktop(initialPath = null) {
  if (activeNote) return activeNote.promise;

  const desktopVersion = state.version;

  let finish;
  const promise = new Promise((resolveClose) => { finish = resolveClose; });
  const overlay = document.createElement("div");
  overlay.className = "note-overlay v14-overlay";
  overlay.innerHTML = `
    <section class="v14-desktop" role="dialog" aria-label="Vents 1.4 desktop">
      <header class="v14-systembar">
        <span class="v14-system-mark">◆ NOVA DOS ${escapeHtml(desktopVersion)}</span>
        <span>VENTS 1.6 PROGRAM MANAGER</span>
        <span class="v14-clock">--:--</span>
      </header>
      <main class="v14-surface">
        <div class="v14-tile-grid" aria-label="Desktop applications">
          <button class="v14-desktop-tile" data-v14-app="files"><span class="v14-tile-icon">▣</span><strong>My PC</strong><small>File Manager</small></button>
          <button class="v14-desktop-tile" data-v14-app="note"><span class="v14-tile-icon">✎</span><strong>G-Note</strong><small>Text Editor</small></button>
          <button class="v14-desktop-tile" data-v14-app="terminal"><span class="v14-tile-icon">&gt;_</span><strong>Terminal</strong><small>Command Line</small></button>
          <button class="v14-desktop-tile" data-v14-app="games"><span class="v14-tile-icon">★</span><strong>Arcade</strong><small>Games Room</small></button>
          <button class="v14-desktop-tile" data-v14-app="system"><span class="v14-tile-icon">⚙</span><strong>System</strong><small>Control Panel</small></button>
        </div>
        <div class="v14-window-layer"></div>
        <div class="v14-welcome">DOUBLE-CLICK AN ICON TO OPEN A WINDOW</div>
      </main>
      <footer class="v14-taskbar">
        <button class="v14-menu-button" data-v14-app="system">PROGRAM MANAGER</button>
        <span class="v14-task-status">Ready · User /home/user</span>
        <button class="v14-exit-button" data-v14-action="close">Exit Vents</button>
      </footer>
    </section>
  `;
  document.body.appendChild(overlay);

  const desktop = overlay.querySelector(".v14-desktop");
  const layer = overlay.querySelector(".v14-window-layer");
  const taskStatus = overlay.querySelector(".v14-task-status");
  const clock = overlay.querySelector(".v14-clock");
  let zIndex = 3;
  let clockTimer;
  let windowNumber = 0;

  const setTaskStatus = (message) => { taskStatus.textContent = message; };
  const updateClock = () => { clock.textContent = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }); };
  updateClock();
  clockTimer = setInterval(updateClock, 1000);

  const focusWindow = (windowElement) => {
    zIndex++;
    windowElement.style.zIndex = zIndex;
    overlay.querySelectorAll(".v14-window").forEach((item) => item.classList.toggle("is-active", item === windowElement));
  };

  const closeWindow = (windowElement) => {
    windowElement.remove();
    setTaskStatus("Ready · Desktop window closed");
  };

  const makeWindow = ({ app, title, width = 540, height = 360, content }) => {
    const existing = layer.querySelector(`.v14-window[data-v14-window="${app}"]`);
    if (existing) { existing.hidden = false; focusWindow(existing); return existing; }
    windowNumber++;
    const windowElement = document.createElement("section");
    windowElement.className = "v14-window is-active";
    windowElement.dataset.v14Window = app;
    windowElement.style.width = `${width}px`;
    windowElement.style.height = `${height}px`;
    windowElement.style.left = `${Math.min(80 + windowNumber * 28, Math.max(18, window.innerWidth - width - 24))}px`;
    windowElement.style.top = `${Math.min(64 + windowNumber * 22, Math.max(42, window.innerHeight - height - 78))}px`;
      windowElement.innerHTML = `
      <header class="v14-window-titlebar">
        <span><b>◆</b> ${escapeHtml(title)}</span>
        <span class="v14-window-buttons"><button data-v14-window-action="minimize" aria-label="Minimize">_</button><button data-v14-window-action="maximize" aria-label="Maximize">□</button><button data-v14-window-action="close" aria-label="Close">×</button></span>
      </header>
      <div class="v14-window-body">${content}</div>
    `;
    layer.appendChild(windowElement);
    const titlebar = windowElement.querySelector(".v14-window-titlebar");
    let drag = null;
    titlebar.addEventListener("pointerdown", (event) => {
      if (event.target.closest("button")) return;
      focusWindow(windowElement);
      const rect = windowElement.getBoundingClientRect();
      drag = { x: event.clientX - rect.left, y: event.clientY - rect.top };
      titlebar.setPointerCapture(event.pointerId);
    });
    titlebar.addEventListener("pointermove", (event) => {
      if (!drag) return;
      windowElement.style.left = `${Math.max(8, event.clientX - drag.x)}px`;
      windowElement.style.top = `${Math.max(34, event.clientY - drag.y)}px`;
    });
    titlebar.addEventListener("pointerup", () => { drag = null; });
    const toggleMaximize = () => {
      const maximized = windowElement.classList.toggle("is-maximized");
      const button = windowElement.querySelector('[data-v14-window-action="maximize"]');
      button.textContent = maximized ? "❐" : "□";
      button.setAttribute("aria-label", maximized ? "Restore" : "Maximize");
    };
    titlebar.addEventListener("dblclick", toggleMaximize);
    windowElement.addEventListener("pointerdown", () => focusWindow(windowElement));
    windowElement.querySelector('[data-v14-window-action="close"]').addEventListener("click", () => closeWindow(windowElement));
    windowElement.querySelector('[data-v14-window-action="minimize"]').addEventListener("click", () => {
      windowElement.hidden = true;
      setTaskStatus(`${title} minimized · click its desktop tile to restore`);
    });
    windowElement.querySelector('[data-v14-window-action="maximize"]').addEventListener("click", toggleMaximize);
    focusWindow(windowElement);
    return windowElement;
  };

  const listDirectory = (path, listElement, pathInput, windowElement) => {
    const target = resolve(path);
    const directory = nodeAt(target);
    if (!directory || directory.type !== "dir") {
      setTaskStatus(`Folder not found: ${path}`);
      return;
    }
    pathInput.value = target;
    listElement.innerHTML = "";
    Object.entries(directory.children || {}).sort(([a], [b]) => a.localeCompare(b)).forEach(([name, node]) => {
      const entry = document.createElement("button");
      entry.type = "button";
      entry.className = "v14-file-entry";
      entry.innerHTML = `<span>${node.type === "dir" ? "▰" : "▤"}</span><b>${escapeHtml(name)}</b><small>${node.type === "dir" ? "FOLDER" : `${String(node.content || "").length} BYTES`}</small>`;
      entry.addEventListener("dblclick", () => {
        const nextPath = `${target}/${name}`.replace(/\/+/g, "/");
        if (node.type === "dir") listDirectory(nextPath, listElement, pathInput, windowElement);
        else openTextWindow(nextPath, node.content || "");
      });
      entry.addEventListener("click", () => setTaskStatus(`${target}/${name}`));
      listElement.appendChild(entry);
    });
    setTaskStatus(`Browsing ${target}`);
  };

  const openTextWindow = async (path, content) => {
    if (!(await confirmFileOpen(path, overlay))) {
      setTaskStatus("File open cancelled.");
      return;
    }
    const name = path.split("/").pop() || "Untitled";
    const windowElement = makeWindow({
      app: `text-${path.replace(/[^a-z0-9]/gi, "-")}`,
      title: `G-Note · ${name}`,
      width: 620,
      height: 430,
      content: `<textarea class="v14-text-editor" spellcheck="false">${escapeHtml(content)}</textarea><div class="v14-window-actions"><button data-v14-save-note>Save to ${escapeHtml(path)}</button></div>`,
    });
    windowElement.querySelector("[data-v14-save-note]").addEventListener("click", () => {
      writeNoteFile(path, windowElement.querySelector(".v14-text-editor").value);
      setTaskStatus(`Saved ${path}`);
    });
  };

  const openFiles = () => {
    const windowElement = makeWindow({
      app: "files",
      title: "MY FILES · NOVA FILE MANAGER",
      width: 590,
      height: 440,
      content: `<div class="v14-file-toolbar"><input class="v14-path-input" value="/home/user" spellcheck="false" /><button data-v14-go>GO</button></div><div class="v14-file-list" role="listbox"></div><div class="v14-file-hint">Double-click a folder to open it · double-click a file to read it</div>`,
    });
    const list = windowElement.querySelector(".v14-file-list");
    const pathInput = windowElement.querySelector(".v14-path-input");
    const refresh = () => listDirectory(pathInput.value, list, pathInput, windowElement);
    windowElement.querySelector("[data-v14-go]").addEventListener("click", refresh);
    pathInput.addEventListener("keydown", (event) => { if (event.key === "Enter") refresh(); });
    refresh();
    return windowElement;
  };

  const openTerminal = () => {
    const windowElement = makeWindow({
      app: "terminal",
      title: "TERMINAL · C:\\DOS",
      width: 650,
      height: 420,
      content: `<div class="v14-terminal-output">NOVA DOS ${escapeHtml(desktopVersion)} VENTS TERMINAL\nType HELP or VER.\n</div><form class="v14-terminal-form"><span>C:\\&gt;</span><input autocomplete="off" spellcheck="false" aria-label="Vents terminal command" /><button>RUN</button></form>`,
    });
    const outputElement = windowElement.querySelector(".v14-terminal-output");
    const input = windowElement.querySelector(".v14-terminal-form input");
    windowElement.querySelector(".v14-terminal-form").addEventListener("submit", async (event) => {
      event.preventDefault();
      const parsed = tokenize(input.value.trim());
      input.value = "";
      if (!parsed.cmd) return;
      const lines = [];
      const guiContext = Object.create(ctx);
      guiContext.args = parsed.args;
      guiContext.print = (text) => String(text).split("\n").forEach((line) => lines.push(line));
      guiContext.printHtml = (html) => lines.push(String(html).replace(/<[^>]*>/g, ""));
      guiContext.progress = (text) => lines.push(String(text));
      outputElement.textContent += `\nC:\\> ${parsed.cmd} ${parsed.args.join(" ")}\n`;
      try {
        if (!commands[parsed.cmd.toLowerCase()] || ["vents", "ven", "turn"].includes(parsed.cmd.toLowerCase())) {
          lines.push(`Bad command or file name - ${parsed.cmd}`);
        } else if (!commandAvailable(parsed.cmd.toLowerCase())) {
          lines.push(`${parsed.cmd}: not available in NovaDOS ${desktopVersion}`);
        } else {
          await commands[parsed.cmd.toLowerCase()](guiContext);
        }
      } catch (error) { lines.push(error?.message || String(error)); }
      outputElement.textContent += lines.join("\n") + "\n";
      outputElement.scrollTop = outputElement.scrollHeight;
    });
    input.focus();
    return windowElement;
  };

  const openGames = () => {
    const windowElement = makeWindow({
      app: "games",
      title: "GAMES",
      width: 500,
      height: 350,
      content: `<div class="v14-game-tile-grid"><button data-v14-game="dice">DICE<br /><small>ROLL THE DIE</small></button><button data-v14-game="coin">COIN FLIP<br /><small>CALL IT</small></button><button data-v14-game="slot">SLOT MACHINE<br /><small>HIT THE JACKPOT</small></button><button data-v14-game="fortune">FORTUNE<br /><small>ASK THE ORACLE</small></button></div><pre class="v14-game-result">Choose a game.</pre>`,
    });
    const result = windowElement.querySelector(".v14-game-result");
    windowElement.querySelectorAll("[data-v14-game]").forEach((button) => button.addEventListener("click", () => {
      const game = button.dataset.v14Game;
      const values = game === "dice" ? [`You rolled ${Math.floor(Math.random() * 6) + 1}.`] : game === "coin" ? [Math.random() < 0.5 ? "HEADS" : "TAILS"] : game === "slot" ? [`[ ${["7", "★", "◆"][Math.floor(Math.random() * 3)]} | ${["7", "★", "◆"][Math.floor(Math.random() * 3)]} | ${["7", "★", "◆"][Math.floor(Math.random() * 3)]} ]`] : ["The desktop says: keep exploring."];
      result.textContent = values[0];
    }));
    return windowElement;
  };

  const openSystem = () => {
    const windowElement = makeWindow({
      app: "system",
      title: "NOVA MENU · SYSTEM CONTROL",
      width: 460,
      height: 330,
      content: `<div class="v14-system-panel"><div class="v14-system-logo">◆</div><h2>NOVA DOS ${escapeHtml(desktopVersion)}</h2><p>VENTS RETRO DESKTOP · DESKTOP EDITION</p><hr /><p>Memory: 640K conventional<br />Filesystem: Nova FS 1.5<br />Anti-malware: active</p><button data-v14-scan>SCAN USER FILES</button><output data-v14-scan-output></output></div>`,
    });
    windowElement.querySelector("[data-v14-scan]").addEventListener("click", () => {
      const scan = scanPathForMalware(HOME());
      windowElement.querySelector("[data-v14-scan-output]").textContent = scan.threats.length ? `${scan.threats.length} threat(s) blocked.` : "No threats found.";
    });
    return windowElement;
  };

  const openApp = (app) => {
    if (app === "files") openFiles();
    else if (app === "note") openTextWindow("/home/user/desktop-note.txt", nodeAt("/home/user/desktop-note.txt")?.content || "");
    else if (app === "terminal") openTerminal();
    else if (app === "games") openGames();
    else if (app === "system") openSystem();
  };

  const closeDesktop = () => {
    clearInterval(clockTimer);
    overlay.remove();
    activeNote = null;
    finish();
    focusInput();
  };

  activeNote = { promise, close: closeDesktop };
  overlay.addEventListener("dblclick", (event) => {
    const tile = event.target.closest("[data-v14-app]");
    if (tile) openApp(tile.dataset.v14App);
  });
  overlay.addEventListener("click", (event) => {
    if (event.target.closest('[data-v14-action="close"]')) closeDesktop();
    const tile = event.target.closest("[data-v14-app]");
    if (tile) openApp(tile.dataset.v14App);
  });
  if (initialPath) openTextWindow(initialPath, nodeAt(initialPath)?.content || "");
  return promise;
}

function openVentsDesktop(initialPath = null, preapprovedPath = null) {
  if (activeNote) return activeNote.promise;

  const ventsVersion = currentVentsVersion();
  const isVents15 = ventsVersion === "1.5" || ventsVersion === "1.6";
  const isVents16 = ventsVersion === "1.6";
  const isVents101 = ventsVersion === "1.01";
  const canUpdateVents16 = state.version === "1.4" && ventsVersion === "1.5";
  const hasInternetDownloads = true;
  const ventsBrand = isVents16 ? "VENTS 1.6" : isVents15 ? "VENTS 1.5" : isVents101 ? "VENTS 1.01" : "VENTS";
  const appTitle = isVents16 ? "My PC" : ventsBrand;

  let finish;
  const promise = new Promise((resolveClose) => { finish = resolveClose; });
  const overlay = document.createElement("div");
  overlay.className = isVents16 ? "note-overlay v16-overlay" : "note-overlay";
  overlay.innerHTML = `
    <div class="note-boot-screen" aria-hidden="true">
      <div class="note-boot-mark">${ventsBrand}</div>
      <div class="note-boot-subtitle">USER GRAPHICAL SYSTEM // 2026</div>
      <div class="note-boot-message">LOADING USER DESKTOP...</div>
      <div class="note-boot-progress"><span></span></div>
      <div class="note-boot-footer">COPYRIGHT NOVA SYSTEMS</div>
    </div>
    ${isVents16 ? `<div class="v16-empty-desktop" aria-label="Vents 1.6 desktop">
      <div class="v16-desktop-icons">
        <button class="v16-desktop-icon" data-v16-app="my-pc" aria-label="Open My PC"><span class="v16-desktop-icon-art">▤</span><span>My PC</span></button>
        <button class="v16-desktop-icon" data-v16-app="terminal" aria-label="Open Terminal"><span class="v16-desktop-icon-art">&gt;_</span><span>Terminal</span></button>
        <button class="v16-desktop-icon" data-v16-app="calculator" aria-label="Open Calculator"><span class="v16-desktop-icon-art">＋</span><span>Calculator</span></button>
        <button class="v16-desktop-icon" data-v16-app="gnote" aria-label="Open G-note"><span class="v16-desktop-icon-art">✎</span><span>G-note</span></button>
          <button class="v16-desktop-icon" data-v16-app="games" aria-label="Open Arcade"><span class="v16-desktop-icon-art">★</span><span>Arcade</span></button>
          <button class="v16-desktop-icon" data-v16-app="code" aria-label="Open Code"><span class="v16-desktop-icon-art">&lt;/&gt;</span><span>Code</span></button>
          <button class="v16-desktop-icon" data-v16-app="internet-installer" aria-label="Open Install Files From Internet"><span class="v16-desktop-icon-art">↓</span><span>Install Files<br />From Internet</span></button>
      </div>
      <div class="v16-desktop-power">
        <button type="button" data-v16-desktop-action="dos">Enter DOS</button>
      </div>
    </div>
      <div class="v16-desktop-context-menu" hidden role="menu" aria-label="Desktop menu">
        <button type="button" data-v16-context-action="open-my-pc">Open My PC</button>
        <button type="button" data-v16-context-action="refresh">Refresh</button>
        <div class="v16-desktop-context-divider"></div>
        <button type="button" data-v16-context-action="new-file">New text file</button>
        <button type="button" data-v16-context-action="new-folder">New folder</button>
        <div class="v16-desktop-context-divider"></div>
        <button type="button" data-v16-context-action="properties">Desktop properties</button>
      </div>
    ` : ""}
    <section class="note-window${isVents16 ? " v16-my-pc-window" : ""}" role="dialog" aria-label="My PC file manager">
      <header class="note-titlebar">
        <div class="note-brand"><span class="note-title">${appTitle}</span><span class="note-edition">USER DESKTOP</span></div>
        <span class="note-user-badge">USER /home/user</span>
          ${isVents16 ? `<div class="v16-app-controls" aria-label="My PC window controls">
            <button type="button" data-action="minimize-app" aria-label="Minimize My PC">_</button>
            <button type="button" data-action="maximize-app" aria-label="Maximize My PC">□</button>
            <button type="button" data-action="turn-off" aria-label="Exit My PC">×</button>
          </div>` : '<button class="note-close" data-action="turn-off" aria-label="Exit Vents">×</button>'}
      </header>
      ${isVents16 ? '<div class="v16-app-content">' : ""}
      <nav class="note-menubar">
        <div class="note-view-tabs" role="tablist" aria-label="Desktop views">
          <button class="is-active" data-action="view-files" role="tab">Files</button>
          <button data-action="view-editor" role="tab">Editor</button>
          <button data-action="view-tools" role="tab">Tools</button>
          ${isVents15 ? '<button data-action="view-games" role="tab">Games</button>' : ""}
        </div>
        <div class="note-menubar-actions">
          <button data-action="refresh" aria-label="Refresh files">↻</button>
          <button data-action="turn-off">Exit</button>
        </div>
      </nav>
      <div class="note-toolbar">
        <button data-action="back" aria-label="Back">←</button>
        <button data-action="up" aria-label="Go up">↑</button>
        <button data-action="home">Home</button>
        <input class="note-path" aria-label="Current folder" value="/home/user" spellcheck="false" />
        <button data-action="go-path">Go</button>
        <span class="note-toolbar-spacer"></span>
        <button data-action="new-file">New file</button>
        <button data-action="new-folder">New folder</button>
        <button data-action="rename">Rename</button>
        <button data-action="copy">Copy</button>
        <button data-action="move">Move</button>
        <button class="note-danger-button" data-action="delete">Delete</button>
        <span class="note-toolbar-spacer"></span>
        ${hasInternetDownloads ? '<button data-action="download-internet" title="Download a file from the internet into this folder">Download from internet</button>' : ""}
        ${isVents101 ? '<button data-action="update-vents" title="Copy the Vents 1.5 update files">Update Vents to 1.5</button>' : ""}
        ${canUpdateVents16 ? '<button data-action="update-vents-16" title="Copy the Vents 1.6 update files">Update Vents to 1.6</button>' : ""}
        ${isVents16 ? '<button data-action="downgrade-vents" title="Return to Vents 1.5">Downgrade to Vents 1.5</button>' : ventsVersion === "1.5" ? '<button data-action="downgrade-vents" title="Return to Vents 1.01">Downgrade to Vents 1.01</button>' : ""}
      </div>
      <div class="note-desktop-body">
        <aside class="note-sidebar" aria-label="Places and tools">
          <div class="note-sidebar-label">PLACES</div>
          <button class="note-place is-active" data-home-place data-path="/home/user"><span class="note-sidebar-icon">⌂</span> Home</button>
          <button class="note-place" data-path="/tmp"><span class="note-sidebar-icon">□</span> Temporary</button>
          <button class="note-place" data-path="/var"><span class="note-sidebar-icon">▤</span> Data</button>
          <div class="note-sidebar-label note-sidebar-tools-label">TOOLS</div>
          <button class="note-place" data-action="view-tools"><span class="note-sidebar-icon">▦</span> Utilities</button>
          <button class="note-place" data-action="view-editor"><span class="note-sidebar-icon">✎</span> Text editor</button>
          ${isVents15 ? '<button class="note-place" data-action="view-games"><span class="note-sidebar-icon">★</span> Games</button>' : ""}
          <div class="note-sidebar-foot">NOVA DOS ${escapeHtml(state.version)}<br />USER MODE</div>
        </aside>
        <main class="note-desktop-main">
          <section class="note-view note-files-view" data-view="files">
            <div class="note-view-heading">
              <div><div class="note-kicker">USER FILES</div><h1>File manager</h1></div>
              <span class="note-entry-count"></span>
            </div>
            <div class="note-file-grid" role="listbox" aria-label="Files"></div>
            <div class="note-empty-state" hidden>No files here yet.<br /><span>Create a file or folder to get started.</span></div>
          </section>
          <section class="note-view note-editor-view" data-view="editor" hidden>
            <div class="note-editor-heading">
              <div><div class="note-kicker">TEXT EDITOR</div><input class="note-filename" value="/home/user/untitled.txt" spellcheck="false" aria-label="File path" /></div>
              <div class="note-editor-actions">
                <button data-action="new-file">New</button>
                <button data-action="save-as">Save as</button>
                <button class="note-save-button" data-action="save">Save</button>
              </div>
            </div>
            <textarea class="note-editor" spellcheck="false" aria-label="Text editor"></textarea>
            <div class="note-editor-meta"><span class="note-editor-stat">0 characters</span><span>Ctrl+S saves · Esc exits</span></div>
          </section>
          <section class="note-view note-viewer-view" data-view="viewer" hidden>
            <div class="note-view-heading">
              <div><div class="note-kicker">FILE VIEWER</div><h1 class="note-viewer-title">File contents</h1></div>
              <button data-action="view-files">Back to files</button>
            </div>
            <pre class="note-file-viewer" aria-label="File contents"></pre>
          </section>
          <section class="note-view note-tools-view" data-view="tools" hidden>
            <div class="note-view-heading">
              <div><div class="note-kicker">USER UTILITIES</div><h1>Tools</h1></div>
              <span class="note-tool-caption">Separate workspaces for everyday tasks</span>
            </div>
            <div class="note-tool-tabs" role="tablist" aria-label="Tool workspaces">
              <button class="is-active" data-tool-panel="utilities" role="tab">Utilities</button>
              <button data-tool-panel="coding" role="tab">Coding</button>
              <button data-tool-panel="terminal" role="tab">Terminal</button>
            </div>
            <div class="note-tool-panel" data-tool-panel-view="utilities">
              <div class="note-tools-grid">
                <form class="note-tool-card note-calculator-card" data-tool-form="calculator">
                  <div class="note-tool-card-title">Calculator</div>
                  <div class="note-tool-card-copy">Evaluate a math expression.</div>
                  <div class="note-tool-row"><input class="note-calc-input" placeholder="12 * (4 + 3)" spellcheck="false" /><button>Run</button></div>
                  <output class="note-calc-output"></output>
                </form>
                <form class="note-tool-card" data-tool-form="search">
                  <div class="note-tool-card-title">Find in files</div>
                  <div class="note-tool-card-copy">Search names and text in your user files.</div>
                  <div class="note-tool-row"><input class="note-search-input" placeholder="search term" /><button>Find</button></div>
                  <output class="note-search-output"></output>
                </form>
                ${isVents15 ? `<form class="note-tool-card note-antivirus-card" data-tool-form="antivirus">
                  <div class="note-tool-card-title">Graphical antivirus</div>
                  <div class="note-tool-card-copy">Scan Vents files before they open or run.</div>
                  <div class="note-tool-row"><button type="submit">Scan now</button></div>
                  <output class="note-antivirus-output">Protection active.</output>
                </form>` : ""}
                ${isVents15 ? `<form class="note-tool-card" data-tool-form="filesystem">
                  <div class="note-tool-card-title">Filesystem health</div>
                  <div class="note-tool-card-copy">Check the improved Nova FS structure.</div>
                  <div class="note-tool-row"><button type="submit">Check now</button></div>
                  <output class="note-filesystem-output">Ready.</output>
                </form>` : ""}
              </div>
            </div>
            <section class="note-tool-panel note-coding-panel" data-tool-panel-view="coding" hidden>
              <div class="note-workspace-heading">
                <div><div class="note-kicker">CODING WORKSPACE</div><h2>Source editor</h2></div>
                <span class="note-tool-caption">JavaScript, Python, HTML, CSS, C, Rust, C++, Assembly, and WebAssembly</span>
              </div>
              <div class="note-code-toolbar">
                <select class="note-code-language" aria-label="Programming language">
                  <option value="javascript">JavaScript</option>
                  <option value="python">Python</option>
                  <option value="html">HTML</option>
                  <option value="css">CSS</option>
                  <option value="c">C</option>
                  <option value="rust">Rust</option>
                  <option value="cpp">C++</option>
                  <option value="assembly">Assembly</option>
                  <option value="wasm">WebAssembly</option>
                </select>
                <select class="note-code-file-list" aria-label="Source files">
                  <option value="">Saved source files...</option>
                </select>
                <input class="note-code-path" value="/home/user/program.js" aria-label="Source file path" spellcheck="false" />
                <button data-action="code-new">New</button>
                <button data-action="code-open">Open</button>
                <button data-action="code-run">Run</button>
                <button class="note-save-button" data-action="code-save">Save</button>
              </div>
              <textarea class="note-code-editor" spellcheck="false" aria-label="Coding workspace"></textarea>
              <div class="note-code-output" aria-live="polite">Run output will appear here.</div>
              <div class="note-code-status">New source file · Ctrl+S saves</div>
            </section>
            <section class="note-tool-panel note-terminal-panel" data-tool-panel-view="terminal" hidden>
              <div class="note-workspace-heading">
                <div><div class="note-kicker">USER TERMINAL</div><h2>Command line</h2></div>
                <span class="note-tool-caption">User-level DOS commands</span>
              </div>
              <form class="note-terminal-form" data-tool-form="terminal">
                <span class="note-terminal-prompt">nova@vents:C:\&gt;</span>
                <input class="note-terminal-input" placeholder="calc 12 * 4" spellcheck="false" aria-label="Terminal command" />
                <button>Run</button>
              </form>
              <pre class="note-terminal-output" aria-live="polite">Ready.</pre>
            </section>
          </section>
          ${isVents15 ? `<section class="note-view note-games-view" data-view="games" hidden>
            <div class="note-view-heading">
              <div><div class="note-kicker">VENTS ARCADE</div><h1>Games</h1></div>
              <span class="note-tool-caption">Built into Vents ${ventsVersion}</span>
            </div>
            <div class="note-games-grid">
              <button class="note-game-card" data-game="star-dash"><strong>Star Dash</strong><span>Dodge the asteroids.</span></button>
              <button class="note-game-card" data-game="pixel-pairs"><strong>Pixel Pairs</strong><span>Match the memory grid.</span></button>
              <button class="note-game-card" data-game="space-catcher"><strong>Space Catcher</strong><span>Catch falling stars.</span></button>
              <button class="note-game-card" data-game="number-sprint"><strong>Number Sprint</strong><span>Race the clock.</span></button>
              <button class="note-game-card" data-game="mines"><strong>Mines</strong><span>Find the safe squares.</span></button>
              <button class="note-game-card" data-game="word-grid"><strong>Word Grid</strong><span>Build words from pixels.</span></button>
              <button class="note-game-card" data-game="memory-match"><strong>Memory Match</strong><span>Remember the sequence.</span></button>
              <button class="note-game-card" data-game="safe-path"><strong>Safe Path</strong><span>Choose the secure route.</span></button>
            </div>
            <div class="note-game-stage" hidden tabindex="-1"></div>
            <pre class="note-game-output" aria-live="polite">Choose a game to play.</pre>
          </section>` : ""}
        </main>
      </div>
      <div class="note-context-menu" hidden role="menu">
        <button data-context-action="open">Open</button>
        <button data-context-action="new-file">New file</button>
        <button data-context-action="new-folder">New folder</button>
        <div class="note-context-divider"></div>
        <button data-context-action="copy">Copy</button>
        <button data-context-action="move">Move</button>
        <button data-context-action="rename">Rename</button>
        <button class="note-context-danger" data-context-action="delete">Delete</button>
        <div class="note-context-divider"></div>
        <button data-context-action="properties">Properties</button>
        <button data-context-action="refresh">Refresh</button>
      </div>
      <footer class="note-statusbar">
        <span class="note-status">Ready</span>
        <span class="note-status-context">User mode · graphical shell</span>
      </footer>
      ${isVents16 ? '</div>' : ""}
      ${isVents16 ? `<span class="v16-resize-handle v16-resize-nw" data-v16-resize="nw" aria-label="Resize My PC"></span>
      <span class="v16-resize-handle v16-resize-ne" data-v16-resize="ne" aria-label="Resize My PC"></span>
      <span class="v16-resize-handle v16-resize-sw" data-v16-resize="sw" aria-label="Resize My PC"></span>
      <span class="v16-resize-handle v16-resize-se" data-v16-resize="se" aria-label="Resize My PC"></span>` : ""}
    </section>
  `;
  document.body.appendChild(overlay);

  const windowElement = overlay.querySelector(".note-window");
  const bootScreen = overlay.querySelector(".note-boot-screen");
  const editor = overlay.querySelector(".note-editor");
  const filename = overlay.querySelector(".note-filename");
  const pathInput = overlay.querySelector(".note-path");
  const fileGrid = overlay.querySelector(".note-file-grid");
  const emptyState = overlay.querySelector(".note-empty-state");
  const entryCount = overlay.querySelector(".note-entry-count");
  const viewerTitle = overlay.querySelector(".note-viewer-title");
  const fileViewer = overlay.querySelector(".note-file-viewer");
  const status = overlay.querySelector(".note-status");
  const editorStat = overlay.querySelector(".note-editor-stat");
  const codePathInput = overlay.querySelector(".note-code-path");
  const codeLanguage = overlay.querySelector(".note-code-language");
  const codeFileList = overlay.querySelector(".note-code-file-list");
  const codeEditor = overlay.querySelector(".note-code-editor");
  const codeOutput = overlay.querySelector(".note-code-output");
  const codeStatus = overlay.querySelector(".note-code-status");
  const terminalInput = overlay.querySelector(".note-terminal-input");
  const terminalOutput = overlay.querySelector(".note-terminal-output");
  const contextMenu = overlay.querySelector(".note-context-menu");
  const desktopContextMenu = overlay.querySelector(".v16-desktop-context-menu");
  let currentPath = `${HOME()}/untitled.txt`;
  let currentDirectory = HOME();
  let selectedPath = null;
  let currentView = "files";
  let pathHistory = [currentDirectory];
  let pathHistoryIndex = 0;
  let dirty = false;
  let codeDirty = false;
  let activeToolPanel = "utilities";
  let gameCleanup = () => {};
  overlay.querySelector("[data-home-place]").dataset.path = HOME();
  filename.value = currentPath;
  codePathInput.value = `${HOME()}/program.js`;
  let bootTimer;
  let bootRemoveTimer;

  const GUI_EXCLUDED_COMMANDS = new Set([
    "who", "whoami", "id", "passwd", "acswitch", "tty", "ps", "tasklist",
    "reboot", "shutdown", "hostname", "ip", "network", "ping", "nslookup",
    "route", "diskfree", "label", "attrib", "verify", "prompt", "mem", "chkdsk",
    "ven", "turn", "more", "choose", "countdown", "sleep",
    "cd", "md", "rd", "copy", "move", "ren", "del", "delete", "write", "append",
    "truncate", "mkdir", "rmdir", "rm", "mv", "cp", "clear", "cls", "history",
    "open",
  ]);

  const CORE_FOLDERS = ["/usr", "/bin", "/etc", "/var"];
  let contextPath = null;

  const setStatus = (message, kind = "") => {
    status.textContent = message;
    status.className = `note-status${kind ? ` ${kind}` : ""}`;
  };

  const openMyPc = () => {
    if (!isVents16) return;
    windowElement.classList.add("is-open", "is-ready");
    fileGrid.focus();
    setStatus("My PC opened");
  };

  let v16MiniZIndex = 5;
  const v16MiniWindows = new Map();
  const focusV16MiniWindow = (miniWindow) => {
    v16MiniZIndex += 1;
    miniWindow.style.zIndex = v16MiniZIndex;
    overlay.querySelectorAll(".v16-mini-window").forEach((item) => item.classList.toggle("is-active", item === miniWindow));
  };
  const openV16MiniWindow = ({ app, title, content, setup }) => {
    const existing = v16MiniWindows.get(app);
    if (existing) {
      existing.hidden = false;
      focusV16MiniWindow(existing);
      return existing;
    }
    const miniWindow = document.createElement("section");
    miniWindow.className = "v16-mini-window";
    miniWindow.dataset.v16MiniApp = app;
    miniWindow.style.zIndex = ++v16MiniZIndex;
    miniWindow.innerHTML = `
      <header class="v16-mini-titlebar">
        <span>${escapeHtml(title)}</span>
        <div class="v16-mini-controls" aria-label="${escapeHtml(title)} window controls">
          <button type="button" data-v16-window-action="minimize" aria-label="Minimize ${escapeHtml(title)}">_</button>
          <button type="button" data-v16-window-action="maximize" aria-label="Maximize ${escapeHtml(title)}">□</button>
          <button type="button" data-v16-window-action="close" aria-label="Exit ${escapeHtml(title)}">×</button>
        </div>
      </header>
      <div class="v16-mini-body">${content}</div>
    `;
    overlay.appendChild(miniWindow);
    v16MiniWindows.set(app, miniWindow);
    const titlebar = miniWindow.querySelector(".v16-mini-titlebar");
    let drag = null;
    titlebar.addEventListener("pointerdown", (event) => {
      if (event.target.closest("button")) return;
      focusV16MiniWindow(miniWindow);
      const rect = miniWindow.getBoundingClientRect();
      drag = { x: event.clientX - rect.left, y: event.clientY - rect.top };
      titlebar.setPointerCapture(event.pointerId);
    });
    titlebar.addEventListener("pointermove", (event) => {
      if (!drag) return;
      miniWindow.style.left = `${Math.max(8, event.clientX - drag.x)}px`;
      miniWindow.style.top = `${Math.max(8, event.clientY - drag.y)}px`;
    });
    titlebar.addEventListener("pointerup", () => { drag = null; });
    titlebar.addEventListener("pointercancel", () => { drag = null; });
    miniWindow.addEventListener("pointerdown", () => focusV16MiniWindow(miniWindow));
    miniWindow.querySelector('[data-v16-window-action="minimize"]').addEventListener("click", () => {
      miniWindow.hidden = true;
    });
    miniWindow.querySelector('[data-v16-window-action="maximize"]').addEventListener("click", () => {
      const maximized = miniWindow.classList.toggle("is-maximized");
      const button = miniWindow.querySelector('[data-v16-window-action="maximize"]');
      button.textContent = maximized ? "❐" : "□";
      button.setAttribute("aria-label", `${maximized ? "Restore" : "Maximize"} ${title}`);
      focusV16MiniWindow(miniWindow);
    });
    miniWindow.querySelector('[data-v16-window-action="close"]').addEventListener("click", () => {
      v16MiniWindows.delete(app);
      miniWindow.remove();
    });
    setup?.(miniWindow);
    return miniWindow;
  };

  const openVntOutputWindow = async (path) => {
    const node = nodeAt(path);
    if (!node || node.type !== "file") return;
    const outputWindow = document.createElement("section");
    outputWindow.className = "note-window note-vnt-output-window";
    outputWindow.innerHTML = `<header class="note-titlebar"><span class="note-title">VNT output · ${escapeHtml(path.split("/").pop() || "application")}</span><button class="note-close" type="button" aria-label="Close VNT output">×</button></header><div class="note-vnt-output-status">Loading Vents application...</div><div class="note-vnt-output-body"><pre class="note-vnt-output-text"></pre></div>`;
    overlay.appendChild(outputWindow);
    const statusElement = outputWindow.querySelector(".note-vnt-output-status");
    const bodyElement = outputWindow.querySelector(".note-vnt-output-body");
    const textElement = outputWindow.querySelector(".note-vnt-output-text");
    outputWindow.querySelector(".note-close").addEventListener("click", () => outputWindow.remove());
    try {
      const packageInfo = parseVntPackage(node.content);
      statusElement.textContent = `Running ${packageInfo.manifest.name || path.split("/").pop()} · ${packageInfo.language}`;
      const webUnits = packageInfo.units.filter((unit) => ["html", "css", "javascript", "typescript"].includes(unit.language));
      const nativeUnits = packageInfo.units.filter((unit) => !webUnits.includes(unit));
      const hasWebPreview = webUnits.some((unit) => unit.language === "html" || unit.language === "css");
      if (hasWebPreview) {
        const htmlUnit = webUnits.find((unit) => unit.language === "html");
        const css = webUnits.filter((unit) => unit.language === "css").map((unit) => unit.source).join("\n");
        const js = webUnits.filter((unit) => ["javascript", "typescript"].includes(unit.language)).map((unit) => unit.source).join("\n\n");
        let preview = htmlUnit?.source || "<main><h1>VNT application</h1><p>CSS preview</p></main>";
        const injected = `${css ? `<style>${css}</style>` : ""}${js ? `<script>${js}</script>` : ""}`;
        const headIndex = preview.toLowerCase().indexOf("</head>");
        preview = headIndex >= 0 ? `${preview.slice(0, headIndex)}${injected}${preview.slice(headIndex)}` : `${injected}${preview}`;
        textElement.remove();
        const frame = document.createElement("iframe");
        frame.className = "code-preview-frame note-vnt-preview-frame";
        frame.title = "VNT application preview";
        frame.setAttribute("sandbox", "allow-scripts");
        frame.srcdoc = preview;
        bodyElement.appendChild(frame);
      } else {
        const chunks = [];
        for (const unit of packageInfo.units) {
          const result = await runCodeSource(unit.language, unit.source);
          chunks.push(`[${unit.path}]\n${result.output || "Program finished with no output."}`);
        }
        textElement.textContent = chunks.join("\n\n");
      }
      if (hasWebPreview && nativeUnits.length) {
        const nativeResults = [];
        for (const unit of nativeUnits) {
          const result = await runCodeSource(unit.language, unit.source);
          nativeResults.push(`[${unit.path}]\n${result.output || "Program finished with no output."}`);
        }
        const nativeText = nativeResults.join("\n\n");
        if (textElement.isConnected) textElement.textContent = nativeText;
        else {
          const pre = document.createElement("pre");
          pre.className = "note-vnt-output-text";
          pre.textContent = nativeText;
          bodyElement.appendChild(pre);
        }
      }
      statusElement.textContent = `Finished · ${packageInfo.units.length} linked file${packageInfo.units.length === 1 ? "" : "s"}`;
    } catch (error) {
      statusElement.textContent = "VNT application failed";
      textElement.textContent = error?.message || String(error);
      textElement.classList.add("has-error");
    }
  };

  const openV16App = (app) => {
    if (!isVents16) return;
    if (app === "my-pc") {
      openMyPc();
      return;
    }
    if (app === "terminal") {
      const miniWindow = openV16MiniWindow({
        app,
        title: "Terminal",
        content: `<div class="v16-terminal-app"><pre class="v16-terminal-output">NOVA DOS ${escapeHtml(state.version)} VENTS TERMINAL\nType HELP or VER.\n</pre><form class="v16-terminal-form"><span>C:\\&gt;</span><input autocomplete="off" spellcheck="false" aria-label="Terminal command" /><button type="submit">RUN</button></form></div>`,
        setup: (appWindow) => {
          const outputElement = appWindow.querySelector(".v16-terminal-output");
          const input = appWindow.querySelector(".v16-terminal-form input");
          appWindow.querySelector(".v16-terminal-form").addEventListener("submit", (event) => {
            event.preventDefault();
            const parsed = tokenize(input.value.trim());
            if (!parsed.cmd) return;
            outputElement.textContent += `\nC:\\> ${parsed.cmd} ${parsed.args.join(" ")}\n`;
            runGuiCommand(parsed.cmd.toLowerCase(), parsed.args, outputElement);
            input.value = "";
          });
          input.focus();
        },
      });
      focusV16MiniWindow(miniWindow);
      return;
    }
    if (app === "calculator") {
      const miniWindow = openV16MiniWindow({
        app,
        title: "Calculator",
        content: `<form class="v16-calculator-app"><input class="v16-calculator-input" value="12 * (4 + 3)" aria-label="Calculator expression" spellcheck="false" /><button type="submit">Calculate</button><output class="v16-calculator-output" aria-live="polite">Enter an expression.</output></form>`,
        setup: (appWindow) => {
          const form = appWindow.querySelector(".v16-calculator-app");
          const input = appWindow.querySelector(".v16-calculator-input");
          form.addEventListener("submit", (event) => {
            event.preventDefault();
            runGuiCommand("calc", [input.value], appWindow.querySelector(".v16-calculator-output"));
          });
          input.focus();
          input.select();
        },
      });
      focusV16MiniWindow(miniWindow);
      return;
    }
    if (app === "gnote") {
      const miniWindow = openV16MiniWindow({
        app,
        title: "G-note",
        content: `<div class="v16-gnote-app"><div class="v16-gnote-toolbar"><input class="v16-gnote-path" value="/home/user/untitled.txt" aria-label="G-note file path" spellcheck="false" /><button type="button" data-gnote-action="new">New</button><button type="button" data-gnote-action="save">Save</button></div><textarea class="v16-gnote-editor" aria-label="G-note editor" spellcheck="false"></textarea><div class="v16-gnote-status">New document</div></div>`,
        setup: (appWindow) => {
          const pathInput = appWindow.querySelector(".v16-gnote-path");
          const editor = appWindow.querySelector(".v16-gnote-editor");
          const statusText = appWindow.querySelector(".v16-gnote-status");
          const load = () => {
            const node = nodeAt(resolve(pathInput.value));
            editor.value = node?.type === "file" ? node.content : "";
            statusText.textContent = node?.type === "file" ? `Opened ${resolve(pathInput.value)}` : "New document";
          };
          appWindow.querySelector('[data-gnote-action="new"]').addEventListener("click", () => {
            editor.value = "";
            statusText.textContent = "New document · unsaved";
            editor.focus();
          });
          appWindow.querySelector('[data-gnote-action="save"]').addEventListener("click", () => {
            try {
              const saved = writeNoteFile(pathInput.value, editor.value);
              statusText.textContent = `Saved ${saved}`;
            } catch (error) {
              statusText.textContent = error?.message || String(error);
            }
          });
          load();
          editor.focus();
        },
      });
      focusV16MiniWindow(miniWindow);
      return;
    }
    if (app === "games") {
      const miniWindow = openV16MiniWindow({
        app,
        title: "Arcade",
        content: `<div class="v16-arcade-app">
          <div class="v16-arcade-intro"><span class="v16-app-kicker">NOVA ARCADE</span><strong>Pick a cartridge.</strong><span>Small games for a short break.</span></div>
          <div class="v16-arcade-tabs" role="tablist" aria-label="Arcade games">
            <button type="button" class="is-active" data-arcade-game="memory">Memory Match</button>
            <button type="button" data-arcade-game="sprint">Number Sprint</button>
            <button type="button" data-arcade-game="slots">Lucky 7</button>
          </div>
          <div class="v16-arcade-scorebar"><span data-arcade-status>Find every pair.</span><b data-arcade-score>0 pts</b></div>
          <div class="v16-arcade-stage" data-arcade-stage></div>
        </div>`,
        setup: (appWindow) => {
          const stage = appWindow.querySelector("[data-arcade-stage]");
          const status = appWindow.querySelector("[data-arcade-status]");
          const score = appWindow.querySelector("[data-arcade-score]");
          let timer = null;

          const renderMemory = () => {
            clearTimeout(timer);
            const symbols = ["◆", "★", "●", "▲", "✦", "■"];
            const deck = [...symbols, ...symbols].sort(() => Math.random() - 0.5);
            let flipped = [];
            const matched = new Set();
            let moves = 0;
            score.textContent = "0 pts";
            status.textContent = "Find every pair.";
            stage.innerHTML = `<div class="v16-memory-grid">${deck.map((symbol, index) => `<button type="button" class="v16-memory-card" data-card-index="${index}" aria-label="Hidden card ${index + 1}"><span>${symbol}</span></button>`).join("")}</div><div class="v16-game-hint">Click two cards to reveal a pair.</div>`;
            const cards = [...stage.querySelectorAll("[data-card-index]")];
            const updateScore = () => { score.textContent = `${matched.size * 10} pts · ${moves} ${moves === 1 ? "move" : "moves"}`; };
            cards.forEach((card) => card.addEventListener("click", () => {
              const index = Number(card.dataset.cardIndex);
              if (matched.has(index) || flipped.includes(index) || flipped.length === 2) return;
              card.classList.add("is-flipped");
              flipped.push(index);
              if (flipped.length < 2) return;
              moves++;
              const [first, second] = flipped;
              if (deck[first] === deck[second]) {
                matched.add(first);
                matched.add(second);
                cards[first].classList.add("is-matched");
                cards[second].classList.add("is-matched");
                flipped = [];
                status.textContent = matched.size === deck.length ? "Board cleared. Nice memory." : "Pair found.";
                updateScore();
                return;
              }
              status.textContent = "Not a pair — try again.";
              updateScore();
              timer = setTimeout(() => {
                cards[first].classList.remove("is-flipped");
                cards[second].classList.remove("is-flipped");
                flipped = [];
                status.textContent = "Find every pair.";
              }, 650);
            }));
          };

          const renderSprint = () => {
            clearTimeout(timer);
            let round = 0;
            let points = 0;
            const nextRound = () => {
              const target = Math.floor(Math.random() * 9) + 1;
              const choices = [target, ...Array.from({ length: 3 }, () => Math.floor(Math.random() * 9) + 1)];
              choices.sort(() => Math.random() - 0.5);
              stage.innerHTML = `<div class="v16-sprint-prompt">Tap <strong>${target}</strong></div><div class="v16-sprint-grid">${choices.map((value) => `<button type="button" data-sprint-value="${value}">${value}</button>`).join("")}</div><div class="v16-game-hint">Ten rounds. How quick can you be?</div>`;
              status.textContent = `Round ${round + 1} of 10.`;
              score.textContent = `${points} pts`;
              stage.querySelectorAll("[data-sprint-value]").forEach((button) => button.addEventListener("click", () => {
                const correct = Number(button.dataset.sprintValue) === target;
                if (correct) points += 10;
                round++;
                if (round >= 10) {
                  stage.innerHTML = `<div class="v16-game-finish"><strong>${points} points</strong><span>${points === 100 ? "Perfect run." : "Run it again and beat your score."}</span><button type="button" data-sprint-restart>Play again</button></div>`;
                  status.textContent = "Sprint complete.";
                  score.textContent = `${points} pts`;
                  stage.querySelector("[data-sprint-restart]").addEventListener("click", renderSprint);
                } else {
                  status.textContent = correct ? "Correct." : `The answer was ${target}.`;
                  nextRound();
                }
              }));
            };
            nextRound();
          };

          const renderSlots = () => {
            clearTimeout(timer);
            let points = 0;
            stage.innerHTML = `<div class="v16-slots-reel"><span data-slot-a>◆</span><span data-slot-b>★</span><span data-slot-c>●</span></div><button type="button" class="v16-slot-button" data-slot-spin>SPIN</button><div class="v16-game-hint">Match two symbols for 10 points. Match all three for 50.</div>`;
            const symbols = ["7", "★", "◆", "●", "✦"];
            const reels = [stage.querySelector("[data-slot-a]"), stage.querySelector("[data-slot-b]"), stage.querySelector("[data-slot-c]")];
            stage.querySelector("[data-slot-spin]").addEventListener("click", () => {
              const result = reels.map((reel) => symbols[Math.floor(Math.random() * symbols.length)]);
              result.forEach((value, index) => { reels[index].textContent = value; });
              const counts = result.reduce((map, value) => map.set(value, (map.get(value) || 0) + 1), new Map());
              const best = Math.max(...counts.values());
              const earned = best === 3 ? 50 : best === 2 ? 10 : 0;
              points += earned;
              status.textContent = earned ? `Jackpot energy: +${earned}.` : "No match. Spin again.";
              score.textContent = `${points} pts`;
            });
            status.textContent = "Ready to spin.";
            score.textContent = "0 pts";
          };

          const renderGame = (game) => {
            appWindow.querySelectorAll("[data-arcade-game]").forEach((tab) => tab.classList.toggle("is-active", tab.dataset.arcadeGame === game));
            if (game === "sprint") renderSprint();
            else if (game === "slots") renderSlots();
            else renderMemory();
          };

          appWindow.querySelectorAll("[data-arcade-game]").forEach((tab) => tab.addEventListener("click", () => renderGame(tab.dataset.arcadeGame)));
          renderMemory();
        },
      });
      focusV16MiniWindow(miniWindow);
      return;
    }
    if (app === "code") {
      const miniWindow = openV16MiniWindow({
        app,
        title: "Code",
        content: `<div class="v16-code-app">
          <aside class="v16-code-sidebar">
            <div class="v16-code-sidebar-head"><span>PROJECT FILES</span><button type="button" data-code-action="new" aria-label="New source file">+</button></div>
            <div class="v16-code-file-list" data-code-files></div>
            <div class="v16-code-sidebar-help">Connect files with the toolbar, then Run project.</div>
          </aside>
          <main class="v16-code-main">
            <div class="v16-code-toolbar">
              <select data-code-language aria-label="Programming language">
                <option value="javascript">JavaScript</option><option value="python">Python</option><option value="html">HTML</option><option value="css">CSS</option><option value="c">C</option><option value="rust">Rust</option><option value="cpp">C++</option><option value="assembly">Assembly</option><option value="wasm">WebAssembly</option>
              </select>
              <input data-code-path value="/home/user/program.js" aria-label="Source file path" spellcheck="false" />
              <button type="button" data-code-action="open">Open</button>
              <button type="button" data-code-action="save">Save</button>
              <button type="button" data-code-action="delete">Delete</button>
              <button type="button" data-code-action="connect">Connect</button>
              <button type="button" class="v16-code-run" data-code-action="run">Run</button>
              <button type="button" class="v16-code-project-run" data-code-action="run-project">Run project</button>
            </div>
            <div class="v16-code-editor-wrap"><textarea data-code-editor spellcheck="false" aria-label="Source code"></textarea><div data-code-output aria-live="polite">Ready.</div></div>
            <div class="v16-code-status" data-code-status>New JavaScript file · Ctrl+S saves</div>
          </main>
        </div>`,
        setup: (appWindow) => {
          const languageSelect = appWindow.querySelector("[data-code-language]");
          const pathInput = appWindow.querySelector("[data-code-path]");
          const editor = appWindow.querySelector("[data-code-editor]");
          const output = appWindow.querySelector("[data-code-output]");
          const status = appWindow.querySelector("[data-code-status]");
          const fileList = appWindow.querySelector("[data-code-files]");
          const defaults = CODE_STARTERS;
          const languageName = () => CODE_LANGUAGES[languageSelect.value]?.label || "Source";
          const setStatus = (message, kind = "") => {
            status.textContent = message;
            status.className = `v16-code-status${kind ? ` ${kind}` : ""}`;
          };
          const collectFiles = () => {
            const paths = [];
            const visit = (node, base) => {
              if (!node || node.type !== "dir") return;
              Object.entries(node.children || {}).forEach(([name, child]) => {
                const path = `${base}/${name}`.replace(/\/+/g, "/");
                if (child.type === "dir") visit(child, path);
                else if (CODE_SOURCE_EXTENSIONS.has(name.split(".").pop().toLowerCase())) paths.push(path);
              });
            };
            visit(fs, "");
            return paths.sort((a, b) => a.localeCompare(b));
          };
          const refreshFiles = () => {
            const activePath = resolve(pathInput.value);
            fileList.innerHTML = "";
            const paths = collectFiles();
            if (!paths.length) {
              fileList.innerHTML = `<div class="v16-code-empty-files">No saved source files yet.</div>`;
              return;
            }
            paths.forEach((path) => {
              const button = document.createElement("button");
              button.type = "button";
              button.className = `v16-code-file${path === activePath ? " is-active" : ""}`;
              button.dataset.codeFilePath = path;
              button.innerHTML = `<span>${escapeHtml(path.split("/").pop())}</span><small>${escapeHtml(CODE_LANGUAGES[codeLanguageForPath(path)]?.label || "Source")}</small>`;
              fileList.appendChild(button);
            });
          };
          const load = () => {
            const target = resolve(pathInput.value);
            const node = nodeAt(target);
            if (node?.type === "file") {
              editor.value = node.content || "";
              languageSelect.value = codeLanguageForPath(target);
              setStatus(`Opened ${target}`);
            } else {
              editor.value = defaults[languageSelect.value] || "";
              setStatus(`New ${languageName()} file at ${target}`);
            }
            output.textContent = "Ready.";
            refreshFiles();
            editor.focus();
          };
          const save = () => {
            try {
              const savedPath = writeNoteFile(pathInput.value, editor.value);
              pathInput.value = savedPath;
              setStatus(`Saved ${savedPath}`, "is-saved");
              refreshFiles();
            } catch (error) { setStatus(error?.message || String(error), "has-error"); }
          };
          const newFile = () => {
            const language = CODE_LANGUAGES[languageSelect.value] || CODE_LANGUAGES.javascript;
            pathInput.value = sourcePathForLanguage(`${HOME()}/program${language.defaultExtension}`, languageSelect.value, true);
            editor.value = defaults[languageSelect.value] || "";
            output.textContent = "Ready.";
            setStatus(`New ${language.label} file · unsaved`);
            refreshFiles();
            editor.focus();
          };
          const deleteFile = () => {
            const target = resolve(pathInput.value);
            const node = nodeAt(target);
            if (!node || node.type !== "file") {
              setStatus("Save a file before deleting it.", "has-error");
              return;
            }
            if (!window.confirm(`Delete ${target.split("/").pop()}?`)) return;
            const parent = nodeAt(target.split("/").slice(0, -1).join("/") || "/");
            if (parent?.type === "dir") delete parent.children[target.split("/").pop()];
            savePersistentState();
            newFile();
            setStatus(`Deleted ${target}`, "is-saved");
            refreshFiles();
          };
          const includeDirective = (path) => {
            const language = codeLanguageForPath(path);
            if (language === "python") return `# nova:include ${path}`;
            if (language === "html") return `<!-- nova:include ${path} -->`;
            if (language === "css") return `/* nova:include ${path} */`;
            if (language === "wasm") return `;; nova:include ${path}`;
            if (language === "assembly") return `# nova:include ${path}`;
            return `// nova:include ${path}`;
          };
          const connectFile = () => {
            const paths = collectFiles().filter((path) => path !== resolve(pathInput.value));
            if (!paths.length) {
              setStatus("Save another source file first.", "has-error");
              return;
            }
            const choice = window.prompt(`Connect which file?\n\n${paths.join("\n")}`, paths[0]);
            if (!choice) return;
            const target = resolve(choice.trim());
            if (nodeAt(target)?.type !== "file") {
              setStatus(`Source file not found: ${choice}`, "has-error");
              return;
            }
            const directive = includeDirective(target);
            if (!editor.value.includes(directive)) {
              editor.value = `${directive}\n${editor.value}`;
              save();
              setStatus(`Connected ${target.split("/").pop()} · saved`, "is-saved");
            } else setStatus(`${target.split("/").pop()} is already connected.`);
          };
          const connectedPaths = (entryPath) => {
            const order = [];
            const visited = new Set();
            const visit = (path) => {
              const target = resolve(path);
              if (visited.has(target)) return;
              const node = nodeAt(target);
              if (!node || node.type !== "file") return;
              visited.add(target);
              const source = String(node.content || "");
              const includes = /nova:include\s+([^\s*>'"]+)/g;
              let match;
              while ((match = includes.exec(source))) visit(match[1]);
              order.push(target);
            };
            visit(entryPath);
            return order;
          };
          const projectEntryFor = (path) => {
            const target = resolve(path);
            for (const candidate of collectFiles()) {
              if (candidate === target) continue;
              const group = connectedPaths(candidate);
              if (group.length > 1 && group.includes(target)) return candidate;
            }
            return target;
          };
          const runProject = async (requestedEntry = null) => {
            save();
            const entryPath = resolve(requestedEntry || pathInput.value);
            const paths = connectedPaths(entryPath);
            if (!paths.length) {
              setStatus("Save an entry file before running the project.", "has-error");
              return;
            }
            const languages = [...new Set(paths.map(codeLanguageForPath))];
            output.textContent = `Running project · ${paths.length} connected file${paths.length === 1 ? "" : "s"}...`;
            try {
              const entryLanguage = codeLanguageForPath(entryPath);
              const htmlPath = paths.find((path) => codeLanguageForPath(path) === "html");
              const cssSources = paths.filter((path) => codeLanguageForPath(path) === "css").map((path) => String(nodeAt(path)?.content || ""));
              const jsSources = paths.filter((path) => codeLanguageForPath(path) === "javascript").map((path) => String(nodeAt(path)?.content || ""));
              if (htmlPath && jsSources.length) {
                const html = String(nodeAt(htmlPath)?.content || "");
                const styles = cssSources.length ? `<style>${cssSources.join("\n")}</style>` : "";
                const scripts = `<script>${jsSources.join("\n\n")}</script>`;
                const webProject = /<\/head>/i.test(html)
                  ? html.replace(/<\/head>/i, `${styles}${scripts}</head>`)
                  : `${styles}${html}${scripts}`;
                renderCodePreview(output, "html", webProject);
                setStatus(`Web project preview ready · ${paths.length} files`, "is-saved");
                return;
              }
              if (entryLanguage === "html") {
                const html = String(nodeAt(entryPath)?.content || "");
                const css = paths.filter((path) => codeLanguageForPath(path) === "css").map((path) => String(nodeAt(path)?.content || "")).join("\n");
                renderCodePreview(output, "html", css ? `<style>${css}</style>${html}` : html);
                setStatus(`Project preview ready · ${paths.length} files`, "is-saved");
                return;
              }
              if (entryLanguage === "css") {
                const css = paths.filter((path) => codeLanguageForPath(path) === "css").map((path) => String(nodeAt(path)?.content || "")).join("\n");
                renderCodePreview(output, "css", css);
                setStatus(`Project preview ready · ${paths.length} files`, "is-saved");
                return;
              }
              if (languages.length === 1 && !["css", "html"].includes(entryLanguage)) {
                const source = paths.map((path) => String(nodeAt(path)?.content || "")).join("\n\n");
                const result = await runCodeSource(entryLanguage, source);
                setCodeOutputText(output, result.output);
                setStatus(result.failed ? "Project failed" : `Project complete · ${paths.length} files`, result.failed ? "has-error" : "is-saved");
                return;
              }
              const chunks = [];
              for (const path of paths) {
                const language = codeLanguageForPath(path);
                if (["html", "css"].includes(language)) {
                  chunks.push(`[${path}] ${language} file connected.`);
                  continue;
                }
                const result = await runCodeSource(language, nodeAt(path)?.content || "");
                chunks.push(`[${path}]\n${result.output}`);
              }
              setCodeOutputText(output, chunks.join("\n\n"));
              setStatus(`Project complete · ${paths.length} files · ${languages.length} languages`, "is-saved");
            } catch (error) {
              setCodeOutputText(output, error?.message || String(error));
              setStatus("Project failed", "has-error");
            }
          };
          const run = async () => {
            save();
            const entryPath = projectEntryFor(pathInput.value);
            const projectPaths = connectedPaths(entryPath);
            if (projectPaths.length > 1) {
              await runProject(entryPath);
              return;
            }
            const language = CODE_LANGUAGES[languageSelect.value] || CODE_LANGUAGES.javascript;
            const scan = scanFileForMalware(pathInput.value, editor.value);
            if (!scan.safe) {
              output.textContent = `Blocked by Nova Guard.\n${scan.threats.join("\n")}`;
              setStatus("Threat blocked", "has-error");
              return;
            }
            output.textContent = `Running ${language.label}...`;
            try {
              const result = await runCodeSource(languageSelect.value, editor.value);
              if (result.preview) {
                renderCodePreview(output, languageSelect.value, editor.value);
              } else {
                setCodeOutputText(output, result.output);
              }
              setStatus(result.failed ? "Run failed" : result.preview ? "Preview ready" : "Run complete", result.failed ? "has-error" : "is-saved");
            } catch (error) {
              setCodeOutputText(output, error?.message || String(error));
              setStatus("Run failed", "has-error");
            }
          };
          appWindow.querySelectorAll("[data-code-action]").forEach((button) => button.addEventListener("click", () => {
            const action = button.dataset.codeAction;
            if (action === "new") newFile();
            else if (action === "open") load();
            else if (action === "save") save();
            else if (action === "delete") deleteFile();
            else if (action === "connect") connectFile();
            else if (action === "run") run();
            else if (action === "run-project") runProject();
          }));
          languageSelect.addEventListener("change", () => {
            const language = CODE_LANGUAGES[languageSelect.value] || CODE_LANGUAGES.javascript;
            pathInput.value = sourcePathForLanguage(pathInput.value, languageSelect.value, true);
            editor.value = defaults[languageSelect.value] || editor.value;
            setStatus(`${language.label} selected · new file is ${pathInput.value.split("/").pop()}`);
          });
          editor.addEventListener("keydown", (event) => {
            if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
              event.preventDefault();
              save();
            }
            if (event.key === "Tab") {
              event.preventDefault();
              editor.setRangeText("    ", editor.selectionStart, editor.selectionEnd, "end");
            }
          });
          fileList.addEventListener("click", (event) => {
            const file = event.target.closest("[data-code-file-path]");
            if (!file) return;
            pathInput.value = file.dataset.codeFilePath;
            load();
          });
          load();
        },
      });
      focusV16MiniWindow(miniWindow);
      return;
    }
    if (app === "internet-installer") {
      const miniWindow = openV16MiniWindow({
        app,
        title: "Install Files From Internet",
        content: `<form class="v16-installer-app"><div class="v16-installer-copy">Download a file into NovaDOS user storage.</div><label>Internet URL<input class="v16-installer-url" type="url" placeholder="https://example.com/file.txt" required /></label><label>Destination folder<input class="v16-installer-destination" value="/home/user" placeholder="/home/user" required spellcheck="false" /></label><button class="v16-installer-submit" type="submit">Install file</button><output class="v16-installer-output" aria-live="polite">A destination folder is required.</output></form>`,
        setup: (appWindow) => {
          const form = appWindow.querySelector(".v16-installer-app");
          const urlInput = appWindow.querySelector(".v16-installer-url");
          const destinationInput = appWindow.querySelector(".v16-installer-destination");
          const outputElement = appWindow.querySelector(".v16-installer-output");
          const submit = appWindow.querySelector(".v16-installer-submit");
          form.addEventListener("submit", async (event) => {
            event.preventDefault();
            const link = urlInput.value.trim();
            const destinationText = destinationInput.value.trim();
            const destination = destinationText ? resolve(destinationText) : "";
            if (!link || !destinationText) {
              outputElement.textContent = "Enter both a URL and a destination folder.";
              return;
            }
            const destinationNode = nodeAt(destination);
            if (!destinationNode || destinationNode.type !== "dir") {
              outputElement.textContent = `Destination folder not found: ${destinationText}`;
              return;
            }
            if (!(await confirmVentsInternetInstall(link))) {
              outputElement.textContent = "Installation cancelled.";
              return;
            }
            submit.disabled = true;
            outputElement.textContent = "Downloading...";
            try {
              const result = await downloadFile(link, ({ loaded, total }) => {
                outputElement.textContent = total
                  ? `Downloading... ${Math.min(100, Math.round((loaded / total) * 100))}%`
                  : `Downloading... ${formatDownloadBytes(loaded)}`;
              });
              const scan = scanFileForMalware(result.filename, result.content);
              if (!scan.safe) {
                if (state.version === "1.5") {
                  const approved = await confirmSecurityScan(result.filename, scan, overlay, "install");
                  if (!approved) {
                    outputElement.textContent = `Installation cancelled: ${scan.threats.join(", ")}.`;
                    return;
                  }
                  outputElement.textContent = "Security override accepted. Saving file...";
                } else {
                  outputElement.textContent = "Legacy release: saving file without the NovaDOS 1.5 install prompt...";
                }
              }
              const savedPath = writeNoteFile(`${destination}/${result.filename}`, result.content, {
                contentType: result.contentType,
                bytes: result.bytes,
                rawBytes: result.rawBytes,
                sourceUrl: link,
              });
              refreshFiles();
              outputElement.textContent = `Installed ${result.filename} in ${savedPath}.`;
              setStatus(`Installed ${result.filename}`, "saved");
            } catch (error) {
              outputElement.textContent = error?.message || String(error);
            } finally {
              submit.disabled = false;
            }
          });
          urlInput.focus();
        },
      });
      focusV16MiniWindow(miniWindow);
    }
  };

  if (isVents16) {
    const titlebar = windowElement.querySelector(".note-titlebar");
    let dragState = null;
    const stopDragging = () => {
      dragState = null;
      windowElement.classList.remove("is-dragging");
    };
    titlebar.addEventListener("pointerdown", (event) => {
      if (event.target.closest("button")) return;
      const rect = windowElement.getBoundingClientRect();
      dragState = {
        startX: event.clientX,
        startY: event.clientY,
        startLeft: Number.parseFloat(windowElement.style.left) || windowElement.offsetLeft,
        startTop: Number.parseFloat(windowElement.style.top) || windowElement.offsetTop,
        offsetX: event.clientX - rect.left,
        offsetY: event.clientY - rect.top,
      };
      titlebar.setPointerCapture(event.pointerId);
      windowElement.classList.add("is-dragging");
    });
    titlebar.addEventListener("pointermove", (event) => {
      if (!dragState) return;
      const maxLeft = Math.max(8, overlay.clientWidth - windowElement.offsetWidth - 8);
      const maxTop = Math.max(8, overlay.clientHeight - windowElement.offsetHeight - 8);
      const left = Math.min(maxLeft, Math.max(8, dragState.startLeft + event.clientX - dragState.startX));
      const top = Math.min(maxTop, Math.max(8, dragState.startTop + event.clientY - dragState.startY));
      windowElement.style.left = `${left}px`;
      windowElement.style.top = `${top}px`;
    });
    titlebar.addEventListener("pointerup", stopDragging);
    titlebar.addEventListener("pointercancel", stopDragging);

    const minWidth = 180;
    const minHeight = 190;
    overlay.querySelectorAll("[data-v16-resize]").forEach((handle) => {
      let resizeState = null;
      const stopResizing = () => { resizeState = null; };
      handle.addEventListener("pointerdown", (event) => {
        event.preventDefault();
        event.stopPropagation();
        const rect = windowElement.getBoundingClientRect();
        resizeState = {
          direction: handle.dataset.v16Resize,
          startX: event.clientX,
          startY: event.clientY,
          left: Number.parseFloat(windowElement.style.left) || windowElement.offsetLeft,
          top: Number.parseFloat(windowElement.style.top) || windowElement.offsetTop,
          width: rect.width,
          height: rect.height,
        };
        handle.setPointerCapture(event.pointerId);
      });
      handle.addEventListener("pointermove", (event) => {
        if (!resizeState) return;
        const dx = event.clientX - resizeState.startX;
        const dy = event.clientY - resizeState.startY;
        const direction = resizeState.direction;
        let left = resizeState.left;
        let top = resizeState.top;
        let width = resizeState.width;
        let height = resizeState.height;
        if (direction.includes("e")) width = Math.max(minWidth, resizeState.width + dx);
        if (direction.includes("s")) height = Math.max(minHeight, resizeState.height + dy);
        if (direction.includes("w")) {
          width = Math.max(minWidth, resizeState.width - dx);
          left = resizeState.left + resizeState.width - width;
        }
        if (direction.includes("n")) {
          height = Math.max(minHeight, resizeState.height - dy);
          top = resizeState.top + resizeState.height - height;
        }
        left = Math.max(8, Math.min(left, overlay.clientWidth - minWidth - 8));
        top = Math.max(8, Math.min(top, overlay.clientHeight - minHeight - 8));
        width = Math.min(width, overlay.clientWidth - left - 8);
        height = Math.min(height, overlay.clientHeight - top - 8);
        windowElement.style.left = `${left}px`;
        windowElement.style.top = `${top}px`;
        windowElement.style.width = `${Math.max(minWidth, width)}px`;
        windowElement.style.height = `${Math.max(minHeight, height)}px`;
      });
      handle.addEventListener("pointerup", stopResizing);
      handle.addEventListener("pointercancel", stopResizing);
    });
  }

  const formatEntrySize = (node) => {
    if (node.type === "dir") return `${Object.keys(node.children || {}).length} items`;
    const length = String(node.content || "").length;
    return `${length} ${length === 1 ? "character" : "characters"}`;
  };

  const parentPath = (path) => {
    const parts = path.split("/").filter(Boolean);
    parts.pop();
    return parts.length ? `/${parts.join("/")}` : "/";
  };

  const isCoreFolder = (path) => CORE_FOLDERS.some((root) => path === root || path.startsWith(`${root}/`));

  const userForHomePath = (path) => {
    const match = path.match(/^\/home\/([^/]+)$/);
    return match && state.users[match[1]] ? match[1] : null;
  };

  const isUserHomePath = (path) => Boolean(userForHomePath(path));

  const isTextFile = (path, node) => {
    const extension = path.split(".").pop().toLowerCase();
    const textExtensions = new Set([
      "txt", "md", "markdown", "json", "js", "jsx", "ts", "tsx", "html", "htm", "css",
      "py", "csv", "log", "ini", "conf", "xml", "yaml", "yml", "sh", "bat", "cmd", "c",
      "cpp", "cc", "cxx", "c++", "h", "hpp", "hh", "hxx", "h++", "java", "rs", "go", "sql", "toml", "svg",
      "novdos", "vnt",
    ]);
    if (textExtensions.has(extension)) return true;
    return !/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(String(node.content || ""));
  };

  const showUserSwitchNotice = (username) => {
    const backdrop = document.createElement("div");
    backdrop.className = "note-modal-backdrop";
    backdrop.innerHTML = `
      <div class="note-modal" role="alertdialog" aria-modal="true" aria-labelledby="note-modal-title">
        <div class="note-modal-kicker">ACCOUNT PROTECTED</div>
        <h2 id="note-modal-title">Switch on the DOS</h2>
        <p>You have to switch to <strong>${escapeHtml(username)}</strong> on the DOS before opening that user’s home.</p>
        <button data-action="close-user-notice">Okay</button>
      </div>
    `;
    overlay.appendChild(backdrop);
    backdrop.querySelector("[data-action=close-user-notice]").focus();
    const closeNotice = () => backdrop.remove();
    backdrop.addEventListener("click", (event) => {
      if (event.target === backdrop || event.target.closest("[data-action=close-user-notice]")) closeNotice();
    });
  };

  const showProperties = (path) => {
    const node = nodeAt(path);
    if (!node) return;
    const name = path.split("/").pop() || "C:\\";
    const kind = node.type === "dir" ? "Folder" : "File";
    const details = node.type === "dir"
      ? `${Object.keys(node.children || {}).length} items`
      : `${String(node.content || "").length} characters`;
    setStatus(`${kind}: ${name} · ${details}`);
  };

  const hideContextMenu = () => {
    contextMenu.hidden = true;
    contextPath = null;
  };

  const hideDesktopContextMenu = () => {
    if (desktopContextMenu) desktopContextMenu.hidden = true;
  };

  const showDesktopContextMenu = (event) => {
    if (!desktopContextMenu) return;
    hideContextMenu();
    desktopContextMenu.hidden = false;
    const menuWidth = desktopContextMenu.offsetWidth || 210;
    const menuHeight = desktopContextMenu.offsetHeight || 220;
    desktopContextMenu.style.left = `${Math.min(event.clientX, Math.max(8, window.innerWidth - menuWidth - 8))}px`;
    desktopContextMenu.style.top = `${Math.min(event.clientY, Math.max(8, window.innerHeight - menuHeight - 8))}px`;
  };

  const showContextMenu = (event, path = null) => {
    contextPath = path;
    if (path) {
      selectedPath = path;
      refreshFiles();
    }
    const requiresSelection = ["open", "copy", "move", "rename", "delete", "properties"];
    contextMenu.querySelectorAll("[data-context-action]").forEach((item) => {
      item.disabled = requiresSelection.includes(item.dataset.contextAction) && !path;
    });
    contextMenu.hidden = false;
    contextMenu.style.left = `${Math.min(event.clientX, Math.max(8, window.innerWidth - 210))}px`;
    contextMenu.style.top = `${Math.min(event.clientY, Math.max(8, window.innerHeight - 330))}px`;
  };

  const refreshFiles = () => {
    const directory = nodeAt(currentDirectory);
    fileGrid.innerHTML = "";
    pathInput.value = currentDirectory;
    overlay.querySelectorAll(".note-place[data-path]").forEach((place) => {
      place.classList.toggle("is-active", place.dataset.path === currentDirectory);
    });
    if (!directory || directory.type !== "dir") {
      emptyState.hidden = false;
      entryCount.textContent = "Folder unavailable";
      return;
    }
    const entries = Object.entries(directory.children || {}).sort(([nameA, nodeA], [nameB, nodeB]) => {
      if (nodeA.type !== nodeB.type) return nodeA.type === "dir" ? -1 : 1;
      return nameA.localeCompare(nameB);
    });
    entryCount.textContent = `${entries.length} ${entries.length === 1 ? "item" : "items"}`;
    emptyState.hidden = entries.length > 0;
    for (const [name, node] of entries) {
      const path = `${currentDirectory}/${name}`.replace(/\/+/g, "/");
      const card = document.createElement("button");
      card.className = `note-file-card${selectedPath === path ? " is-selected" : ""}`;
      card.draggable = !isCoreFolder(path) && !isUserHomePath(path);
      card.dataset.path = path;
      card.dataset.type = node.type;
      card.setAttribute("role", "option");
      card.setAttribute("aria-selected", selectedPath === path ? "true" : "false");
      const icon = document.createElement("span");
      icon.className = `note-file-icon ${node.type === "dir" ? "is-folder" : "is-file"}`;
      icon.textContent = node.type === "dir" ? "□" : "▤";
      const label = document.createElement("span");
      label.className = "note-file-name";
      label.textContent = name;
      const meta = document.createElement("span");
      meta.className = "note-file-meta";
      meta.textContent = formatEntrySize(node);
      card.append(icon, label, meta);
      fileGrid.appendChild(card);
    }
  };

  const viewFile = (path) => {
    const node = nodeAt(path);
    if (!node || node.type !== "file") return;
    viewerTitle.textContent = path.split("/").pop() || "File contents";
    fileViewer.textContent = node.content || "(empty file)";
    showView("viewer");
    setStatus(`Viewing ${path}`);
  };

  const openPath = async (path, preapproved = false) => {
    const node = nodeAt(path);
    if (!node) return;
    if (node.type === "file" && !preapproved && !(await confirmFileOpen(path, overlay))) {
      setStatus("File open cancelled.", "dim");
      return;
    }
    if (isVents15 && state.version !== "1.5" && node.type === "file") {
      const scan = scanFileForMalware(path, node.content);
      if (!scan.safe) {
        setStatus(`Graphical antivirus blocked ${path}.`, "error");
        return;
      }
    }
   if (node.type === "dir") {
     const username = userForHomePath(path);
     if (username && username !== state.user) {
       showUserSwitchNotice(username);
       return;
     }
     navigate(path);
     return;
   }
    if (isVntFile(path)) {
      await openVntOutputWindow(path);
      return;
    }
   if (isDosProgramFile(path)) {
      const extension = isNovdosFile(path) ? ".NOVDOS" : ".COM";
      setStatus(`Run ${extension} programs from the DOS terminal with OPEN filename${extension}.`);
    } else if (CODE_SOURCE_EXTENSIONS.has(path.split(".").pop().toLowerCase())) {
      showView("tools");
      showToolPanel("coding");
      await loadCodeFile(path, true);
    } else if (isTextFile(path, node)) await loadFile(path, true);
    else viewFile(path);
  };

  const loadFile = async (path, preapproved = false) => {
    const node = nodeAt(resolve(path));
    if (!node || node.type !== "file") {
      setStatus(`Could not open ${path}.`, "error");
      return;
    }
    if (!preapproved && !(await confirmFileOpen(path, overlay))) {
      setStatus("File open cancelled.", "dim");
      return;
    }
    currentPath = resolve(path);
    filename.value = currentPath;
    editor.value = node.content;
    dirty = false;
    setStatus(`Opened ${currentPath}`);
    updateEditorStats();
    showView("editor");
    editor.focus();
  };

  const saveFile = () => {
    const requestedPath = filename.value.trim();
    if (!requestedPath) {
      setStatus("Enter a filename before saving.", "error");
      filename.focus();
      return;
    }
    try {
      currentPath = writeNoteFile(requestedPath, editor.value);
      filename.value = currentPath;
      dirty = false;
      setStatus(`Saved ${currentPath}`, "saved");
      refreshFiles();
    } catch (error) {
      setStatus(error.message || String(error), "error");
    }
  };

  const newFile = () => {
    currentPath = `${HOME()}/untitled.txt`;
    if (currentView === "files") currentPath = `${currentDirectory}/untitled.txt`;
    filename.value = currentPath;
    editor.value = "";
    dirty = true;
    setStatus("New document · unsaved", "unsaved");
    updateEditorStats();
    showView("editor");
    editor.focus();
  };

  const updateEditorStats = () => {
    const length = editor.value.length;
    const lines = editor.value ? editor.value.split(/\r?\n/).length : 0;
    editorStat.textContent = `${length} ${length === 1 ? "character" : "characters"} · ${lines} ${lines === 1 ? "line" : "lines"}`;
  };

  const setCodeStatus = (message, kind = "") => {
    codeStatus.textContent = message;
    codeStatus.className = `note-code-status${kind ? ` ${kind}` : ""}`;
  };

  const sourceExtensions = CODE_SOURCE_EXTENSIONS;
  const languageForPath = codeLanguageForPath;

  const refreshCodeFiles = () => {
    const selected = codePathInput.value;
    codeFileList.innerHTML = "<option value=\"\">Saved source files...</option>";
    for (const path of collectNoteFiles()) {
      const extension = path.split(".").pop().toLowerCase();
      if (!sourceExtensions.has(extension)) continue;
      const option = document.createElement("option");
      option.value = path;
      option.textContent = path;
      codeFileList.appendChild(option);
    }
    codeFileList.value = nodeAt(selected)?.type === "file" ? selected : "";
  };

  const loadCodeFile = async (path, preapproved = false) => {
    const target = resolve(path);
    const node = nodeAt(target);
    if (node?.type === "dir") {
      setCodeStatus(`${path}: is a folder`, "error");
      return;
    }
    if (node && !preapproved && !(await confirmFileOpen(target, overlay))) {
      setCodeStatus("File open cancelled.", "error");
      return;
    }
    codePathInput.value = target;
    codeLanguage.value = languageForPath(target);
    updateCodeLanguageUI();
    codeEditor.value = node?.content || "";
    codeDirty = false;
    setCodeStatus(node ? `Opened ${target}` : `New source file at ${target}`);
    refreshCodeFiles();
    codeEditor.focus();
  };

  const saveCodeFile = () => {
    const requestedPath = codePathInput.value.trim();
    if (!requestedPath) {
      setCodeStatus("Enter a source file path first.", "error");
      codePathInput.focus();
      return;
    }
    try {
      const savedPath = writeNoteFile(requestedPath, codeEditor.value);
      codePathInput.value = savedPath;
      codeDirty = false;
      setCodeStatus(`Saved ${savedPath}`, "saved");
      refreshCodeFiles();
      refreshFiles();
    } catch (error) {
      setCodeStatus(error.message || String(error), "error");
    }
  };

  const newCodeFile = () => {
    const language = CODE_LANGUAGES[codeLanguage.value] || CODE_LANGUAGES.javascript;
    const extension = language.defaultExtension;
    const languageName = language.label;
    const requestedName = window.prompt(`New ${languageName} file name`, `program${extension}`);
    if (!requestedName) return;
    const name = requestedName.includes(".") ? requestedName : `${requestedName}${extension}`;
    if (/[\\/]/.test(name)) {
      setCodeStatus("Use a file name, not a folder path.", "error");
      return;
    }
    const target = sourcePathForLanguage(`${currentDirectory}/${name}`, codeLanguage.value, true);
    codePathInput.value = target;
    codeEditor.value = CODE_STARTERS[codeLanguage.value] || "";
    codeDirty = true;
    setCodeStatus("New source file · unsaved", "unsaved");
    codeFileList.value = "";
    codeEditor.focus();
  };

  const updateCodeLanguageUI = () => {
    const language = CODE_LANGUAGES[codeLanguage.value] || CODE_LANGUAGES.javascript;
    const codeRunButton = overlay.querySelector('[data-action="code-run"]');
    codeRunButton.disabled = !language.runnable;
    codeRunButton.title = language.runnable
      ? `Run ${language.label} source`
      : `${language.label} files can be opened, edited, and saved here`;
  };

  const runCodeFile = async () => {
    const language = CODE_LANGUAGES[codeLanguage.value] || CODE_LANGUAGES.javascript;
    const scan = scanFileForMalware(codePathInput.value, codeEditor.value);
    if (!scan.safe) {
      codeOutput.textContent = `Graphical antivirus blocked ${codePathInput.value}.\n${scan.threats.join("\n")}`;
      setCodeStatus("Threat blocked", "error");
      return;
    }
    codeOutput.textContent = `Running ${language.label}...`;
    try {
      const result = await runCodeSource(codeLanguage.value, codeEditor.value);
      if (result.preview) {
        renderCodePreview(codeOutput, codeLanguage.value, codeEditor.value);
      } else {
        setCodeOutputText(codeOutput, result.output);
      }
      setCodeStatus(result.failed ? "Run failed" : result.preview ? "Preview ready" : "Run complete", result.failed ? "error" : "saved");
    } catch (error) {
      setCodeOutputText(codeOutput, error?.message || String(error));
      setCodeStatus("Run failed", "error");
    }
  };

  const showToolPanel = (panel) => {
    activeToolPanel = panel;
    overlay.querySelectorAll("[data-tool-panel-view]").forEach((section) => {
      section.hidden = section.dataset.toolPanelView !== panel;
    });
    overlay.querySelectorAll(".note-tool-tabs [data-tool-panel]").forEach((tab) => {
      tab.classList.toggle("is-active", tab.dataset.toolPanel === panel);
    });
    if (panel === "coding") codeEditor.focus();
    if (panel === "terminal") terminalInput.focus();
  };

  const showView = (view) => {
    currentView = view;
    overlay.querySelectorAll("[data-view]").forEach((section) => {
      section.hidden = section.dataset.view !== view;
    });
    overlay.querySelectorAll(".note-view-tabs button[data-action]").forEach((tab) => {
      tab.classList.toggle("is-active", tab.dataset.action === `view-${view}` || (view === "tools" && tab.dataset.action === "view-tools"));
    });
    const activePlaceAction = view === "tools" ? "view-tools" : view === "editor" ? "view-editor" : view === "games" ? "view-games" : view === "viewer" ? "view-files" : "";
    overlay.querySelectorAll(".note-place[data-action]").forEach((place) => {
      place.classList.toggle("is-active", place.dataset.action === activePlaceAction);
    });
    if (view !== "files") overlay.querySelectorAll(".note-place[data-path]").forEach((place) => place.classList.remove("is-active"));
    if (view === "files") refreshFiles();
    if (view === "editor") { updateEditorStats(); editor.focus(); }
    if (view === "tools") showToolPanel(activeToolPanel);
  };

  const navigate = (path, addHistory = true) => {
    const target = resolve(path);
    const node = nodeAt(target);
    if (!node || node.type !== "dir") {
      setStatus(`Folder not found: ${path}`, "error");
      return;
    }
    currentDirectory = target;
    selectedPath = null;
    if (addHistory && pathHistory[pathHistoryIndex] !== target) {
      pathHistory = pathHistory.slice(0, pathHistoryIndex + 1);
      pathHistory.push(target);
      pathHistoryIndex++;
    }
    showView("files");
    setStatus(`Browsing ${currentDirectory}`);
  };

  const selectedNode = () => selectedPath ? nodeAt(selectedPath) : null;

  const createFolder = () => {
    const name = window.prompt("New folder name", "New folder");
    if (!name || /[\\/]/.test(name.trim())) return;
    const cleanName = name.trim();
    const directory = nodeAt(currentDirectory);
    if (!directory || directory.children[cleanName]) {
      setStatus("A file or folder with that name already exists.", "error");
      return;
    }
    directory.children[cleanName] = { type: "dir", children: {} };
    savePersistentState();
    refreshFiles();
    setStatus(`Created ${cleanName}`, "saved");
  };

  const removeSelected = () => {
    const node = selectedNode();
    if (!node || !selectedPath) { setStatus("Select a file or folder first."); return; }
    const name = selectedPath.split("/").pop();
    if (!window.confirm(`Delete ${name}?`)) return;
    const parent = nodeAt(parentPath(selectedPath));
    if (!parent || parent.type !== "dir") return;
    delete parent.children[name];
    if (currentPath === selectedPath) newFile();
    selectedPath = null;
    savePersistentState();
    refreshFiles();
    setStatus(`Deleted ${name}`, "saved");
  };

  const renameSelected = () => {
    const node = selectedNode();
    if (!node || !selectedPath) { setStatus("Select a file or folder first."); return; }
    const oldName = selectedPath.split("/").pop();
    const newName = window.prompt("Rename to", oldName);
    if (!newName || /[\\/]/.test(newName.trim())) return;
    const cleanName = newName.trim();
    const parent = nodeAt(parentPath(selectedPath));
    if (!parent || parent.children[cleanName]) {
      setStatus("A file or folder with that name already exists.", "error");
      return;
    }
    parent.children[cleanName] = node;
    delete parent.children[oldName];
    if (currentPath === selectedPath) {
      currentPath = `${parentPath(selectedPath)}/${cleanName}`.replace(/\/+/g, "/");
      filename.value = currentPath;
    }
    selectedPath = `${parentPath(selectedPath)}/${cleanName}`.replace(/\/+/g, "/");
    savePersistentState();
    refreshFiles();
    setStatus(`Renamed to ${cleanName}`, "saved");
  };

  const cloneNode = (node) => node.type === "dir"
    ? { ...node, children: Object.fromEntries(Object.entries(node.children || {}).map(([name, child]) => [name, cloneNode(child)])) }
    : { ...node };

  const isProtectedMoveSource = (path) => isCoreFolder(path) || path === "/home" || isUserHomePath(path);
  const isProtectedMoveDestination = (path) => isCoreFolder(path) || path === "/home" || (isUserHomePath(path) && userForHomePath(path) !== state.user);

  const moveEntryToFolder = (sourcePath, destinationFolder) => {
    const sourceNode = nodeAt(sourcePath);
    const destinationNode = nodeAt(destinationFolder);
    if (!sourceNode || !destinationNode || destinationNode.type !== "dir") {
      setStatus("Drop target is not a folder.", "error");
      return false;
    }
    if (isProtectedMoveSource(sourcePath) || isProtectedMoveDestination(destinationFolder)) {
      setStatus("Core folders and other user homes are protected.", "error");
      return false;
    }
    if (sourceNode.type === "dir" && (destinationFolder === sourcePath || destinationFolder.startsWith(`${sourcePath}/`))) {
      setStatus("A folder cannot be moved inside itself.", "error");
      return false;
    }
    const name = sourcePath.split("/").pop();
    if (!name || destinationNode.children[name]) {
      setStatus("A file or folder with that name already exists.", "error");
      return false;
    }
    const sourceParent = nodeAt(parentPath(sourcePath));
    if (!sourceParent || sourceParent.type !== "dir") return false;
    destinationNode.children[name] = sourceNode;
    delete sourceParent.children[name];
    selectedPath = `${destinationFolder}/${name}`.replace(/\/+/g, "/");
    savePersistentState();
    refreshFiles();
    setStatus(`Moved ${name} to ${destinationFolder}`, "saved");
    return true;
  };

  const copyOrMoveSelected = (move = false) => {
    const node = selectedNode();
    if (!node || !selectedPath) { setStatus("Select a file or folder first."); return; }
    if (move && isProtectedMoveSource(selectedPath)) {
      setStatus("Core folders and user home folders cannot be moved.", "error");
      return;
    }
    const name = selectedPath.split("/").pop();
    const destination = window.prompt(move ? "Move to path" : "Copy to path", `${currentDirectory}/${name}-copy`);
    if (!destination) return;
    let target = resolve(destination);
    const targetNode = nodeAt(target);
    if (targetNode?.type === "dir") target = `${target}/${name}`;
    if (move && isProtectedMoveDestination(parentPath(target))) {
      setStatus("Core folders and other user homes are protected.", "error");
      return;
    }
    const targetParent = nodeAt(parentPath(target));
    const targetName = target.split("/").pop();
    if (!targetParent || targetParent.type !== "dir" || !targetName || targetParent.children[targetName]) {
      setStatus("Destination is not available.", "error");
      return;
    }
    targetParent.children[targetName] = move ? node : cloneNode(node);
    if (move) {
      const sourceParent = nodeAt(parentPath(selectedPath));
      delete sourceParent.children[name];
      selectedPath = target;
    }
    savePersistentState();
    refreshFiles();
    setStatus(`${move ? "Moved" : "Copied"} to ${target}`, "saved");
  };

  const updateVents = async () => {
    if (state.version !== "1.22") {
      setStatus("Vents 1.5 requires NovaDOS 1.22.", "error");
      return;
    }
    if (!isVents101) {
      setStatus("Vents is already updated.", "dim");
      return;
    }
    const source = ensureVentsUpdatePackage();
    const destination = ensureDirectoryAt("/usr/vents/1.5");
    const files = Object.entries(source.children || {});
    for (const [name, node] of files) {
      setStatus(`Copying Vents 1.5 file: ${name}...`, "unsaved");
      await new Promise((resolveCopy) => setTimeout(resolveCopy, 90));
      destination.children[name] = cloneNode(node);
    }
    state.ventsVersion = "1.5";
    savePersistentState();
    setStatus(`Copied ${files.length} Vents 1.5 update files. Restarting Vents...`, "saved");
    setTimeout(() => {
      close();
      openVentsDesktop();
    }, 450);
  };

  const updateVents16 = async () => {
    if (state.version !== "1.4") {
      setStatus("The Vents 1.6 update is only available on NovaDOS 1.4.", "error");
      return;
    }
    if (ventsVersion !== "1.5") {
      setStatus("Vents is already updated.", "dim");
      return;
    }
    const installedVents15 = nodeAt("/usr/vents/1.5");
    const source = installedVents15?.type === "dir" ? installedVents15 : ensureVentsUpdatePackage();
    const destination = ensureDirectoryAt("/usr/vents/1.6");
    const files = Object.entries(source.children || {});
    for (const [name, node] of files) {
      setStatus(`Copying Vents 1.6 file: ${name}...`, "unsaved");
      await new Promise((resolveCopy) => setTimeout(resolveCopy, 90));
      destination.children[name] = cloneNode(node);
    }
    state.ventsVersion = "1.6";
    savePersistentState();
    setStatus(`Copied ${files.length} Vents 1.6 update files. Restarting Vents...`, "saved");
    setTimeout(() => {
      close();
      openVentsDesktop();
    }, 450);
  };

  const downgradeVents = async () => {
    const targetVersion = isVents16 ? "1.5" : ventsVersion === "1.5" ? "1.01" : null;
    if (!targetVersion) {
      setStatus("This Vents version cannot be downgraded further.", "error");
      return;
    }
    if (targetVersion === "1.5" && state.version !== "1.4") {
      setStatus("Vents 1.6 is only available on NovaDOS 1.4.", "error");
      return;
    }
    state.ventsVersion = targetVersion;
    savePersistentState();
    setStatus(`Downgraded to Vents ${targetVersion}. Restarting Vents...`, "saved");
    setTimeout(() => {
      close();
      openVentsDesktop();
    }, 450);
  };

  const playVentsGame = (name) => {
    const gameLibrary = overlay.querySelector(".note-games-grid");
    const gameStage = overlay.querySelector(".note-game-stage");
    const gameOutput = overlay.querySelector(".note-game-output");
    const shuffle = (items) => {
      const copy = [...items];
      for (let index = copy.length - 1; index > 0; index--) {
        const swap = Math.floor(Math.random() * (index + 1));
        [copy[index], copy[swap]] = [copy[swap], copy[index]];
      }
      return copy;
    };
    const shell = (title, instructions) => {
      gameCleanup();
      gameLibrary.hidden = true;
      gameStage.hidden = false;
      gameStage.innerHTML = `
        <div class="note-game-heading"><strong>${title}</strong><span>${instructions}</span></div>
        <div class="note-game-info">Get ready.</div>
        <div class="note-game-board"></div>
        <button class="note-game-back" type="button" data-game-back>Back to games</button>
      `;
      gameStage.focus();
      const info = gameStage.querySelector(".note-game-info");
      const board = gameStage.querySelector(".note-game-board");
      const finish = (message, won = false) => {
        gameCleanup();
        gameCleanup = () => {};
        info.textContent = message;
        gameOutput.textContent = `${won ? "✓" : "■"} ${title}\n\n${message}`;
        board.querySelectorAll("button").forEach((button) => { button.disabled = true; });
        setStatus(`${title}: ${won ? "you won" : "game over"}.`, won ? "saved" : "error");
      };
      return { board, info, finish };
    };

    if (name === "star-dash") {
      const { board, info, finish } = shell("Star Dash", "Use ←/→ or the buttons to dodge falling asteroids.");
      board.innerHTML = `<div class="note-star-dash-grid"></div><div class="note-game-controls"><button type="button" data-dash="left">← Left</button><button type="button" data-dash="right">Right →</button></div>`;
      const grid = board.querySelector(".note-star-dash-grid");
      let lane = 1;
      let score = 0;
      let shields = 3;
      let obstacles = [];
      let ended = false;
      const render = () => {
        grid.innerHTML = "";
        for (let row = 0; row < 6; row++) {
          for (let column = 0; column < 3; column++) {
            const cell = document.createElement("span");
            cell.className = "note-dash-cell";
            if (row === 5 && column === lane) cell.classList.add("is-player");
            if (obstacles.some((obstacle) => obstacle.row === row && obstacle.lane === column)) cell.classList.add("is-rock");
            grid.appendChild(cell);
          }
        }
        info.textContent = `Score ${score}/15 · Shields ${shields}`;
      };
      const move = (direction) => { lane = Math.max(0, Math.min(2, lane + direction)); render(); };
      const onKey = (event) => {
        if (event.key === "ArrowLeft") { move(-1); event.preventDefault(); }
        if (event.key === "ArrowRight") { move(1); event.preventDefault(); }
      };
      overlay.addEventListener("keydown", onKey);
      board.addEventListener("click", (event) => {
        if (event.target.dataset.dash === "left") move(-1);
        if (event.target.dataset.dash === "right") move(1);
      });
      const timer = setInterval(() => {
        if (ended) return;
        obstacles = obstacles.map((obstacle) => ({ ...obstacle, row: obstacle.row + 1 }));
        if (obstacles.some((obstacle) => obstacle.row === 5 && obstacle.lane === lane)) {
          shields--;
          obstacles = obstacles.filter((obstacle) => !(obstacle.row === 5 && obstacle.lane === lane));
        }
        obstacles = obstacles.filter((obstacle) => obstacle.row < 6);
        obstacles.push({ lane: Math.floor(Math.random() * 3), row: 0 });
        score++;
        render();
        if (shields <= 0) { ended = true; finish("The asteroid field got you. Try changing lanes sooner."); }
        else if (score >= 15) { ended = true; finish("You reached the station without losing all your shields!", true); }
      }, 520);
      gameCleanup = () => { clearInterval(timer); overlay.removeEventListener("keydown", onKey); };
      render();
      return;
    }

    if (name === "pixel-pairs") {
      const { board, info, finish } = shell("Pixel Pairs", "Reveal two tiles at a time and match every pair.");
      const symbols = ["★", "◆", "●", "▲", "■", "☀", "☁", "✦"];
      const cards = shuffle([...symbols, ...symbols]);
      board.innerHTML = `<div class="note-memory-grid"></div>`;
      const grid = board.querySelector(".note-memory-grid");
      let first = null;
      let matched = 0;
      let locked = false;
      cards.forEach((symbol, index) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "note-memory-card";
        button.textContent = "?";
        button.dataset.index = index;
        button.addEventListener("click", () => {
          if (locked || button.classList.contains("is-matched") || button === first) return;
          button.textContent = symbol;
          button.classList.add("is-open");
          if (!first) { first = button; return; }
          locked = true;
          const second = button;
          if (cards[first.dataset.index] === cards[second.dataset.index]) {
            first.classList.add("is-matched");
            second.classList.add("is-matched");
            matched++;
            first = null;
            locked = false;
            info.textContent = `${matched}/8 pairs matched`;
            if (matched === 8) finish("Every pixel pair matched!", true);
          } else {
            setTimeout(() => {
              first.textContent = "?";
              second.textContent = "?";
              first.classList.remove("is-open");
              second.classList.remove("is-open");
              first = null;
              locked = false;
            }, 650);
          }
        });
        grid.appendChild(button);
      });
      info.textContent = "0/8 pairs matched";
      gameCleanup = () => { grid.replaceChildren(); };
      return;
    }

    if (name === "space-catcher") {
      const { board, info, finish } = shell("Space Catcher", "Click the moving star ten times before time runs out.");
      board.innerHTML = `<div class="note-catcher-arena"><button class="note-catcher-target" type="button">★</button></div>`;
      const arena = board.querySelector(".note-catcher-arena");
      const target = board.querySelector(".note-catcher-target");
      let caught = 0;
      let seconds = 20;
      const place = () => {
        target.style.left = `${8 + Math.random() * 78}%`;
        target.style.top = `${8 + Math.random() * 70}%`;
      };
      const timer = setInterval(() => {
        seconds--;
        info.textContent = `${caught}/10 stars · ${seconds}s left`;
        place();
        if (seconds <= 0) finish(`Time up — you caught ${caught}/10 stars.`);
      }, 1000);
      target.addEventListener("click", () => {
        caught++;
        info.textContent = `${caught}/10 stars · ${seconds}s left`;
        place();
        if (caught >= 10) finish("You caught the whole constellation!", true);
      });
      gameCleanup = () => { clearInterval(timer); arena.replaceChildren(); };
      place();
      info.textContent = "0/10 stars · 20s left";
      return;
    }

    if (name === "number-sprint") {
      const { board, info, finish } = shell("Number Sprint", "Click the numbers from 1 to 16 as quickly as possible.");
      const numbers = shuffle(Array.from({ length: 16 }, (_, index) => index + 1));
      board.innerHTML = `<div class="note-number-grid"></div>`;
      const grid = board.querySelector(".note-number-grid");
      let next = 1;
      let seconds = 0;
      const timer = setInterval(() => { seconds++; info.textContent = `Next: ${next} · ${seconds}s`; }, 1000);
      numbers.forEach((number) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "note-number-button";
        button.textContent = number;
        button.addEventListener("click", () => {
          if (number !== next) { info.textContent = `Next: ${next} · ${seconds}s`; return; }
          button.classList.add("is-correct");
          button.disabled = true;
          next++;
          if (next > 16) finish(`Finished in ${seconds} seconds!`, true);
          else info.textContent = `Next: ${next} · ${seconds}s`;
        });
        grid.appendChild(button);
      });
      gameCleanup = () => clearInterval(timer);
      info.textContent = "Next: 1 · 0s";
      return;
    }

    if (name === "mines") {
      const { board, info, finish } = shell("Mines", "Reveal every safe square without hitting a mine.");
      const mineIndexes = new Set(shuffle(Array.from({ length: 16 }, (_, index) => index)).slice(0, 3));
      board.innerHTML = `<div class="note-mines-grid"></div>`;
      const grid = board.querySelector(".note-mines-grid");
      let safe = 0;
      for (let index = 0; index < 16; index++) {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "note-mine-button";
        button.textContent = "?";
        button.addEventListener("click", () => {
          if (button.disabled) return;
          button.disabled = true;
          if (mineIndexes.has(index)) {
            button.textContent = "✹";
            button.classList.add("is-mine");
            finish("Boom! You found a mine.");
          } else {
            button.textContent = "·";
            button.classList.add("is-safe");
            safe++;
            info.textContent = `${safe}/13 safe squares found`;
            if (safe === 13) finish("Minefield cleared. Excellent route planning!", true);
          }
        });
        grid.appendChild(button);
      }
      info.textContent = "0/13 safe squares found";
      return;
    }

    if (name === "word-grid") {
      const { board, info, finish } = shell("Word Grid", "Click letters in order to spell NOVA.");
      const targetWord = "NOVA";
      const letters = shuffle(["N", "O", "V", "A", "X", "D", "S", "P", "E", "L", "L", "R"]);
      board.innerHTML = `<div class="note-letter-grid"></div>`;
      const grid = board.querySelector(".note-letter-grid");
      let next = 0;
      letters.forEach((letter) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "note-letter-button";
        button.textContent = letter;
        button.addEventListener("click", () => {
          if (letter !== targetWord[next]) {
            button.classList.add("is-wrong");
            setTimeout(() => button.classList.remove("is-wrong"), 300);
            return;
          }
          button.disabled = true;
          button.classList.add("is-correct");
          next++;
          info.textContent = `${targetWord.slice(0, next)}${"_".repeat(targetWord.length - next)}`;
          if (next === targetWord.length) finish("NOVA completed!", true);
        });
        grid.appendChild(button);
      });
      info.textContent = "____";
      return;
    }

    if (name === "memory-match") {
      const { board, info, finish } = shell("Memory Match", "Watch the sequence, then repeat it.");
      const colors = ["red", "blue", "green", "yellow"];
      board.innerHTML = `<div class="note-simon-grid">${colors.map((color) => `<button type="button" class="note-simon-button is-${color}" data-color="${color}">${color}</button>`).join("")}</div>`;
      const buttons = [...board.querySelectorAll(".note-simon-button")];
      const sequence = Array.from({ length: 5 }, () => colors[Math.floor(Math.random() * colors.length)]);
      let position = 0;
      let accepting = false;
      const showSequence = async () => {
        accepting = false;
        info.textContent = "Watch carefully...";
        for (const color of sequence) {
          const button = buttons.find((item) => item.dataset.color === color);
          button.classList.add("is-lit");
          await new Promise((resolveFlash) => setTimeout(resolveFlash, 420));
          button.classList.remove("is-lit");
          await new Promise((resolveGap) => setTimeout(resolveGap, 140));
        }
        accepting = true;
        info.textContent = "Your turn — repeat the sequence.";
      };
      buttons.forEach((button) => button.addEventListener("click", () => {
        if (!accepting) return;
        if (button.dataset.color !== sequence[position]) {
          accepting = false;
          finish("Wrong sequence. Memory banks need a reset.");
          return;
        }
        position++;
        if (position === sequence.length) finish("Perfect memory! Sequence repeated.", true);
      }));
      gameCleanup = () => { accepting = false; };
      showSequence();
      return;
    }

    if (name === "safe-path") {
      const { board, info, finish } = shell("Safe Path", "Choose one tile per row. Reach the bottom without a trap.");
      const safeIndexes = Array.from({ length: 5 }, () => Math.floor(Math.random() * 4));
      board.innerHTML = `<div class="note-path-grid"></div>`;
      const grid = board.querySelector(".note-path-grid");
      let row = 0;
      for (let currentRow = 0; currentRow < 5; currentRow++) {
        for (let column = 0; column < 4; column++) {
          const button = document.createElement("button");
          button.type = "button";
          button.className = "note-path-button";
          button.textContent = "□";
          button.dataset.row = currentRow;
          button.dataset.column = column;
          button.addEventListener("click", () => {
            if (Number(button.dataset.row) !== row) return;
            if (Number(button.dataset.column) !== safeIndexes[row]) {
              button.textContent = "×";
              button.classList.add("is-trap");
              finish(`Trap on row ${row + 1}. Try another path.`);
              return;
            }
            button.textContent = "✓";
            button.classList.add("is-safe");
            row++;
            if (row === 5) finish("You found the secure route!", true);
            else info.textContent = `Choose a tile on row ${row + 1} of 5.`;
          });
          grid.appendChild(button);
        }
      }
      info.textContent = "Choose a tile on row 1 of 5.";
      return;
    }
  };

  const checkFilesystemHealth = () => {
    let files = 0;
    let folders = 0;
    let invalid = 0;
    const visit = (node) => {
      if (!node || !["file", "dir"].includes(node.type)) {
        invalid++;
        return;
      }
      if (node.type === "file") {
        files++;
        return;
      }
      folders++;
      Object.values(node.children || {}).forEach(visit);
    };
    visit(fs);
    return { files, folders, invalid };
  };

  const confirmVentsInternetInstall = (url = "") => new Promise((resolve) => {
    const backdrop = document.createElement("div");
    backdrop.className = "note-modal-backdrop";
    backdrop.innerHTML = `
      <div class="note-modal note-internet-disclaimer" role="alertdialog" aria-modal="true" aria-labelledby="internet-disclaimer-title">
        <div class="note-modal-kicker">INTERNET FILE DISCLAIMER</div>
        <h2 id="internet-disclaimer-title">Continue download?</h2>
        <p>Files from the internet can be useful, but they may also be dangerous. Only continue if you trust the source.</p>
        ${url ? `<p class="note-disclaimer-url">${escapeHtml(url)}</p>` : ""}
        <div class="note-disclaimer-options">
          <button type="button" data-disclaimer-choice="yes">Yes, continue</button>
          <button type="button" data-disclaimer-choice="no">No, cancel</button>
        </div>
      </div>
    `;
    overlay.appendChild(backdrop);
    const buttons = [...backdrop.querySelectorAll("[data-disclaimer-choice]")];
    let index = 0;
    let closed = false;
    const finish = (accepted) => {
      if (closed) return;
      closed = true;
      backdrop.remove();
      resolve(accepted);
    };
    const render = () => buttons.forEach((button, buttonIndex) => {
      button.classList.toggle("is-selected", buttonIndex === index);
    });
    buttons[0].focus();
    render();
    backdrop.addEventListener("click", (event) => {
      const choice = event.target.closest("[data-disclaimer-choice]")?.dataset.disclaimerChoice;
      if (choice) finish(choice === "yes");
    });
    backdrop.addEventListener("keydown", (event) => {
      if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
        index = index === 0 ? 1 : 0;
        buttons[index].focus();
        render();
        event.preventDefault();
      } else if (event.key === "Enter") {
        finish(index === 0);
        event.preventDefault();
      } else if (event.key === "Escape") {
        finish(false);
        event.preventDefault();
      }
    });
  });

  const downloadFromInternet = async () => {
    if (!hasInternetDownloads) {
      setStatus("Downloading from the internet requires NovaDOS 1.2. Run UPGRADE first.", "error");
      return;
    }
    const url = window.prompt("Download a file from the internet — enter the link:");
    if (!url || !url.trim()) return;
    const link = url.trim();
    const destinationInput = window.prompt("Enter the destination folder path (required):");
    if (!destinationInput || !destinationInput.trim()) {
      setStatus("A destination folder is required.", "error");
      return;
    }
    const dest = resolve(destinationInput.trim());
    const destinationNode = nodeAt(dest);
    if (!destinationNode || destinationNode.type !== "dir") {
      setStatus(`Destination folder not found: ${destinationInput.trim()}`, "error");
      return;
    }
    if (!(await confirmVentsInternetInstall(link))) {
      setStatus("Internet download cancelled.", "dim");
      return;
    }
    setStatus(`Downloading ${link}...`, "unsaved");
    try {
      const result = await downloadFile(link, ({ loaded, total }) => {
        const size = formatDownloadBytes(loaded);
        const status = total
          ? `${Math.min(100, Math.round((loaded / total) * 100))}% (${size} / ${formatDownloadBytes(total)})`
          : size;
        setStatus(`Downloading file... ${status}`, "unsaved");
      });
      if (state.version === "1.5") {
        const scan = scanFileForMalware(result.filename, result.content);
        if (!scan.safe) {
          if (!(await confirmSecurityScan(result.filename, scan, overlay, "install"))) {
            setStatus(`Installation cancelled for ${result.filename}.`, "error");
            return;
          }
          setStatus(`Security override accepted for ${result.filename}.`, "unsaved");
        }
      }
      const savedPath = writeNoteFile(`${dest}/${result.filename}`, result.content, {
        contentType: result.contentType,
        bytes: result.bytes,
        rawBytes: result.rawBytes,
        sourceUrl: link,
      });
      refreshFiles();
      setStatus(`Downloaded ${result.filename} (${formatDownloadBytes(result.bytes)}) into ${savedPath}.`, "saved");
    } catch (error) {
      const message = error && error.message ? error.message : String(error);
      setStatus(`Download failed: ${message}`, "error");
    }
  };

  const runGuiCommand = async (name, args, outputElement) => {
    const command = commands[name];
    if (!command || GUI_EXCLUDED_COMMANDS.has(name)) {
      outputElement.textContent = `${name || "command"}: unavailable in Vents user mode.`;
      return;
    }
    const lines = [];
    const guiContext = Object.create(ctx);
    guiContext.args = args;
    guiContext.print = (text, cls = "") => String(text).split("\n").forEach((line) => lines.push({ text: line, cls }));
    guiContext.printHtml = (html, cls = "") => lines.push({ text: String(html).replace(/<[^>]*>/g, ""), cls });
    guiContext.clear = () => { lines.length = 0; };
    guiContext.progress = (text) => lines.push({ text, cls: "dim" });
    guiContext.confirmInternetInstall = (url) => confirmVentsInternetInstall(url);
    outputElement.textContent = `Running ${name}...`;
    try {
      await command(guiContext);
    } catch (error) {
      lines.push({ text: error?.message || String(error), cls: "err" });
    }
    outputElement.textContent = lines.map(({ text }) => text).join("\n") || "Done.";
    refreshFiles();
    savePersistentState();
  };

  const searchFiles = (query) => {
    const needle = query.trim().toLowerCase();
    if (!needle) return "Enter a search term.";
    const matches = [];
    for (const path of collectNoteFiles()) {
      const node = nodeAt(path);
      if (path.toLowerCase().includes(needle) || String(node?.content || "").toLowerCase().includes(needle)) matches.push(path);
    }
    return matches.length ? matches.join("\n") : "No matches.";
  };

  const close = () => {
    clearTimeout(bootTimer);
    clearTimeout(bootRemoveTimer);
    gameCleanup();
    gameCleanup = () => {};
    overlay.remove();
    activeNote = null;
    finish();
    focusInput();
  };

  activeNote = { promise, close };
  refreshFiles();
  refreshCodeFiles();
  updateCodeLanguageUI();

  bootTimer = setTimeout(() => {
    windowElement.classList.add("is-ready");
    bootScreen.classList.add("is-complete");
    bootRemoveTimer = setTimeout(() => bootScreen.remove(), 360);
    if (isVents16) {
      if (initialPath) {
        openMyPc();
        openPath(initialPath, preapprovedPath === initialPath);
      }
    } else {
      fileGrid.focus();
      if (initialPath) openPath(initialPath, preapprovedPath === initialPath);
    }
  }, 1500);

  overlay.addEventListener("click", (event) => {
    const desktopContextAction = event.target.closest("[data-v16-context-action]")?.dataset.v16ContextAction;
    if (desktopContextAction) {
      hideDesktopContextMenu();
      if (desktopContextAction === "open-my-pc") openV16App("my-pc");
      else if (desktopContextAction === "refresh") setStatus("Desktop refreshed");
      else if (desktopContextAction === "new-file") {
        openMyPc();
        showView("files");
        newFile();
      } else if (desktopContextAction === "new-folder") {
        openMyPc();
        showView("files");
        createFolder();
      } else if (desktopContextAction === "properties") {
        setStatus(`Vents ${ventsVersion} desktop · ${Object.keys(nodeAt(HOME())?.children || {}).length} user items`);
      }
      return;
    }
    const desktopAction = event.target.closest("[data-v16-desktop-action]")?.dataset.v16DesktopAction;
    if (isVents16 && desktopAction) {
      if (desktopAction === "shutdown") {
        print("Vents shut down.", "dim");
      } else if (desktopAction === "dos") {
        print("Returning to NovaDOS.", "dim");
      }
      close();
      return;
    }
    const toolPanel = event.target.closest("[data-tool-panel]")?.dataset.toolPanel;
    if (toolPanel) {
      showToolPanel(toolPanel);
      return;
    }
    const contextAction = event.target.closest("[data-context-action]")?.dataset.contextAction;
    if (contextAction) {
      const selectedContextPath = contextPath;
      hideContextMenu();
      if (contextAction === "open" && selectedContextPath) openPath(selectedContextPath);
      else if (contextAction === "new-file") newFile();
      else if (contextAction === "new-folder") createFolder();
      else if (contextAction === "copy") copyOrMoveSelected(false);
      else if (contextAction === "move") copyOrMoveSelected(true);
      else if (contextAction === "rename") renameSelected();
      else if (contextAction === "delete") removeSelected();
      else if (contextAction === "properties" && selectedContextPath) showProperties(selectedContextPath);
      else if (contextAction === "refresh") { refreshFiles(); setStatus("Files refreshed"); }
      return;
    }
    if (!event.target.closest(".note-context-menu")) hideContextMenu();
    if (!event.target.closest(".v16-desktop-context-menu")) hideDesktopContextMenu();
    const action = event.target.closest("[data-action]")?.dataset.action;
    if (!action) return;
    if (action === "view-files") showView("files");
    else if (action === "view-editor") showView("editor");
    else if (action === "view-tools") showView("tools");
    else if (action === "view-games") showView("games");
    else if (action === "refresh") { refreshFiles(); setStatus("Files refreshed"); }
    else if (action === "back") {
      if (pathHistoryIndex > 0) { pathHistoryIndex--; currentDirectory = pathHistory[pathHistoryIndex]; showView("files"); }
    } else if (action === "up") navigate(parentPath(currentDirectory));
    else if (action === "home") navigate(HOME());
    else if (action === "go-path") navigate(pathInput.value);
    else if (action === "new-file") newFile();
    else if (action === "new-folder") createFolder();
    else if (action === "save") saveFile();
    else if (action === "save-as") {
      filename.focus();
      filename.select();
      setStatus("Enter a new path, then press Save.");
    } else if (action === "code-new") newCodeFile();
    else if (action === "code-open") loadCodeFile(codePathInput.value);
    else if (action === "code-run") runCodeFile();
    else if (action === "code-save") saveCodeFile();
    else if (action === "rename") renameSelected();
    else if (action === "delete") removeSelected();
    else if (action === "copy") copyOrMoveSelected(false);
    else if (action === "move") copyOrMoveSelected(true);
    else if (action === "download-internet") downloadFromInternet();
    else if (action === "update-vents") updateVents();
    else if (action === "update-vents-16") updateVents16();
    else if (action === "downgrade-vents") downgradeVents();
    else if (action === "maximize-app") {
      if (isVents16 && event.target.closest(".v16-my-pc-window")) {
        const maximized = windowElement.classList.toggle("is-maximized");
        const button = event.target.closest("[data-action=\"maximize-app\"]");
        button.textContent = maximized ? "❐" : "□";
        button.setAttribute("aria-label", maximized ? "Restore My PC" : "Maximize My PC");
      }
    }
    else if (action === "minimize-app") {
      if (isVents16 && event.target.closest(".v16-my-pc-window")) {
        windowElement.classList.remove("is-open");
        setStatus("My PC minimized");
      }
    }
    else if (action === "turn-off") {
      if (isVents16 && event.target.closest(".v16-my-pc-window")) {
        windowElement.classList.remove("is-open");
        setStatus("My PC closed");
      } else close();
    }
  });

  overlay.addEventListener("click", (event) => {
    if (event.target.closest("[data-game-back]")) {
      gameCleanup();
      gameCleanup = () => {};
      overlay.querySelector(".note-game-stage").hidden = true;
      overlay.querySelector(".note-games-grid").hidden = false;
      overlay.querySelector(".note-game-output").textContent = "Choose a game to play.";
      setStatus("Game library ready.");
      return;
    }
    const game = event.target.closest("[data-game]")?.dataset.game;
    if (game) playVentsGame(game);
  });

  overlay.addEventListener("dblclick", (event) => {
    const desktopApp = event.target.closest("[data-v16-app]")?.dataset.v16App;
    if (isVents16 && desktopApp) {
      openV16App(desktopApp);
      return;
    }
    const card = event.target.closest(".note-file-card");
    if (!card) return;
    openPath(card.dataset.path);
  });

  fileGrid.addEventListener("click", (event) => {
    const card = event.target.closest(".note-file-card");
    if (!card) return;
    selectedPath = card.dataset.path;
    const username = userForHomePath(selectedPath);
    if (username === state.user) {
      navigate(selectedPath);
      return;
    }
    fileGrid.querySelectorAll(".note-file-card").forEach((item) => {
      const selected = item === card;
      item.classList.toggle("is-selected", selected);
      item.setAttribute("aria-selected", selected ? "true" : "false");
    });
    setStatus(`Selected ${selectedPath.split("/").pop()}`);
  });

  fileGrid.addEventListener("dragstart", (event) => {
    const card = event.target.closest(".note-file-card");
    if (!card || !card.draggable) return;
    selectedPath = card.dataset.path;
    event.dataTransfer.effectAllowed = "move";
    event.dataTransfer.setData("text/plain", selectedPath);
  });

  fileGrid.addEventListener("dragover", (event) => {
    const card = event.target.closest(".note-file-card");
    const destination = card?.dataset.type === "dir" ? card.dataset.path : currentDirectory;
    if (isProtectedMoveDestination(destination)) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = "move";
    fileGrid.querySelectorAll(".is-drop-target").forEach((item) => item.classList.remove("is-drop-target"));
    if (card?.dataset.type === "dir") card.classList.add("is-drop-target");
  });

  fileGrid.addEventListener("dragleave", (event) => {
    if (!fileGrid.contains(event.relatedTarget)) fileGrid.querySelectorAll(".is-drop-target").forEach((item) => item.classList.remove("is-drop-target"));
  });

  fileGrid.addEventListener("drop", (event) => {
    event.preventDefault();
    const source = event.dataTransfer.getData("text/plain");
    const card = event.target.closest(".note-file-card");
    const destination = card?.dataset.type === "dir" ? card.dataset.path : currentDirectory;
    fileGrid.querySelectorAll(".is-drop-target").forEach((item) => item.classList.remove("is-drop-target"));
    if (source) moveEntryToFolder(source, destination);
  });

  overlay.addEventListener("contextmenu", (event) => {
    if (desktopContextMenu?.contains(event.target)) {
      event.preventDefault();
      return;
    }
    const desktop = event.target.closest(".v16-empty-desktop");
    const desktopIcon = event.target.closest(".v16-desktop-icon");
    const desktopControl = event.target.closest(".v16-desktop-power, .v16-desktop-context-menu");
    if (isVents16 && desktop && !desktopIcon && !desktopControl) {
      event.preventDefault();
      showDesktopContextMenu(event);
      return;
    }
    const filesView = event.target.closest(".note-files-view");
    if (!filesView) return;
    event.preventDefault();
    const card = event.target.closest(".note-file-card");
    showContextMenu(event, card?.dataset.path || null);
  });

  overlay.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      hideDesktopContextMenu();
      hideContextMenu();
    }
  });

  overlay.querySelectorAll(".note-place[data-path]").forEach((place) => {
    place.addEventListener("click", () => navigate(place.dataset.path));
  });

  overlay.querySelector("[data-tool-form=calculator]").addEventListener("submit", (event) => {
    event.preventDefault();
    const outputElement = overlay.querySelector(".note-calc-output");
    runGuiCommand("calc", [overlay.querySelector(".note-calc-input").value], outputElement);
  });
  overlay.querySelector("[data-tool-form=search]").addEventListener("submit", (event) => {
    event.preventDefault();
    const outputElement = overlay.querySelector(".note-search-output");
    outputElement.textContent = searchFiles(overlay.querySelector(".note-search-input").value);
  });
  const antivirusForm = overlay.querySelector("[data-tool-form=antivirus]");
  if (antivirusForm) antivirusForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const outputElement = antivirusForm.querySelector(".note-antivirus-output");
    const result = scanPathForMalware(HOME());
    if (result.threats.length) {
      outputElement.textContent = `${result.threats.length} threat(s) blocked.`;
      outputElement.className = "note-antivirus-output has-threats";
      setStatus("Graphical antivirus found threats in your files.", "error");
    } else {
      outputElement.textContent = "No threats found. Protection is active.";
      outputElement.className = "note-antivirus-output is-clean";
      setStatus("Graphical antivirus scan complete.", "saved");
    }
  });
  const filesystemForm = overlay.querySelector("[data-tool-form=filesystem]");
  if (filesystemForm) filesystemForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const outputElement = filesystemForm.querySelector(".note-filesystem-output");
    const result = checkFilesystemHealth();
    if (result.invalid) {
      outputElement.textContent = `${result.invalid} invalid node(s) found.`;
      outputElement.className = "note-filesystem-output has-errors";
      setStatus("Filesystem health check found errors.", "error");
    } else {
      outputElement.textContent = `${result.folders} folders · ${result.files} files · structure healthy.`;
      outputElement.className = "note-filesystem-output is-healthy";
      setStatus("Filesystem health check complete.", "saved");
    }
  });
  overlay.querySelector("[data-tool-form=terminal]").addEventListener("submit", (event) => {
    event.preventDefault();
    const parsed = tokenize(terminalInput.value.trim());
    if (!parsed.cmd) return;
    terminalOutput.textContent = `Running ${parsed.cmd}...`;
    runGuiCommand(parsed.cmd.toLowerCase(), parsed.args, terminalOutput);
    terminalInput.value = "";
  });
  codeFileList.addEventListener("change", () => {
    if (codeFileList.value) loadCodeFile(codeFileList.value);
  });
  codeLanguage.addEventListener("change", () => {
    const language = CODE_LANGUAGES[codeLanguage.value] || CODE_LANGUAGES.javascript;
    codePathInput.value = sourcePathForLanguage(codePathInput.value, codeLanguage.value, true);
    codeEditor.value = CODE_STARTERS[codeLanguage.value] || codeEditor.value;
    codeDirty = true;
    updateCodeLanguageUI();
    setCodeStatus(`${language.label} selected · new file is ${codePathInput.value.split("/").pop()}`, "unsaved");
  });

  pathInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") { event.preventDefault(); navigate(pathInput.value); }
  });
  filename.addEventListener("input", () => { dirty = true; setStatus("Unsaved changes", "unsaved"); });
  editor.addEventListener("input", () => { dirty = true; updateEditorStats(); setStatus("Unsaved changes", "unsaved"); });
  codePathInput.addEventListener("input", () => { codeDirty = true; setCodeStatus("Unsaved changes", "unsaved"); });
  codeEditor.addEventListener("input", () => { codeDirty = true; setCodeStatus("Unsaved changes", "unsaved"); });
  codeEditor.addEventListener("keydown", (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
      event.preventDefault();
      saveCodeFile();
    }
    if (event.key === "Tab") {
      event.preventDefault();
      const start = codeEditor.selectionStart;
      const end = codeEditor.selectionEnd;
      codeEditor.setRangeText("    ", start, end, "end");
      codeDirty = true;
      setCodeStatus("Unsaved changes", "unsaved");
    }
  });
  editor.addEventListener("keydown", (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
      event.preventDefault();
      saveFile();
    }
  });
  overlay.addEventListener("keydown", (event) => {
    event.stopPropagation();
    if (event.key === "Escape") {
      event.preventDefault();
      close();
    }
  });
  overlay.addEventListener("paste", (event) => event.stopPropagation());

  return promise;
}

function flushLines() {
  term.innerHTML = "";
  for (const row of output) {
    const div = document.createElement("div");
    div.className = "line" + (row.cls ? " " + row.cls : "");
    if (row.prompt) {
      div.classList.add("prompt");
      const ps = document.createElement("span");
      ps.className = "prompt-text";
      ps.textContent = promptLabel(row.pwd);
      const d = document.createElement("span");
      d.className = "dollar";
      d.textContent = ">";
      div.appendChild(ps);
      div.appendChild(d);
      const input = document.createElement("span");
      input.className = "input";
      const before = document.createElement("span");
      before.textContent = buffer.slice(0, cursor);
      const caret = document.createElement("span");
      caret.className = "caret";
      const after = document.createElement("span");
      after.textContent = buffer.slice(cursor);
      input.appendChild(before);
      input.appendChild(caret);
      input.appendChild(after);
      div.appendChild(input);
    } else if (row.html) {
      div.innerHTML = row.html;
    } else {
      div.textContent = row.text;
    }
    term.appendChild(div);
  }
  term.scrollTop = term.scrollHeight;
}

function print(text, cls = "") {
  for (const line of String(text).split("\n")) output.push({ text: line, cls });
}
function printHtml(html, cls = "") {
  output.push({ html, cls });
}
function clearScreen() {
  output = [];
}
function promptLine() {
  output.push({ prompt: true, pwd: cwd });
}

/* ---- interactive session (menus + inline text input) ---- */
let session = null;

function startMenu(title, items, footer) {
  let index = 0;
  const start = output.length;
  const render = () => {
    output.length = start;
    printHtml("  " + title, "ok");
    items.forEach((it, i) => {
      printHtml((i === index ? " > " : "   ") + it, i === index ? "ok" : "");
    });
    if (footer) printHtml(footer, "dim");
    flushLines();
  };
  return new Promise((resolve) => {
    const onKey = (e) => {
      if (e.key === "ArrowUp") { index = (index - 1 + items.length) % items.length; render(); e.preventDefault(); }
      else if (e.key === "ArrowDown") { index = (index + 1) % items.length; render(); e.preventDefault(); }
      else if (e.key === "Enter") { session = null; render(); resolve(index); e.preventDefault(); }
      else if (e.key === "Escape") { session = null; output.length = start; resolve(null); e.preventDefault(); }
    };
    session = { onKey };
    render();
  });
}

function startInternetDisclaimer(url = "") {
  const start = output.length;
  const options = ["Yes", "No"];
  let index = 0;
  const render = () => {
    output.length = start;
    print("INTERNET FILE DISCLAIMER", "warn");
    print("Files from the internet can be useful, but they may also be dangerous.", "warn");
    if (url) print(`You are about to install: ${url}`, "dim");
    print("Do you want to proceed?", "warn");
    printHtml(`  ${index === 0 ? "<" : " "} ${options[0]}${index === 0 ? ">" : " "}    ${index === 1 ? "<" : " "} ${options[1]}${index === 1 ? ">" : " "}`, "ok");
    print("Use the Left/Right arrow keys to choose, then press Enter.", "dim");
    flushLines();
  };
  return new Promise((resolve) => {
    const finish = (accepted) => {
      session = null;
      print(accepted ? "Proceeding with the internet file." : "Installation cancelled.", accepted ? "ok" : "dim");
      flushLines();
      resolve(accepted);
    };
    const onKey = (event) => {
      if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
        index = index === 0 ? 1 : 0;
        render();
        event.preventDefault();
      } else if (event.key === "Enter") {
        finish(index === 0);
        event.preventDefault();
      } else if (event.key === "Escape") {
        finish(false);
        event.preventDefault();
      }
    };
    session = { onKey };
    render();
  });
}

function startFileSecurityPrompt(path, scan, action = "open") {
  const start = output.length;
  const options = ["Yes", "No"];
  const actionLabel = action === "install" ? "install" : action === "run" ? "run" : "open";
  let index = 0;
  const render = () => {
    output.length = start;
    print("SECURITY WARNING", "err");
    print("This file may include malicious or overwhelming code that may harm your DOS/Computer.", "warn");
    print(`Are you sure you want to ${actionLabel} it?`, "warn");
    print(`File: ${path}`, "dim");
    scan.threats.forEach((threat) => print(`Detected: ${threat}`, "warn"));
    printHtml(`  ${index === 0 ? "<" : " "} ${options[0]}${index === 0 ? ">" : " "}    ${index === 1 ? "<" : " "} ${options[1]}${index === 1 ? ">" : " "}`, "ok");
    print("Use the Left/Right arrow keys to choose, then press Enter.", "dim");
    flushLines();
  };
  return new Promise((resolve) => {
    const finish = (accepted) => {
      session = null;
      print(accepted ? `Proceeding with the ${actionLabel}.` : `${actionLabel[0].toUpperCase()}${actionLabel.slice(1)} cancelled.`, accepted ? "ok" : "dim");
      flushLines();
      resolve(accepted);
    };
    const onKey = (event) => {
      if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
        index = index === 0 ? 1 : 0;
        render();
        event.preventDefault();
      } else if (event.key === "Enter") {
        finish(index === 0);
        event.preventDefault();
      } else if (event.key === "Escape") {
        finish(false);
        event.preventDefault();
      }
    };
    session = { onKey };
    render();
  });
}

function confirmGraphicalFileOpen(container, path, scan, action = "open") {
  const actionLabel = action === "install" ? "install" : action === "run" ? "run" : "open";
  const actionButtonLabel = actionLabel[0].toUpperCase() + actionLabel.slice(1);
  const backdrop = document.createElement("div");
  backdrop.className = "note-security-backdrop";
  backdrop.innerHTML = `
    <div class="note-security-modal" role="alertdialog" aria-modal="true" aria-labelledby="security-alert-title">
      <div class="note-security-kicker">NOVA GUARD // FILE ALERT</div>
      <h2 id="security-alert-title">Unsafe file detected</h2>
      <p>This file may include malicious or overwhelming code that may harm your DOS/Computer.</p>
      <div class="note-security-file">${escapeHtml(path)}</div>
      <ul class="note-security-reasons">${scan.threats.map((threat) => `<li>${escapeHtml(threat)}</li>`).join("")}</ul>
      <p>Do you want to proceed?</p>
      <div class="note-security-options">
        <button type="button" data-security-choice="yes">Yes, ${actionButtonLabel.toLowerCase()} file</button>
        <button type="button" data-security-choice="no">No, cancel</button>
      </div>
      <small>Use the Left/Right arrow keys to choose, then press Enter.</small>
    </div>
  `;
  container.appendChild(backdrop);
  const buttons = [...backdrop.querySelectorAll("[data-security-choice]")];
  let index = 0;
  let closed = false;
  const finish = (accepted) => {
    if (closed) return;
    closed = true;
    backdrop.remove();
    resolve(accepted);
  };
  const render = () => buttons.forEach((button, buttonIndex) => {
    button.classList.toggle("is-selected", buttonIndex === index);
  });
  let resolve;
  const promise = new Promise((resolveChoice) => { resolve = resolveChoice; });
  buttons[0].focus();
  render();
  backdrop.addEventListener("click", (event) => {
    const choice = event.target.closest("[data-security-choice]")?.dataset.securityChoice;
    if (choice) finish(choice === "yes");
  });
  backdrop.addEventListener("keydown", (event) => {
    event.stopPropagation();
    if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
      index = index === 0 ? 1 : 0;
      buttons[index].focus();
      render();
      event.preventDefault();
    } else if (event.key === "Enter") {
      finish(index === 0);
      event.preventDefault();
    } else if (event.key === "Escape") {
      finish(false);
      event.preventDefault();
    }
  });
  return promise;
}

async function confirmFileOpen(path, graphicalContainer = null) {
  const target = resolve(path);
  const node = nodeAt(target);
  if (state.version !== "1.5" || !node || node.type !== "file") return true;
  const scan = scanFileForMalware(target, node.content);
  if (scan.safe) return true;
  return confirmSecurityScan(target, scan, graphicalContainer, "open");
}

async function confirmSecurityScan(path, scan, graphicalContainer = null, action = "open") {
  return graphicalContainer
    ? confirmGraphicalFileOpen(graphicalContainer, path, scan, action)
    : startFileSecurityPrompt(path, scan, action);
}

function startInput(label) {
  const start = output.length;
  let value = "";
  const render = () => {
    output.length = start;
    printHtml("  " + label, "dim");
    printHtml("  > " + value + "█", "ok");
    flushLines();
  };
  return new Promise((resolve) => {
    const onKey = (e) => {
      if (e.key === "Enter") { session = null; output.length = start; resolve(value); e.preventDefault(); }
      else if (e.key === "Escape") { session = null; output.length = start; resolve(null); e.preventDefault(); }
      else if (e.key === "Backspace") { value = value.slice(0, -1); render(); e.preventDefault(); }
      else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey) { value += e.key; render(); e.preventDefault(); }
    };
    const onPaste = (e) => {
      const pasted = e.clipboardData?.getData("text/plain");
      if (!pasted) return;
      value += pasted.replace(/\r\n?/g, "\n");
      render();
      e.preventDefault();
    };
    session = { onKey, onPaste };
    render();
  });
}

function startEditor(filename, initialValue) {
  const start = output.length;
  const lines = String(initialValue || "").split("\n");
  let row = 0;
  let col = 0;

  const render = () => {
    output.length = start;
    printHtml(`--- ${escapeHtml(filename)} ---`, "dim");
    printHtml("Ctrl+S save and exit | Esc cancel", "dim");
    lines.forEach((line, index) => {
      const active = index === row;
      const before = active ? escapeHtml(line.slice(0, col)) : escapeHtml(line);
      const after = active ? escapeHtml(line.slice(col)) : "";
      const caret = active ? '<span class="caret"> </span>' : "";
      printHtml(`<span class="editor-line-number">${String(index + 1).padStart(3, "0")}</span> ${before}${caret}${after}`);
    });
    flushLines();
  };

  return new Promise((resolve) => {
    const finish = (value) => {
      session = null;
      output.length = start;
      resolve(value);
    };

    const onKey = (e) => {
      const line = lines[row];
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") {
        finish(lines.join("\n"));
        e.preventDefault();
      } else if (e.key === "Escape" || (e.ctrlKey && e.key.toLowerCase() === "c")) {
        finish(null);
        e.preventDefault();
      } else if (e.key === "Enter") {
        lines[row] = line.slice(0, col);
        lines.splice(row + 1, 0, line.slice(col));
        row++;
        col = 0;
        render();
        e.preventDefault();
      } else if (e.key === "Backspace") {
        if (col > 0) {
          lines[row] = line.slice(0, col - 1) + line.slice(col);
          col--;
        } else if (row > 0) {
          const previousLength = lines[row - 1].length;
          lines[row - 1] += line;
          lines.splice(row, 1);
          row--;
          col = previousLength;
        }
        render();
        e.preventDefault();
      } else if (e.key === "Delete") {
        if (col < line.length) lines[row] = line.slice(0, col) + line.slice(col + 1);
        else if (row < lines.length - 1) {
          lines[row] += lines[row + 1];
          lines.splice(row + 1, 1);
        }
        render();
        e.preventDefault();
      } else if (e.key === "ArrowLeft") {
        if (col > 0) col--;
        else if (row > 0) { row--; col = lines[row].length; }
        render();
        e.preventDefault();
      } else if (e.key === "ArrowRight") {
        if (col < line.length) col++;
        else if (row < lines.length - 1) { row++; col = 0; }
        render();
        e.preventDefault();
      } else if (e.key === "ArrowUp") {
        if (row > 0) { row--; col = Math.min(col, lines[row].length); }
        render();
        e.preventDefault();
      } else if (e.key === "ArrowDown") {
        if (row < lines.length - 1) { row++; col = Math.min(col, lines[row].length); }
        render();
        e.preventDefault();
      } else if (e.key === "Home") {
        col = 0;
        render();
        e.preventDefault();
      } else if (e.key === "End") {
        col = line.length;
        render();
        e.preventDefault();
      } else if (e.key === "Tab") {
        lines[row] = line.slice(0, col) + "    " + line.slice(col);
        col += 4;
        render();
        e.preventDefault();
      } else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
        lines[row] = line.slice(0, col) + e.key + line.slice(col);
        col++;
        render();
        e.preventDefault();
      }
    };

    const onPaste = (e) => {
      const pasted = e.clipboardData?.getData("text/plain");
      if (!pasted) return;
      const incoming = pasted.replace(/\r\n?/g, "\n").split("\n");
      const line = lines[row];
      const before = line.slice(0, col);
      const after = line.slice(col);
      lines[row] = before + incoming[0];
      if (incoming.length > 1) {
        lines.splice(row + 1, 0, ...incoming.slice(1, -1), incoming[incoming.length - 1] + after);
        row += incoming.length - 1;
        col = incoming[incoming.length - 1].length;
      } else {
        lines[row] += after;
        col += incoming[0].length;
      }
      render();
      e.preventDefault();
    };

    session = { onKey, onPaste };
    render();
  });
}

function cleanCompilerText(value) {
  return String(value || "")
    .replace(/\u001b\[[0-?]*[ -\/]*[@-~]/g, "")
    .replace(/\r/g, "");
}

function compilerEntriesText(entries = []) {
  return entries
    .map((entry) => typeof entry === "string" ? entry : entry?.text || "")
    .map(cleanCompilerText)
    .filter(Boolean)
    .join("");
}

async function runCOrCpp(source, language) {
  const compiler = COMPILER_EXPLORER_COMPILERS[language];
  if (!compiler) throw new Error(`No compiler is configured for ${language}.`);
  const response = await fetch(`https://godbolt.org/api/compiler/${compiler}/compile`, {
    method: "POST",
    headers: { "content-type": "application/json", accept: "application/json" },
    body: JSON.stringify({
      source,
      lang: language === "cpp" ? "c++" : "c",
      options: {
        userArguments: "-O0",
        compilerOptions: { executorRequest: true },
        filters: { execute: true },
        executeParameters: { args: [], stdin: "" },
        tools: [],
        libraries: [],
      },
    }),
  });
  if (!response.ok) throw new Error(`Compiler service returned HTTP ${response.status}.`);
  const result = await response.json();
  const output = [];
  const buildOutput = result.buildResult || {};
  const buildStderr = compilerEntriesText(buildOutput.stderr);
  const buildStdout = compilerEntriesText(buildOutput.stdout);
  const runtimeStdout = compilerEntriesText(result.stdout);
  const runtimeStderr = compilerEntriesText(result.stderr);
  if (buildStdout) output.push(buildStdout);
  if (buildStderr) output.push(buildStderr);
  if (runtimeStdout) output.push(runtimeStdout);
  if (runtimeStderr && runtimeStderr !== "Build failed") output.push(runtimeStderr);
  if (result.code !== 0) output.push(`Process exited with code ${result.code}.`);
  return {
    output: output.join("\n").trim() || "Program finished with no output.",
    failed: result.code !== 0,
  };
}

function setCodeOutputText(outputElement, value) {
  outputElement.replaceChildren(document.createTextNode(String(value ?? "")));
}

function renderCodePreview(outputElement, language, source) {
  const frame = document.createElement("iframe");
  frame.className = "code-preview-frame";
  frame.title = `${CODE_LANGUAGES[language]?.label || "Code"} preview`;
  frame.setAttribute("sandbox", "allow-scripts");
  frame.srcdoc = language === "css"
    ? `<!doctype html><html><head><meta charset="utf-8"><style>${source}</style></head><body><main class="preview-card"><h1>CSS preview</h1><p>Your stylesheet is live here.</p><button>Sample button</button></main></body></html>`
    : source;
  outputElement.replaceChildren(frame);
}

async function runRust(source) {
  const response = await fetch("https://play.rust-lang.org/execute", {
    method: "POST",
    headers: { "content-type": "application/json", accept: "application/json" },
    body: JSON.stringify({
      channel: "stable",
      mode: "debug",
      edition: "2021",
      crateType: "bin",
      tests: false,
      code: source,
      backtrace: false,
    }),
  });
  if (!response.ok) throw new Error(`Rust Playground returned HTTP ${response.status}.`);
  const result = await response.json();
  const output = [result.stdout, result.stderr].filter(Boolean).join("\n").trim();
  return {
    output: output || (result.success ? "Rust program finished with no output." : "Rust compilation failed."),
    failed: !result.success,
  };
}

async function runAssembly(source) {
  const compiler = COMPILER_EXPLORER_COMPILERS.assembly;
  const response = await fetch(`https://godbolt.org/api/compiler/${compiler}/compile`, {
    method: "POST",
    headers: { "content-type": "application/json", accept: "application/json" },
    body: JSON.stringify({
      source,
      lang: "assembly",
      options: {
        compilerOptions: { executorRequest: false },
        filters: { execute: false, intel: true, labels: true, directives: true },
        userArguments: "",
      },
    }),
  });
  if (!response.ok) throw new Error(`Assembly compiler returned HTTP ${response.status}.`);
  const result = await response.json();
  const errors = compilerEntriesText(result.stderr);
  const listing = compilerEntriesText(result.asm);
  return {
    output: [errors, listing].filter(Boolean).join("\n") || "Assembly assembled successfully.",
    failed: result.code !== 0,
  };
}

let wabtRuntime;
async function runWasm(source) {
  if (!wabtRuntime) {
    if (!window.WabtModule) {
      await new Promise((resolve, reject) => {
        const script = document.createElement("script");
        script.src = "https://cdn.jsdelivr.net/npm/wabt@1.0.37/index.js";
        script.onload = resolve;
        script.onerror = () => reject(new Error("Could not load the WebAssembly toolkit."));
        document.head.appendChild(script);
      });
    }
    wabtRuntime = await window.WabtModule();
  }
  const parsed = wabtRuntime.parseWat("program.wat", source);
  try {
    parsed.validate();
    const binary = parsed.toBinary({ log: false, write_debug_names: true }).buffer;
    const instantiated = await WebAssembly.instantiate(binary, {});
    const exports = instantiated.instance.exports;
    const names = Object.keys(exports);
    const callableName = ["main", "run", "_start"].find((name) => typeof exports[name] === "function");
    let resultLine = "No callable export; module compiled successfully.";
    if (callableName) {
      const value = exports[callableName]();
      resultLine = `${callableName}() → ${value === undefined ? "completed" : formatJavaScriptValue(value)}`;
    }
    return { output: `WebAssembly compiled successfully.\nExports: ${names.join(", ") || "none"}\n${resultLine}`, failed: false };
  } finally {
    parsed.destroy();
  }
}

async function runCodeSource(languageKey, source) {
  if (languageKey === "typescript") languageKey = "javascript";
  if (languageKey === "cython" || languageKey === "cpython") languageKey = "python";
  if (languageKey === "html" || languageKey === "css") return { preview: true, output: "Preview ready." };
  if (languageKey === "rust") return runRust(source);
  if (languageKey === "assembly") return runAssembly(source);
  if (languageKey === "wasm") return runWasm(source);
  if (languageKey === "python") {
    const result = await runPython(source);
    return { output: [result.stdout, result.stderr].filter(Boolean).join("\n") || "Program finished with no output.", failed: Boolean(result.stderr) };
  }
  if (languageKey === "c" || languageKey === "cpp") return runCOrCpp(source, languageKey);
  const result = await runJavaScript(source);
  return { output: [...result.output.map((entry) => entry.text), result.error].filter(Boolean).join("\n") || "Program finished with no output.", failed: Boolean(result.error) };
}

function vntLanguageFor(entry, declared = "") {
  const normalized = String(declared || "").trim().toLowerCase();
  const aliases = {
    js: "javascript", jsx: "javascript", ts: "typescript", tsx: "typescript",
    py: "python", pyx: "cython", cpy: "cpython", cxx: "cpp", "c++": "cpp",
    rs: "rust", asm: "assembly", wat: "wasm",
  };
  if (normalized) return aliases[normalized] || normalized;
  return codeLanguageForPath(entry || "main.js");
}

function parseVntPackage(content) {
  let manifest;
  try {
    manifest = JSON.parse(String(content || ""));
  } catch (_) {
    throw new Error("VNT package must contain a JSON manifest.");
  }
  if (!manifest || manifest.format !== "vnt/1") throw new Error("Unsupported VNT package format. Expected format=vnt/1.");
  if (typeof manifest.entry !== "string" || !manifest.entry.trim()) throw new Error("VNT package is missing an entry file.");
  if (!manifest.files || typeof manifest.files !== "object") throw new Error("VNT package is missing its files map.");
  const entry = manifest.entry.replaceAll("\\", "/").replace(/^\/+/, "");
  if (typeof manifest.files[entry] !== "string") throw new Error("VNT entry file is not present in the package.");
  const language = vntLanguageFor(entry, manifest.language);
  const supported = ["javascript", "typescript", "python", "cython", "cpython", "html", "css", "c", "cpp", "rust", "assembly", "wasm"];
  if (!supported.includes(language)) throw new Error("VNT language is not supported by the Vents runtime: " + language);
  const linked = Array.isArray(manifest.links) ? manifest.links : [];
  const units = [entry, ...linked].filter((name, index, list) => list.indexOf(name) === index).map((name) => {
    const normalized = String(name).replaceAll("\\", "/").replace(/^\/+/, "");
    if (!Object.prototype.hasOwnProperty.call(manifest.files, normalized) || typeof manifest.files[normalized] !== "string") {
      throw new Error("VNT linked file is not present: " + normalized);
    }
    const unitLanguage = vntLanguageFor(normalized, normalized === entry ? manifest.language : "");
    if (!supported.includes(unitLanguage)) throw new Error("VNT linked language is not supported: " + unitLanguage);
    return { path: normalized, language: unitLanguage, source: manifest.files[normalized] };
  });
  return { manifest, entry, language, source: manifest.files[entry], units };
}

async function runVntProgram(path, allowUnsafe = false) {
  const target = resolve(path);
  const node = nodeAt(target);
  if (!node || node.type !== "file") {
    print("File not found - " + path, "err");
    return;
  }
  const scan = scanFileForMalware(target, node.content);
  if (!scan.safe && !allowUnsafe) {
    print("Anti-malware blocked " + target.split("/").pop() + ".", "err");
    scan.threats.forEach((threat) => print("  " + threat, "warn"));
    return;
  }
  const packageInfo = parseVntPackage(node.content);
  print("VNT runtime: " + (packageInfo.manifest.name || target.split("/").pop()) + " [" + packageInfo.language + "]", "dim");
  for (const unit of packageInfo.units) {
    const result = await runCodeSource(unit.language, unit.source);
    if (result.preview) {
      print("Linked " + unit.path + " [" + unit.language + "] is ready for preview in Vents Code.", "dim");
    } else if (result.output) {
      print("[" + unit.path + "]\n" + result.output, result.failed ? "err" : "");
    }
  }
}

const NOVA_GUARD_WORKER_SOURCE = String.raw`
const output = [];
const outputLimit = ${NOVA_RUNTIME_OUTPUT_LIMIT};
let outputSize = 0;
let limitReported = false;
const textOf = (value) => {
  if (typeof value === "string") return value;
  if (value === undefined) return "undefined";
  if (value === null) return "null";
  if (typeof value === "bigint") return String(value) + "n";
  if (typeof value === "function") return "[Function]";
  try { return JSON.stringify(value); } catch (_) { return String(value); }
};
const emit = (method, values) => {
  const text = values.map(textOf).join(" ");
  outputSize += text.length;
  if (outputSize > outputLimit) {
    if (!limitReported) {
      limitReported = true;
      self.postMessage({ type: "limit", output });
    }
    return;
  }
  output.push({ text, cls: method === "error" ? "err" : method === "warn" ? "warn" : "" });
};
const makeConsole = () => ({
  log: (...values) => emit("log", values),
  info: (...values) => emit("info", values),
  debug: (...values) => emit("debug", values),
  warn: (...values) => emit("warn", values),
  error: (...values) => emit("error", values),
  dir: (...values) => emit("log", values),
  clear: () => {},
});
const pushPythonText = (target, text) => {
  outputSize += String(text).length;
  if (outputSize > outputLimit) {
    if (!limitReported) {
      limitReported = true;
      self.postMessage({ type: "limit", output });
    }
    return;
  }
  target.push(text);
};
self.onmessage = async (event) => {
  const { language, source, consoleName } = event.data;
  try {
    if (language === "javascript") {
      const runner = new Function("console", consoleName || "__novaConsole", '"use strict"; return (async () => {\n' + source + '\n})();');
      await runner(makeConsole(), makeConsole());
      self.postMessage({ type: "done", output });
      return;
    }
    const module = await import("https://cdn.jsdelivr.net/pyodide/v0.27.2/full/pyodide.mjs");
    const pyodide = await module.loadPyodide({ indexURL: "https://cdn.jsdelivr.net/pyodide/v0.27.2/full/" });
    self.postMessage({ type: "ready" });
    const stdout = [];
    const stderr = [];
    pyodide.setStdout({ batched: (text) => pushPythonText(stdout, text) });
    pyodide.setStderr({ batched: (text) => pushPythonText(stderr, text) });
    try {
      await pyodide.runPythonAsync(source);
    } catch (error) {
      pushPythonText(stderr, error && error.message ? error.message : String(error));
    }
    self.postMessage({ type: "done", stdout: stdout.join(""), stderr: stderr.join(""), output });
  } catch (error) {
    self.postMessage({ type: "error", error: error && error.stack ? error.stack : String(error), output });
  }
};
`;

function runNovaGuardedProgram(language, source, consoleName = "") {
  return new Promise((resolve) => {
    const workerUrl = URL.createObjectURL(new Blob([NOVA_GUARD_WORKER_SOURCE], { type: "text/javascript" }));
    const worker = new Worker(workerUrl, { type: "module" });
    let finished = false;
    let timer = setTimeout(() => finish({ type: "limit" }), NOVA_RUNTIME_LIMIT_MS);
    const finish = (result) => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      worker.terminate();
      URL.revokeObjectURL(workerUrl);
      if (result.type === "limit") {
        resolve({
          output: result.output || [],
          stdout: "",
          stderr: "Nova Guard terminated the program automatically because it exceeded the runtime or output safety limit.",
          error: "Nova Guard terminated the program automatically because it exceeded the runtime or output safety limit.",
          terminated: true,
        });
      } else if (result.type === "error") {
        resolve({ output: result.output || [], error: result.error || "Program failed." });
      } else {
        resolve({ output: result.output || [], stdout: result.stdout || "", stderr: result.stderr || "" });
      }
    };
    worker.onmessage = (event) => {
      if (event.data?.type === "ready") {
        clearTimeout(timer);
        timer = setTimeout(() => finish({ type: "limit" }), NOVA_RUNTIME_LIMIT_MS);
      } else {
        finish(event.data || { type: "error", error: "Nova Guard worker stopped unexpectedly." });
      }
    };
    worker.onerror = (event) => finish({ type: "error", error: event.message || "Nova Guard worker failed." });
    worker.postMessage({ language, source, consoleName });
  });
}

let pythonRuntime;
async function runPython(source) {
  if (state.version === "1.5") return runNovaGuardedProgram("python", source);
  if (!pythonRuntime) {
    pythonRuntime = import("https://cdn.jsdelivr.net/pyodide/v0.27.2/full/pyodide.mjs")
      .then(({ loadPyodide }) => loadPyodide({
        indexURL: "https://cdn.jsdelivr.net/pyodide/v0.27.2/full/",
      }));
  }
  const pyodide = await pythonRuntime;
  const stdout = [];
  const stderr = [];
  pyodide.setStdout({ batched: (text) => stdout.push(text) });
  pyodide.setStderr({ batched: (text) => stderr.push(text) });
  try {
    await pyodide.runPythonAsync(source);
  } catch (error) {
    stderr.push(error && error.message ? error.message : String(error));
  }
  return { stdout: stdout.join(""), stderr: stderr.join(""), failed: stderr.length > 0 };
}

function formatJavaScriptValue(value) {
  if (typeof value === "string") return value;
  if (value === undefined) return "undefined";
  if (value === null) return "null";
  if (typeof value === "bigint") return `${value}n`;
  if (typeof value === "function") return `[Function${value.name ? `: ${value.name}` : ""}]`;
  try {
    const json = JSON.stringify(value);
    return json === undefined ? String(value) : json;
  } catch {
    return String(value);
  }
}

function makeJavaScriptConsole(output, cls = "") {
  const write = (method, values) => {
    const text = values.map(formatJavaScriptValue).join(" ");
    output.push({
      text,
      cls: method === "error" ? "err" : method === "warn" ? "warn" : cls,
    });
  };

  return {
    log: (...values) => write("log", values),
    info: (...values) => write("info", values),
    debug: (...values) => write("debug", values),
    warn: (...values) => write("warn", values),
    error: (...values) => write("error", values),
    dir: (...values) => write("log", values),
    clear: () => {},
  };
}

async function runJavaScript(source, consoleName) {
  const output = [];
  if (state.version === "1.5") {
    if (consoleName && (!/^[A-Za-z_$][\w$]*$/.test(consoleName) || consoleName === "console")) {
      return {
        output,
        error: `Invalid console name '${consoleName}'. Use a JavaScript identifier such as myConsole.`,
      };
    }
    return runNovaGuardedProgram("javascript", source, consoleName);
  }
  const globalConsole = makeJavaScriptConsole(output);
  const parameterNames = ["console"];
  const parameterValues = [globalConsole];

  if (consoleName) {
    if (!/^[A-Za-z_$][\w$]*$/.test(consoleName) || consoleName === "console") {
      return {
        output,
        error: `Invalid console name '${consoleName}'. Use a JavaScript identifier such as myConsole.`,
      };
    }
    parameterNames.push(consoleName);
    parameterValues.push(makeJavaScriptConsole(output));
  }

  try {
    const runner = new Function(
      ...parameterNames,
      `"use strict"; return (async () => {\n${source}\n})();`,
    );
    await runner(...parameterValues);
    return { output };
  } catch (error) {
    return {
      output,
      error: error && error.stack ? error.stack : String(error),
    };
  }
}

function formatDownloadBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function filenameFromDownload(url, response) {
  const disposition = response.headers.get("content-disposition") || "";
  const encoded = disposition.match(/filename\*=UTF-8''([^;]+)/i);
  const quoted = disposition.match(/filename="?([^";]+)"?/i);
  let name = encoded ? encoded[1] : quoted ? quoted[1] : "";
  if (name) {
    try { name = decodeURIComponent(name); } catch (error) {}
  }
  if (!name) {
    const path = new URL(url).pathname;
    name = path.split("/").filter(Boolean).pop() || "downloaded-file";
    try { name = decodeURIComponent(name); } catch (error) {}
  }
  return name.replace(/[\\/:*?"<>|]/g, "_") || "downloaded-file";
}

async function downloadFile(url, onProgress = () => {}) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch (error) {
    throw new Error("Download URL must be a complete http:// or https:// link.");
  }
  if (!["http:", "https:"].includes(parsed.protocol)) {
    throw new Error("Only http:// and https:// download links are supported.");
  }

  const response = await fetch("/api/download", {
    method: "POST",
    headers: { "content-type": "application/json" },
    cache: "no-store",
    body: JSON.stringify({ url: parsed.href }),
  });
  if (!response.ok) {
    let message = `Download failed: HTTP ${response.status} ${response.statusText}`;
    try {
      const body = await response.json();
      if (body && body.error) message = body.error;
    } catch (_) {}
    throw new Error(message);
  }
  const contentType = response.headers.get("content-type") || "text/plain";
  const filename = response.headers.get("x-download-filename") || filenameFromDownload(parsed.href, response);
  const total = Number(response.headers.get("content-length")) || 0;
  const chunks = [];
  let loaded = 0;
  let lastProgressAt = 0;
  const report = (progress) => {
    const now = performance.now();
    if (progress.loaded === progress.total || now - lastProgressAt >= 60) {
      lastProgressAt = now;
      onProgress(progress);
    }
  };

  if (response.body) {
    const reader = response.body.getReader();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
      loaded += value.byteLength;
      report({ loaded, total });
    }
  } else {
    const value = new Uint8Array(await response.arrayBuffer());
    chunks.push(value);
    loaded = value.byteLength;
    report({ loaded, total: total || loaded });
  }

  const bytes = new Uint8Array(loaded);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  onProgress({ loaded, total: total || loaded });
  const isCom = /\.com$/i.test(filename);
  return {
    content: new TextDecoder().decode(bytes),
    filename,
    contentType,
    bytes: loaded,
    rawBytes: isCom ? Array.from(bytes) : null,
  };
}

function showProgress(text) {
  const last = output[output.length - 1];
  if (last && last.progress) {
    last.text = text;
  } else {
    output.push({ text, cls: "dim", progress: true });
  }
  flushLines();
}

  const ctx = {
  args: [],
  state,
  env,
  fs,
  get cwd() { return cwd; },
  set cwd(v) { cwd = v; },
  HOME,
  resolve,
  nodeAt,
  display,
  history,
  commands,
  startTime,
  print,
  printHtml,
  clear: clearScreen,
  menu: startMenu,
  input: startInput,
  editor: startEditor,
  runPython,
  runJavaScript,
  runCom: runComProgram,
  runVnt: runVntProgram,
  runSource: runCodeSource,
  languageForPath: codeLanguageForPath,
  confirmFileOpen,
  confirmSecurityScan,
  scanFileForMalware,
  scanPath: scanPathForMalware,
  antiMalwareEnabled: isAntiMalwareEnabled,
  downloadFile,
  formatDownloadBytes,
  progress: showProgress,
  confirmInternetInstall: startInternetDisclaimer,
  networkInfo,
  networkDetails,
  pingNetwork,
  pingHost,
  lookupHost,
  storageEstimate,
  storageInfo: () => indexedPFS.info(),
  wasmKernel: () => wasmKernelReady,
  processSnapshot: () => [
    { name: "nova-shell", pid: 1, session: "Console", memory: "browser-managed" },
    { name: "wasm-kernel", pid: 2, session: "Kernel", memory: "browser-managed" },
  ],
  versionInfo: (version) => versionInfo(version || state.version),
  normalizeVersion,
  commandAvailable,
  openGraphicalNote,
  openVentsDesktop,
  closeGraphicalNote,
  savePersistentState,
  promptLine,
  resetAll,
};

async function run(input) {
  const trimmed = input.trim();
  if (trimmed) {
    history.push(trimmed);
    if (history.length > 200) history.shift();
  }

  printHtml(`${promptLabel(cwd)}>`, "dim");
  if (trimmed) {
    const last = output[output.length - 1];
    last.html += " " + escapeHtml(trimmed);
  }

  if (trimmed) {
    const { cmd, args } = tokenize(trimmed);
    ctx.args = args;
    const commandName = cmd.toLowerCase();
    const fn = commands[commandName];
    if (!fn) {
      print(`Bad command or file name - ${cmd}`, "err");
    } else if (!commandAvailable(commandName)) {
      print(`${cmd}: this command is not available in ${versionInfo().label}`, "err");
    } else {
      try {
        await fn(ctx);
      } catch (err) {
        print(`${cmd}: ${err && err.message ? err.message : err}`, "err");
      } finally {
        savePersistentState();
      }
    }
  }

  promptLine();
  trimOutput();
  flushLines();
}

async function runComProgram(path, allowUnsafe = false) {
  const target = resolve(path);
  const node = nodeAt(target);
  if (!node || node.type !== "file") {
    print(`File not found - ${path}`, "err");
    return;
  }
  const programName = target.split("/").pop() || "PROGRAM.COM";
  const scan = scanFileForMalware(target, node.content);
  if (!scan.safe && !allowUnsafe) {
    print(`Anti-malware blocked ${programName}.`, "err");
    scan.threats.forEach((threat) => print(`  ${threat}`, "warn"));
    print("The program was not executed.", "dim");
    return;
  }
  if (Array.isArray(node.rawBytes) && node.rawBytes.length) {
    print("Running " + display(target) + " with the x86-16 Vents CPU...", "dim");
    const result = runX86Com(new Uint8Array(node.rawBytes));
    if (result.output) print(result.output);
    print(programName + ": x86-16 program finished after " + result.instructions + " instruction(s).", "dim");
    return;
  }
  const lines = String(node.content || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  print(`Running ${display(target)}...`, "dim");
  if (!lines.length) {
    print(`${programName}: program finished with no output.`, "dim");
    return;
  }
  const guardStarted = state.version === "1.5" ? Date.now() : 0;
  for (let index = 0; index < lines.length; index++) {
    if (state.version === "1.5" && (index >= NOVA_RUNTIME_COMMAND_LIMIT || Date.now() - guardStarted > NOVA_RUNTIME_LIMIT_MS)) {
      print("Nova Guard terminated the program automatically because it exceeded the runtime safety limit.", "err");
      return;
    }
    await run(lines[index]);
  }
  print(`${programName}: program finished.`, "dim");
}

window.addEventListener("beforeunload", savePersistentState);
window.addEventListener("pagehide", savePersistentState);
window.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "hidden") savePersistentState();
});

function trimOutput() {
  while (output.length > 5000) output.shift();
}

function tokenize(s) {
  const tokens = [];
  let cur = "";
  let inq = null;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (inq) {
      if (c === inq) inq = null;
      else cur += c;
    } else if (c === "'" || c === '"') {
      inq = c;
    } else if (c === " " || c === "\t") {
      if (cur) { tokens.push(cur); cur = ""; }
    } else {
      cur += c;
    }
  }
  if (cur) tokens.push(cur);
  return { cmd: tokens[0] || "", args: tokens.slice(1) };
}

function escapeHtml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function resetAll() {
  history = [];
  output = [];
  buffer = "";
  cursor = 0;
  cwd = "/";
  for (const k of Object.keys(env)) delete env[k];
  env.HOME = HOME();
  env.PATH = "C:\\DOS;C:\\BIN";
  Object.assign(fs, makeFS());
}

function lastPrompt() {
  for (let i = output.length - 1; i >= 0; i--) {
    if (output[i].prompt) return output[i];
  }
  return null;
}

window.addEventListener("keydown", (e) => {
  if (session) {
    session.onKey(e);
    return;
  }
  if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
    buffer = buffer.slice(0, cursor) + e.key + buffer.slice(cursor);
    cursor++;
    e.preventDefault();
  } else if (e.key === "Backspace") {
    if (cursor > 0) {
      buffer = buffer.slice(0, cursor - 1) + buffer.slice(cursor);
      cursor--;
    }
    e.preventDefault();
  } else if (e.key === "Enter") {
    if (e.isComposing) return;
    e.preventDefault();
    run(buffer);
    buffer = "";
    cursor = 0;
    historyIdx = -1;
  } else if (e.key === "ArrowLeft") {
    cursor = Math.max(0, cursor - 1);
    e.preventDefault();
  } else if (e.key === "ArrowRight") {
    cursor = Math.min(buffer.length, cursor + 1);
    e.preventDefault();
  } else if (e.key === "Home") {
    cursor = 0;
    e.preventDefault();
  } else if (e.key === "End") {
    cursor = buffer.length;
    e.preventDefault();
  } else if (e.key === "ArrowUp") {
    if (history.length) {
      if (historyIdx === -1) historyIdx = history.length;
      historyIdx = Math.max(0, historyIdx - 1);
      buffer = history[historyIdx];
      cursor = buffer.length;
      e.preventDefault();
    }
  } else if (e.key === "ArrowDown") {
    if (historyIdx !== -1) {
      historyIdx++;
      if (historyIdx >= history.length) {
        historyIdx = -1;
        buffer = "";
      } else {
        buffer = history[historyIdx];
      }
      cursor = buffer.length;
      e.preventDefault();
    }
  } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "l") {
    output = [];
    promptLine();
    e.preventDefault();
  } else if (e.ctrlKey && e.key.toLowerCase() === "c") {
    if (buffer) {
      buffer = "";
      cursor = 0;
      print("^C", "dim");
      promptLine();
      e.preventDefault();
    }
  } else if (e.ctrlKey && e.key.toLowerCase() === "u") {
    buffer = "";
    cursor = 0;
    e.preventDefault();
  }
  flushLines();
});

window.addEventListener("paste", (e) => {
  if (session) {
    if (session.onPaste) session.onPaste(e);
    else e.preventDefault();
    return;
  }
  const pasted = e.clipboardData?.getData("text/plain");
  if (!pasted) return;
  const text = pasted.replace(/\r\n?/g, "\n");
  buffer = buffer.slice(0, cursor) + text + buffer.slice(cursor);
  cursor += text.length;
  e.preventDefault();
  flushLines();
});

term.addEventListener("mousedown", (e) => {
  e.preventDefault();
  focusInput();
});

function focusInput() {
  try { term.focus({ preventScroll: false }); } catch (e) {}
}

term.addEventListener("click", focusInput);

setTimeout(focusInput, 0);

async function bootNovaDOS() {
  await persistentStateReady;
  printHtml(`${versionInfo().label}`, "dim");
  printHtml("Type HELP for a list of commands.", "dim");
  promptLine();
  flushLines();
}

bootNovaDOS();
