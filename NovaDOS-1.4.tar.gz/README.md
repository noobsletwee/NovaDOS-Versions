# NovaDOS 1.4

NovaDOS 1.4 is a browser-based DOS-style terminal interface. This package contains only the NovaDOS 1.4 release.

## Run locally

Serve this folder from a web server and open `index.html`. The included `server.js` provides the `/api/*` routes used by the network, DNS, ping, and download commands when deployed on a platform that supports the project's server runtime.

## GitHub Pages

GitHub Pages can serve the frontend files, but it does not run `server.js`. The terminal itself will load, while commands that require `/api/*` routes need a separate backend or hosting platform that supports the server file.
